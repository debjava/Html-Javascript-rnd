#!/bin/bash
. /db2home/db2inst1/sqllib/db2profile

mkdir -p /tmp/dbTables/logs
touch /tmp/dbTables/logs/db.log
chmod 777 /tmp/dbTables/logs/db.log
su db2inst1 -c "/opt/ibm/db2/V9.7/bin/db2 -tvf corebank-db2.sql" >> /tmp/dbTables/logs/db.log 2>&1

