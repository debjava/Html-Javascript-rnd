create db ccuser1;
connect to ccuser1;

/***********************************************************
------------------------------------------------------------
 THIS FILE IS GENERATED AND SHOULD NOT BE MANUALLY MODIFIED
 ALL CHANGES WILL BE OVERWRITTEN BY THE GENERATOR
------------------------------------------------------------
***********************************************************/

create sequence seq_cl_mask5 as bigint start with 1 increment by 1;

create sequence seq_td_mask4 as bigint start with 1 increment by 1;

create sequence seq_pay_in as bigint start with 1 increment by 1;

create sequence seq_pay_out as bigint start with 1 increment by 1;

create sequence seq_cl_mask1 as bigint start with 1 increment by 1;

create sequence seq_per_num as bigint start with 1 increment by 1;

create sequence seq_td_mask3 as bigint start with 1 increment by 1;

create sequence seq_cl_mask4 as bigint start with 1 increment by 1;

create sequence seq_ac_mask3 as bigint start with 1 increment by 1;

create sequence seq_trn_ref as bigint start with 1 increment by 1;

create sequence seq_ac_mask4 as bigint start with 1 increment by 1;

create sequence seq_man_ref as bigint start with 1 increment by 1;

create sequence seq_fx_ref as bigint start with 1 increment by 1;

create sequence seq_cl_mask3 as bigint start with 1 increment by 1;

create sequence seq_td_mask5 as bigint start with 1 increment by 1;

create sequence seq_ac_mask1 as bigint start with 1 increment by 1;

create sequence seq_td_mask2 as bigint start with 1 increment by 1;

create sequence seq_ac_mask5 as bigint start with 1 increment by 1;

create sequence seq_cl_mask2 as bigint start with 1 increment by 1;

create sequence seq_cln_num as bigint start with 1 increment by 1;

create sequence seq_org_num as bigint start with 1 increment by 1;

create sequence seq_td_mask1 as bigint start with 1 increment by 1;

create sequence seq_ac_mask2 as bigint start with 1 increment by 1;

create table xScheduledJob
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xName varchar(120) not null,
	xGroup varchar(13) not null,
	xBeanId varchar(120) not null,
	xTriggerType varchar(8) not null,
	xCronExpression varchar(120),
	xPeriod int,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xSchedulerLog
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xExecutingEntityId int not null,
	xJobName varchar(120) not null,
	xTaskEvent varchar(8) not null,
	xEventTime timestamp not null with default,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xGLCurrency
(
	xMasterId int not null,
	xEntityId int not null,
	xCurrency varchar(3) not null,
	xTaxWitholdGLAccount varchar(12),
	xRetainedEarningsGLAccount varchar(12),
	xYearToDateProfitLossGLAccount varchar(12),
	xSuspenseBSGLAccount varchar(12),
	xFXTranslationReserveGLAccount varchar(12),
	xFXTranslationDiffGLAccount varchar(12),
	xProfitOnCurExchangeGL varchar(12) not null,
	xLossOnCurExchangeGL varchar(12) not null,
	xNetProfitLossGLAccount varchar(12),
	xSuspenseISGLAccount varchar(12),
	xFXUnrealisedProfitGLAccount varchar(12) not null,
	xFXUnrealisedLossGLAccount varchar(12) not null,
	xDefaultGLDBTransactionCode varchar(4),
	xDefaultGLCRTransactionCode varchar(4),
	xDefaultClientDbTC varchar(4),
	xDefaultClientCrTC varchar(4),
	xCurrencyPosGLDbTC varchar(4),
	xCurrencyPosGLCrTC varchar(4),
	xClearToBaseCurGLDbTC varchar(4),
	xClearToBaseCurGLCrTC varchar(4),
	xProfitOnNonCashGL varchar(12) not null,
	xLossOnNonCashGL varchar(12) not null,
	xCashRateType varchar(16) for bit data not null,
	xNonCashRateType varchar(16) for bit data not null,
	xRevaluationRateType varchar(16) for bit data not null,
	xRevalOfCurExchangeDbTC varchar(4) not null,
	xRevalOfCurExchangeCrTC varchar(4) not null,
	xRevalOfNonCashDbTC varchar(4) not null,
	xRevalOfNonCashCrTC varchar(4) not null,
	xUnrealizedRevalDbTC varchar(4),
	xUnrealizedRevalCrTC varchar(4),
	xYearToDateDbTC varchar(4),
	xYearToDateCrTC varchar(4),
	xSuspended char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCurrency)
);

create table xGLJournal_StatusChanges_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xGLJournal varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xGLJournal, xStatusChange)
);

create table xGLJournal
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xTransactionRefNo varchar(16) not null,
	xGLCurrency varchar(3) not null,
	xGLJournalTemplate varchar(10) not null,
	xAutoGenerate char(1) not null,
	xJournalNumber int not null,
	xValueDate date not null with default,
	xBookDate date not null with default,
	xGLAccountingPeriod varchar(16) for bit data not null,
	xDescription varchar(120),
	xStatus varchar(8) not null,
	xOriginBranch varchar(10) not null,
	xLockedBy varchar(16) for bit data,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xGLAccount_GLCurrencies_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xGLAccount varchar(12) not null,
	xGLCurrency varchar(3) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xGLAccount, xGLCurrency)
);

create table xGLAccount
(
	xMasterId int not null,
	xEntityId int not null,
	xCode varchar(12) not null,
	xName varchar(120) not null,
	xAllCurrencies char(1) not null,
	xGLAccountType varchar(20) not null,
	xTrustType varchar(7),
	xTrustGLAccountCode varchar(32),
	xNormalBalance varchar(6) not null,
	xCashAccount char(1) not null,
	xGLCurrencyPosition varchar(3),
	xFXConsolidationType varchar(20),
	xClearToBaseCurrency char(1) not null,
	xManualPosting char(1) not null,
	xUseDepartment varchar(8) not null,
	xUseCostCentre varchar(8) not null,
	xUseProject varchar(8) not null,
	xIBANRequired char(1) not null,
	xIBAN varchar(35),
	xSuspended char(1) not null,
	xNotes varchar(500),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCode)
);

create table xGLCurrencyExc_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xGLCurrencyExchange varchar(16) not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xGLCurrencyExchange, xStatusChange)
);

create table xGLCurrencyExchange
(
	xMasterId int not null,
	xEntityId int not null,
	xTransactionRefNo varchar(16) not null,
	xGLJournalTemplate varchar(10) not null,
	xValueDate date not null with default,
	xTransactionCodeDB varchar(4) not null,
	xGLAccountDB varchar(12),
	xClientAccountDB varchar(16) for bit data,
	xBranchDB varchar(10) not null,
	xCurrencyDB varchar(3) not null,
	xAmountToDebit decimal(21,6) not null,
	xTransactionCodeCR varchar(4) not null,
	xGLAccountCR varchar(12),
	xClientAccountCR varchar(16) for bit data,
	xBranchCR varchar(10) not null,
	xCurrencyCR varchar(3) not null,
	xAmountToCredit decimal(21,6) not null,
	xDescriptionFrom varchar(120) not null,
	xNotesFrom varchar(500),
	xDescriptionTo varchar(120) not null,
	xNotesTo varchar(500),
	xRateType varchar(16) for bit data not null,
	xFxRate decimal(21,6) not null,
	xStatus varchar(10) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xOriginBranch varchar(10) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xTransactionRefNo)
);

create table xGLChartOfAccountName
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(120) not null,
	xReportType varchar(15) not null,
	xTemplate char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xGLChartOfAccountLinkage
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xGLAccount varchar(12) not null,
	xGLChartOfAccountCR varchar(16) for bit data not null,
	xGLChartOfAccountDB varchar(16) for bit data not null,
	xGLChartOfAccountName varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xTransactionDefault
(
	xMasterId int not null,
	xEntityId int not null,
	xCode varchar(10) not null,
	xType varchar(27) not null,
	xDescription varchar(120) not null,
	xDescriptionDB varchar(120) not null,
	xNotesDB varchar(2000),
	xDescriptionCR varchar(120) not null,
	xNotesCR varchar(2000),
	xTransactionCodeGLDB varchar(4),
	xTransactionCodeGLCR varchar(4),
	xTransactionCodeClientDB varchar(4),
	xTransactionCodeClientCR varchar(4),
	xAddPaymentDays smallint not null,
	xPaymentComment varchar(2000),
	xLiabilityTransactionDefault varchar(10),
	xSuspended char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCode)
);

create table xTransactionCode_Charges_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xTransactionCode varchar(4) not null,
	xCharge varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xTransactionCode, xCharge)
);

create table xTransactionCode
(
	xMasterId int not null,
	xEntityId int not null,
	xCode varchar(4) not null,
	xDescription varchar(120) not null,
	xDebitOrCredit varchar(6) not null,
	xTransactionType varchar(14) not null,
	xClearingDays int not null,
	xGraceDays int not null,
	xForceChequeNumber char(1) not null,
	xSuspended char(1) not null,
	xCashInOut char(1) not null,
	xAffectsDormancyCalculation char(1) not null,
	xAllowDescriptionChange char(1) not null,
	xForceDescriptionChange char(1) not null,
	xGenerateDocument varchar(13),
	xCombineFees char(1) not null,
	xOverrideBalCheck char(1) not null,
	xOverrideBalCheckOnReversals char(1) not null,
	xAllowForcedDebit char(1) not null,
	xAllowForcedCredit char(1) not null,
	xOverrideBlockedStatus char(1) not null,
	xCombinedChargeTransactionCode varchar(4),
	xReverseTransactionCode varchar(4),
	xOverrideDisallowCreditCheck char(1) not null,
	xOverrideDisallowDebitCheck char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCode)
);

create table xGLChartOfAccount
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xChartOfAccountName varchar(16) for bit data not null,
	xParent varchar(16) for bit data,
	xDescription varchar(120) not null,
	xEntryType varchar(7) not null,
	xGLAccountCode varchar(12) not null,
	xNormalBalance varchar(6),
	xSummaryLevel smallint,
	xAutoSummary char(1),
	xAllCurrencies char(1) not null,
	xCashAccount char(1) not null,
	xGLAccountType varchar(20),
	xGLCurrencyPosition varchar(3),
	xTrustType varchar(7),
	xTrustGLAccount varchar(12),
	xNotes varchar(2000),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xTransDefGLLnk
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xTransactionDefault varchar(10) not null,
	xGLAccount varchar(12) not null,
	xGLCurrency varchar(3),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xGLBatch_StatusChanges_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xGLBatch bigint not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xGLBatch, xStatusChange)
);


create sequence SEQ_GLBatch as bigint start with 1 increment by 1;

create table xGLBatch
(
	xAutoId bigint not null,
	xMasterId int not null,
	xEntityId int not null,
	xValueDate date not null with default,
	xCrossEntityProcessed char(1) not null,
	xStatus varchar(10) not null,
	xLockedBy varchar(16) for bit data,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xAutoId, xMasterId, xEntityId)
);

create table xGLJournalTemplate_TC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xGLJournalTemplate varchar(10) not null,
	xTransactionCode varchar(4) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xGLJournalTemplate, xTransactionCode)
);

create table xGLJournalTemplate_Client_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xGLJournalTemplate varchar(10) not null,
	xClient varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xGLJournalTemplate, xClient)
);

create table xGLJournalTemplate
(
	xMasterId int not null,
	xEntityId int not null,
	xCode varchar(10) not null,
	xDescription varchar(60) not null,
	xRestrictBackValueDate char(1),
	xRestrictFutureValueDate char(1),
	xDaysForBackValue int,
	xDaysForFutureValue int,
	xSelectedClient char(1) not null,
	xSelectedDBTransacationCode char(1) not null,
	xSelectedCRTransacationCode char(1) not null,
	xSuspended char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCode)
);

create table xGLChartOfAccountLanguage
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xGLChartOfAccount varchar(16) for bit data not null,
	xLanguage varchar(2),
	xName varchar(120) not null,
	xNotes varchar(2000) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);


create sequence SEQ_GLTransaction as bigint start with 1 increment by 1;

create table xGLTransaction
(
	xAutoId bigint not null,
	xMasterId int not null,
	xEntityId int not null,
	xTransactionRefNo varchar(16) not null,
	xContractRefNo varchar(20) not null,
	xGLAccount varchar(12) not null,
	xAccountBranch varchar(10) not null,
	xTransactionBranch varchar(10) not null,
	xTransactionCode varchar(4) not null,
	xGLCurrency varchar(3) not null,
	xDebitOrCredit varchar(6) not null,
	xAmount decimal(21,6) not null,
	xLcyEquivalent decimal(21,6),
	xRateToBase decimal(16,6),
	xBookingDate date not null with default,
	xValueDate date not null with default,
	xEvent varchar(6) not null,
	xModule varchar(2) not null,
	xMainEntry char(1) not null,
	xGroupId int not null,
	xDescription varchar(120),
	xNotes varchar(2000),
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xAutoId, xMasterId, xEntityId)
);


create sequence SEQ_JournalDetail as bigint start with 1 increment by 1;

create table xJournalDetail
(
	xAutoId bigint not null,
	xMasterId int not null,
	xEntityId int not null,
	xTransactionRefNo varchar(16) not null,
	xGLJournal varchar(16) for bit data not null,
	xGLAccount varchar(12),
	xClientAccount varchar(16) for bit data,
	xTransactionCode varchar(4) not null,
	xNotes varchar(2000),
	xAccountBranch varchar(10) not null,
	xAmount decimal(21,6) not null,
	xDescription varchar(120),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xAutoId, xMasterId, xEntityId)
);

create table xTCDefaultGL
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xTransactionCode varchar(4) not null,
	xGLCurrency varchar(3) not null,
	xGLAccount varchar(12) not null,
	xOverrideDefaultGLAccount char(1) not null,
	xAmount decimal(21,6) not null,
	xOverrideDefaultAmount char(1) not null,
	xSuspended char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xGLAccountingPeriod
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xYearStart date not null with default,
	xYearEnd date not null with default,
	xName varchar(120) not null,
	xOpened timestamp,
	xOpenedBy varchar(16) for bit data,
	xClosed timestamp,
	xClosedBy varchar(16) for bit data,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xGLJournalBranchCombination
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xGLJournalTemplate varchar(10) not null,
	xBranch varchar(10) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xGLJournalBranchRateType
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xGLJournalBranchCombination varchar(16) for bit data not null,
	xCurrencyRateType varchar(16) for bit data not null,
	xMinimumVariance decimal(21,6) not null,
	xMaximumVariance decimal(21,6) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xValueDatedCABalance
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xValueDate date not null with default,
	xBranch varchar(10),
	xClientAccount varchar(16) for bit data,
	xGLCurrency varchar(3),
	xContributingCreditTurnOver decimal(21,6),
	xContributingDebitTurnOver decimal(21,6),
	xContributingBalance decimal(21,6),
	xNonContributingCreditTurnOver decimal(21,6),
	xNonContributingDebitTurnOver decimal(21,6),
	xNonContributingBalance decimal(21,6),
	xNetBalance decimal(21,6),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xValueDatedGLBalance
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xValueDate date not null with default,
	xBranch varchar(10),
	xGLAccount varchar(12),
	xGLCurrency varchar(3),
	xCreditTurnOver decimal(21,6),
	xDebitTurnOver decimal(21,6),
	xNetBalance decimal(21,6),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCollateralCode
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xTransactionFeeAccounting
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xTransactionFeeProfile int not null,
	xGLCurrency varchar(3),
	xGLAccount varchar(12),
	xClientAccount varchar(16) for bit data,
	xTransactionCodeCR varchar(4) not null,
	xTransactionCodeDB varchar(4) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xInterestBase
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xExternalCode varchar(24) not null,
	xDescription varchar(120) not null,
	xSuspended char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xDueDiligenceBinaryData_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xDueDiligenceIdentification varchar(16) for bit data not null,
	xBinaryData varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xDueDiligenceIdentification, xBinaryData)
);

create table xDueDiligenceIdentification
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xContact varchar(16) for bit data not null,
	xType varchar(24) not null,
	xIdentificationNumber varchar(32) not null,
	xIssuingCountry varchar(3) not null,
	xIssuingCountryRegion varchar(16) for bit data,
	xIssueDate date not null with default,
	xExpiryDate date,
	xBinaryData varchar(16) for bit data,
	xNotes varchar(500),
	xSuspended char(1) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xApproved timestamp,
	xApprovedBy varchar(16) for bit data,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xClientContactLink
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xContact varchar(16) for bit data not null,
	xClient varchar(16) for bit data not null,
	xRole varchar(16),
	xOwnership decimal(10,5) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xTransactionFeeProfile
(
	xMasterId int not null,
	xEntityId int not null,
	xCode int not null,
	xDescription varchar(120) not null,
	xType varchar(6) not null,
	xAppliesTo varchar(6) not null,
	xAdditive char(1) not null,
	xCumulative char(1) not null,
	xWaiveFeePeriod varchar(12) not null,
	xFreeChargesInPeriod smallint not null,
	xSuspended char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCode)
);

create table xInterestRate
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xInterestBase varchar(16) for bit data not null,
	xEffectiveBy date not null with default,
	xCurrency varchar(3) not null,
	xRate decimal(16,6) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xApproved timestamp,
	xApprovedBy varchar(16) for bit data,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);


create sequence SEQ_ClientTransactionNew as bigint start with 1 increment by 1;

create table xClientTransactionNew
(
	xAutoId bigint not null,
	xMasterId int not null,
	xEntityId int not null,
	xTransactionRefNo varchar(16) not null,
	xContractRefNo varchar(20) not null,
	xClientAccount varchar(16) for bit data not null,
	xAccountBranch varchar(10) not null,
	xTransactionBranch varchar(10) not null,
	xTransactionCode varchar(4) not null,
	xGLCurrency varchar(3) not null,
	xDebitOrCredit varchar(6) not null,
	xAmount decimal(21,6) not null,
	xLcyEquivalent decimal(21,6) not null,
	xRateToBase decimal(16,6) not null,
	xBookingDate date not null with default,
	xValueDate date not null with default,
	xEvent varchar(6) not null,
	xModule varchar(2) not null,
	xMainEntry char(1) not null,
	xGroupId int not null,
	xChannel varchar(16) for bit data not null,
	xDescription varchar(120),
	xNotes varchar(2000),
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xAutoId, xMasterId, xEntityId)
);

create table xTransCodeTransFeeLink
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xTransactionCode varchar(4),
	xTransactionFee varchar(16) for bit data not null,
	xSuspended char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCAInterestPayable_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xClientAccountInterestPayable varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xClientAccountInterestPayable, xStatusChange)
);

create table xClientAccountInterestPayable
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xMethod varchar(8) not null,
	xClientAccount varchar(16) for bit data not null,
	xInterestScheme varchar(16) for bit data,
	xModifyInterestParameters char(1) not null,
	xRate decimal(21,6),
	xOffset decimal(21,6),
	xInterestFrequency varchar(11) not null,
	xOnBalance varchar(10),
	xPaymentDay varchar(22),
	xNumberOfDays int,
	xCurrency varchar(3) not null,
	xCurrencyRateType varchar(16) for bit data,
	xMinimumInterest decimal(21,6),
	xMaximumInterest decimal(21,6),
	xInterestBase varchar(16) for bit data,
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xUpdated timestamp not null with default,
	xUpdatedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCAInterestReceivable_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCAInterestReceivable varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCAInterestReceivable, xStatusChange)
);

create table xCAInterestReceivable
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xMethodAuth varchar(8) not null,
	xMethodUnAuth varchar(8) not null,
	xClientAccount varchar(16) for bit data not null,
	xInterestSchemeAuth varchar(16) for bit data,
	xInterestSchemeUnAuth varchar(16) for bit data,
	xModifyInterestParameters char(1) not null,
	xRateAuth decimal(21,6),
	xRateUnAuth decimal(21,6),
	xOffsetAuth decimal(21,6),
	xOffsetUnAuth decimal(21,6),
	xInterestFrequency varchar(11) not null,
	xOnBalance varchar(10),
	xCurrency varchar(3) not null,
	xCurrencyRateType varchar(16) for bit data,
	xMinimumInterest decimal(21,6),
	xMaximumInterest decimal(21,6),
	xInterestBaseAuth varchar(16) for bit data,
	xInterestBaseUnAuth varchar(16) for bit data,
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xUpdated timestamp not null with default,
	xUpdatedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCACharges_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xClientAccountCharges varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xClientAccountCharges, xStatusChange)
);

create table xClientAccountCharges
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xClientAccount varchar(16) for bit data not null,
	xAccountOpeningFee varchar(16) for bit data,
	xServiceCharge varchar(16) for bit data,
	xMonthlyServiceCharge varchar(16) for bit data,
	xNonOperatingFee varchar(16) for bit data,
	xAccountClosingFee varchar(16) for bit data,
	xAdditionalStatementFee varchar(16) for bit data,
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xUpdated timestamp not null with default,
	xUpdatedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCAAdditionalCharges_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCAAdditionalCharges varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCAAdditionalCharges, xStatusChange)
);

create table xCAAdditionalCharges
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xClientAccount varchar(16) for bit data not null,
	xDescription varchar(120) not null,
	xStatus varchar(8) not null,
	xChargeId int,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xAdditionalCharge varchar(16) for bit data,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCASettings_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xClientAccountSettings varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xClientAccountSettings, xStatusChange)
);

create table xClientAccountSettings
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xClientAccount varchar(16) for bit data not null,
	xOverdraftLimit decimal(21,6),
	xExpiryDate date,
	xDormant char(1),
	xDormantFrom date,
	xLastDebitTransaction date,
	xLastCreditTransaction date,
	xDisallowDebit char(1),
	xDisallowCredit char(1),
	xStatus varchar(8) not null,
	xBalanceCheck varchar(22),
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xUpdated timestamp not null with default,
	xUpdatedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCASignatory_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xClientAccountSignatory varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xClientAccountSignatory, xStatusChange)
);

create table xClientAccountSignatory
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xClientAccount varchar(16) for bit data not null,
	xPerson varchar(16) for bit data not null,
	xLimit decimal(21,6) not null,
	xNotes varchar(500),
	xStatus varchar(8) not null,
	xGroup varchar(5) not null,
	xOperatingInstruction varchar(7) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xUpdated timestamp not null with default,
	xUpdatedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCAStatus_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xClientAccountStatus varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xClientAccountStatus, xStatusChange)
);

create table xClientAccountStatus
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xClientAccount varchar(16) for bit data not null,
	xReason varchar(120),
	xStatus varchar(9) not null,
	xRecordStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCAClosure_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xClientAccountClosure varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xClientAccountClosure, xStatusChange)
);

create table xClientAccountClosure
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xClient varchar(16) for bit data not null,
	xAccountNumber varchar(16) for bit data not null,
	xCurrentBalance decimal(21,6) not null,
	xInProcess decimal(21,6) not null,
	xBlockedAmount decimal(21,6) not null,
	xOverdraftLimit decimal(21,6) not null,
	xAvailableBalance decimal(21,6) not null,
	xInterestPayableAccrued decimal(21,6) not null,
	xInterestReceivableAccrued decimal(21,6) not null,
	xAccountClosingFee decimal(21,6),
	xNetPayableAmount decimal(21,6) not null,
	xPaymentOption varchar(17),
	xClientTo varchar(16) for bit data,
	xAccountTo varchar(16) for bit data,
	xCashPayoutBranch varchar(10),
	xCashGL varchar(12),
	xAccountToExternal varchar(34),
	xPayoutBranch varchar(120),
	xPayoutBank varchar(16) for bit data,
	xBankNameOther varchar(120),
	xBICCode varchar(11),
	xBankClearingCode varchar(20),
	xTransactionDate date not null with default,
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xElectronicFundTransfer
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xType varchar(12) not null,
	xTypeOfBeneficiary varchar(12) not null,
	xFirstName varchar(60),
	xLastName varchar(60),
	xOrganisationName varchar(60),
	xAddress varchar(16) for bit data,
	xBankAccount varchar(16) for bit data not null,
	xDetailsOfCharges varchar(11) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xTransactionFee
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xTransactionFeeProfile int not null,
	xFeeSchedule int not null,
	xGLCurrency varchar(3) not null,
	xAmountLow decimal(21,6) not null,
	xAmountHigh decimal(21,6) not null,
	xFeeBasis varchar(13) not null,
	xFee decimal(21,6) not null,
	xMinimumFee decimal(21,6) not null,
	xMaximumFee decimal(21,6) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xPayment_BinaryDatas_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xPayment varchar(16) for bit data not null,
	xBinaryData varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xPayment, xBinaryData)
);

create table xPayment_StatusChanges_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xPayment varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xPayment, xStatusChange)
);

create table xPayment
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xPaymentNumber int not null,
	xValueDate date not null with default,
	xPaymentDate date not null with default,
	xClientAccountToDebit varchar(16) for bit data not null,
	xAmountType varchar(26) not null,
	xGLCurrency varchar(3) not null,
	xAmount decimal(21,6) not null,
	xInProcessAmountDB decimal(21,6) not null,
	xActionAfterTransfer varchar(13) not null,
	xPaymentComment varchar(2000) not null,
	xReasonForPayment varchar(2000),
	xTransactionDefault varchar(10) not null,
	xCashGLAccountGLCurrency varchar(3) not null,
	xCashGLAccount varchar(12) not null,
	xTransactionCodeDB varchar(4) not null,
	xTransactionCodeCR varchar(4) not null,
	xDescriptionDB varchar(120) not null,
	xDescriptionCR varchar(120) not null,
	xNotesDB varchar(3000),
	xNotesCR varchar(3000),
	xGLBatch bigint,
	xStatus varchar(10) not null,
	xExported char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xEmploymentCategory
(
	xMasterId int not null,
	xEntityId int not null,
	xCode varchar(4) not null,
	xDescription varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCode)
);

create table xClientAccountIdentifier
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xClientAccount varchar(16) for bit data not null,
	xAccountNumber varchar(255) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xClient_Diaries_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xClient varchar(16) for bit data not null,
	xDiary varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xClient, xDiary)
);

create table xClient_Categories_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xClient varchar(16) for bit data not null,
	xCategory varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xClient, xCategory)
);

create table xClient_Documents_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xClient varchar(16) for bit data not null,
	xDocument varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xClient, xDocument)
);

create table xClient_BankAccounts_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xClient varchar(16) for bit data not null,
	xBankAccount varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xClient, xBankAccount)
);

create table xClient
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xClientNumber int not null,
	xClientType varchar(9) not null,
	xName varchar(120) not null,
	xNameForStatement varchar(120) not null,
	xOwnerBranch varchar(10) not null,
	xOriginBranch varchar(10) not null,
	xAccountManager varchar(16) for bit data,
	xAgent varchar(16) for bit data,
	xAnniversary date,
	xMinor char(1) not null,
	xDead char(1) not null,
	xClosed char(1) not null,
	xFeeSchedule int,
	xLanguageOfCommunication varchar(2),
	xAMLCategory varchar(16) for bit data,
	xPricingCategory varchar(16) for bit data,
	xOfferingCategory varchar(16) for bit data,
	xRiskCountry varchar(3),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xSourceOfFund
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xTransfer_BinaryDatas_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xTransfer varchar(16) for bit data not null,
	xBinaryData varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xTransfer, xBinaryData)
);

create table xTransfer_StatusChanges_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xTransfer varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xTransfer, xStatusChange)
);

create table xTransfer
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xTransferNumber int not null,
	xValueDate date not null with default,
	xAccountToDebit varchar(16) for bit data not null,
	xAccountToCredit varchar(16) for bit data not null,
	xAmountType varchar(26) not null,
	xGLCurrency varchar(3) not null,
	xAmount decimal(21,6) not null,
	xInProcessAmountDB decimal(21,6) not null,
	xInProcessAmountCR decimal(21,6) not null,
	xActionAfterTransfer varchar(13) not null,
	xTransactionDefault varchar(10) not null,
	xTransactionCodeDB varchar(4) not null,
	xTransactionCodeCR varchar(4) not null,
	xDescriptionDB varchar(120) not null,
	xDescriptionCR varchar(120) not null,
	xNotesDB varchar(2000),
	xNotesCR varchar(2000),
	xGLBatch bigint,
	xStatus varchar(10) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xBankersDraft
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xType varchar(16) not null,
	xSendBy varchar(7) not null,
	xNameOnDraft varchar(120) not null,
	xAddress varchar(16) for bit data not null,
	xPhoneNumber varchar(120) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xFeeSchedule
(
	xMasterId int not null,
	xCode int not null,
	xDescription varchar(120) not null,
	xSuspended char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xCode)
);

create table xDueDiligenceEmployment
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xContact varchar(16) for bit data not null,
	xType varchar(31) not null,
	xEmployeeNumber varchar(20),
	xOrganizationName varchar(120),
	xOrganization varchar(16) for bit data,
	xDepartment varchar(120),
	xPositionHeld varchar(120),
	xCommenced date,
	xAnnualSallary decimal(21,6),
	xSallaryCurrency varchar(3),
	xNotes varchar(500),
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xApproved timestamp,
	xApprovedBy varchar(16) for bit data,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xInterestSetting
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xEffectiveBy date not null with default,
	xType varchar(10) not null,
	xInterestBase varchar(16) for bit data,
	xMethod varchar(10) not null,
	xFrequency varchar(11),
	xOnBalance varchar(13),
	xInterestRate decimal(16,6),
	xOffset decimal(16,6),
	xInterestYear varchar(9),
	xGraceDays int,
	xMinimumBalanceToPayInterest decimal(21,6),
	xLimitFee decimal(10,5),
	xMinimumLimitFee decimal(21,6),
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xApproved timestamp,
	xApprovedBy varchar(16) for bit data,
	xStatus varchar(8) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xDueDiligenceSourceOfFund
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xContact varchar(16) for bit data not null,
	xEntryDate date not null with default,
	xAmountFrom decimal(21,6) not null,
	xAmountTo decimal(21,6) not null,
	xCurrency varchar(3) not null,
	xSource varchar(16) for bit data not null,
	xNotes varchar(500),
	xSuspended char(1) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xApproved timestamp,
	xApprovedBy varchar(16) for bit data,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xProductInterestPayable_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xProductInterestPayable varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xProductInterestPayable, xStatusChange)
);

create table xProductInterestPayable
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xInterestFrequency varchar(11) not null,
	xOnBalance varchar(10) not null,
	xPaymentDay varchar(22),
	xInterestScheme varchar(16) for bit data,
	xNumberOfDays int,
	xCurrency varchar(3),
	xCurrencyRateType varchar(16) for bit data,
	xMinimumInterest decimal(21,6),
	xMaximumInterest decimal(21,6),
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xProductInterestRec_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xProductInterestReceivable varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xProductInterestReceivable, xStatusChange)
);

create table xProductInterestReceivable
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xInterestFrequency varchar(11),
	xOnBalance varchar(10),
	xInterestSchemeAuthorised varchar(16) for bit data,
	xInterestSchemeUnAuthorised varchar(16) for bit data,
	xCurrency varchar(3),
	xCurrencyRateType varchar(16) for bit data,
	xMinimumInterest decimal(21,6),
	xMaximumInterest decimal(21,6),
	xStatus varchar(8) not null,
	xPrincipalOverDueScheme varchar(16) for bit data,
	xInterestOverDueScheme varchar(16) for bit data,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xProductProfileGLCurrencyLink
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xProductProfile varchar(6),
	xLoanProduct varchar(6),
	xCurrency varchar(3) not null,
	xMinimumBalance decimal(21,6),
	xMinimumAmount decimal(21,6),
	xMaximumAmount decimal(21,6),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xTermBand_StatusChanges_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xTermBand varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xTermBand, xStatusChange)
);

create table xTermBand
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xFromTermDays int not null,
	xToTermDays int not null,
	xInterestScheme varchar(16) for bit data not null,
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xProduct_InterestPayables_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xProduct varchar(6) not null,
	xProductInterestPayable varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xProduct, xProductInterestPayable)
);

create table xProduct_InterestRec_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xProduct varchar(6) not null,
	xProductInterestReceivable varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xProduct, xProductInterestReceivable)
);

create table xProduct_Branches_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xProduct varchar(6) not null,
	xBranch varchar(10) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xProduct, xBranch)
);

create table xProduct_TransactionCodes_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xProduct varchar(6) not null,
	xTransactionCode varchar(4) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xProduct, xTransactionCode)
);

create table xProduct_Clients_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xProduct varchar(6) not null,
	xClient varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xProduct, xClient)
);

create table xProduct_Offerings_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xProduct varchar(6) not null,
	xOffering varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xProduct, xOffering)
);

create table xProduct_TermBands_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xProduct varchar(6) not null,
	xTermBand varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xProduct, xTermBand)
);

create table xProduct
(
	xMasterId int not null,
	xEntityId int not null,
	xCode varchar(6) not null,
	xType varchar(16) not null,
	xDescription varchar(120) not null,
	xAllowPersonal char(1) not null,
	xAllowOrganisation char(1) not null,
	xAllowJoint char(1) not null,
	xAllowEmployee char(1) not null,
	xSuspended char(1) not null,
	xIBANGenerationRequired char(1),
	xNumberOfGraceDays int,
	xMasterGL varchar(12) not null,
	xTaxWithHeld varchar(12),
	xAgentCommission varchar(12),
	xMasterLegDBGL varchar(4) not null,
	xMasterLegCRGL varchar(4) not null,
	xInterestAccruedDBGL varchar(4),
	xInterestAccruedCRGL varchar(4),
	xInterestAdjustmentDBGL varchar(4),
	xInterestAdjustmentCRGL varchar(4),
	xTaxWithheldDBClient varchar(4),
	xTaxWithheldCRGL varchar(4),
	xTaxWithheldDBGL varchar(4),
	xCommissionExpensesDBGL varchar(4),
	xCommissionExpensesCRClient varchar(4),
	xFromClientAccountDBClient varchar(4),
	xToClientAccountCRClient varchar(4),
	xStatementFormat varchar(16) for bit data not null,
	xCommunicationMode varchar(16) not null,
	xFrequency varchar(14) not null,
	xGenerateOnMovement char(1) not null,
	xAccountOpeningCommission varchar(16) for bit data,
	xAccountManagementCommission varchar(16) for bit data,
	xSelectedTransactionCode char(1) not null,
	xSelectedBranch char(1) not null,
	xSelectedClient char(1) not null,
	xSelectedOffering char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCode)
);

create table xProductProfile
(
	xMasterId int not null,
	xEntityId int not null,
	xCode varchar(6) not null,
	xAccountDormancyDays int,
	xOverdraftAllowed char(1) not null,
	xMinimumTermDays int,
	xMaximumTermDays int,
	xInterestPayoutMode varchar(17),
	xMaturityInstruction varchar(26),
	xRollOverWithGracePeriod char(1),
	xBalanceCheck varchar(22),
	xAccountOpeningFee varchar(16) for bit data,
	xServiceChargeAmount varchar(16) for bit data,
	xServiceChargePercentage varchar(16) for bit data,
	xNonOperationFee varchar(16) for bit data,
	xAccountClosingFee varchar(16) for bit data,
	xStatementFee varchar(16) for bit data,
	xAdditionalStatementFee varchar(16) for bit data,
	xInterestPaid varchar(12),
	xInterestEarned varchar(12),
	xInterestAccruedPayable varchar(12),
	xInterestAccruedReceivable varchar(12),
	xInterestAdjustmentIncome varchar(12),
	xInterestAdjustmentExpense varchar(12),
	xDepositMaturedPayableGL varchar(12),
	xPayoutGL varchar(12),
	xDepositOpeningReceivableGL varchar(12),
	xPrematurePenaltyGL varchar(12),
	xInterestPaidDBGL varchar(4),
	xInterestPaidCRClient varchar(4),
	xInterestPaidCRGL varchar(4),
	xInterestReceivedDBClient varchar(4),
	xInterestReceivedCRGL varchar(4),
	xDepositOpeningReceivableDBGL varchar(4),
	xByCashDBGL varchar(4),
	xTermDepositClientAccCRClient varchar(4),
	xTermDepositAccountDBClient varchar(4),
	xDepositMaturedPayableCRGL varchar(4),
	xDepositMaturedPayableDBGL varchar(4),
	xByCashCRGL varchar(4),
	xPenaltyAmountCRGL varchar(4),
	xAccountClosureDBClient varchar(4),
	xAccountClosureCRClient varchar(4),
	xAccountClosureCRGL varchar(4),
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCode)
);

create table xLoanProduct
(
	xMasterId int not null,
	xEntityId int not null,
	xCode varchar(6) not null,
	xMinimumTermDays int,
	xMaximumTermDays int,
	xInterestEarned varchar(12),
	xInterestAccruedReceivable varchar(12),
	xInterestReceivedDBClient varchar(4),
	xInterestReceivedDBGL varchar(4),
	xInterestReceivedCRGL varchar(4),
	xInterestCalculationMethod varchar(9) not null,
	xCcyRateForDisbursement varchar(16) for bit data not null,
	xCcyRateForRepayment varchar(16) for bit data not null,
	xCcyRateForCharge varchar(16) for bit data not null,
	xPenalInterestEarnedGL varchar(12) not null,
	xPenalInterestAccruedGL varchar(12) not null,
	xSuspenseGL varchar(12) not null,
	xCashGL varchar(12) not null,
	xLoanDisbursementDBGLTxnCode varchar(4) not null,
	xLoanDisbursementCRGLTxnCode varchar(4) not null,
	xLoanDisbursementDBACTxnCode varchar(4) not null,
	xLoanDisbursementCRACTxnCode varchar(4) not null,
	xLoanPaymentDBACTxnCode varchar(4) not null,
	xLoanPaymentCRACTxnCode varchar(4) not null,
	xLoanPaymentDBGLTxnCode varchar(4) not null,
	xLoanPaymentCRGLTxnCode varchar(4) not null,
	xPenalIntAccruedDBGLTxnCode varchar(4) not null,
	xPenalIntAccruedCRGLTxnCode varchar(4) not null,
	xPenalIntReceivedDBACTxnCode varchar(4) not null,
	xPenalIntReceivedDBGLTxnCode varchar(4) not null,
	xPenalIntReceivedCRGLTxnCode varchar(4) not null,
	xProcessingFee varchar(16) for bit data,
	xServiceCharge varchar(16) for bit data,
	xDocumentationCharge varchar(16) for bit data,
	xLegalCharge varchar(16) for bit data,
	xPrePaymentCharge varchar(16) for bit data,
	xInstallmentFee varchar(16) for bit data,
	xLatePaymentFee varchar(16) for bit data,
	xNPLDays int,
	xNPLAmountToBeMoved varchar(12),
	xNPLLedger varchar(12),
	xStopAccrual char(1) not null,
	xStatementFee varchar(16) for bit data,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCode)
);

create table xProductAdditionalCharge
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xProductProfile varchar(6),
	xCharge varchar(16) for bit data not null,
	xDescription varchar(120) not null,
	xChargeId int,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xTermDepositStatus_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xTermDepositStatus varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xTermDepositStatus, xStatusChange)
);

create table xTermDepositStatus
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xStatus varchar(15) not null,
	xReason varchar(500),
	xRecordStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xTermDepositSetting_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xTermDepositSetting varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xTermDepositSetting, xStatusChange)
);

create table xTermDepositSetting
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xFundingMethod varchar(24) not null,
	xFromClient varchar(16) for bit data,
	xFromAccount varchar(34),
	xFromLedger varchar(12),
	xFromBank varchar(16) for bit data,
	xFromBankName varchar(120),
	xFromBranch varchar(120),
	xBICCode varchar(11),
	xBankClearingCode varchar(20),
	xInterestPaymentOption varchar(17) not null,
	xInterestPayoutMethod varchar(22),
	xToClient varchar(16) for bit data,
	xToAccount varchar(34),
	xToBank varchar(16) for bit data,
	xToBankName varchar(120),
	xToBranch varchar(120),
	xToBICCode varchar(11),
	xToBankClearingCode varchar(20),
	xMaturityInstruction varchar(26) not null,
	xRollOverAmount decimal(21,6),
	xRollOverWithGracePeriod char(1),
	xGraceDays int,
	xMaturityPayoutMethod varchar(22) not null,
	xPayoutClient varchar(16) for bit data,
	xPayoutAccount varchar(34) not null,
	xPayoutBank varchar(16) for bit data,
	xPayoutBankName varchar(120),
	xPayoutBranch varchar(120),
	xPayoutBICCode varchar(11),
	xPayoutBankClearingCode varchar(20),
	xStatus varchar(8) not null,
	xAdded date not null with default,
	xAddedBy varchar(16) for bit data not null,
	xUpdated timestamp not null with default,
	xUpdatedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xBlockedAmount_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xBlockedAmount varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xBlockedAmount, xStatusChange)
);

create table xBlockedAmount
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xCurrency varchar(3) not null,
	xRateType varchar(16) for bit data,
	xAmountBlocked decimal(21,6) not null,
	xAmount decimal(21,6) not null,
	xAmountBlockedId int,
	xCategory varchar(16) for bit data not null,
	xReason varchar(500),
	xEffectiveDate date not null with default,
	xExpiryDate date,
	xStatus varchar(8) not null,
	xBlockStatus varchar(9) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xStatement
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xFormat varchar(16) for bit data not null,
	xName varchar(120),
	xCommunicationMode varchar(16) not null,
	xFrequency varchar(14) not null,
	xStatementId int,
	xGenerateOnAccountActivity char(1),
	xStatementFee varchar(16) for bit data,
	xLastStatementDate date,
	xLastStatementNumber int,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xTermDepositInterest_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xTermDepositInterest varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xTermDepositInterest, xStatusChange)
);

create table xTermDepositInterest
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xMethod varchar(8) not null,
	xInterestBase varchar(16) for bit data,
	xOffset decimal(16,6),
	xRate decimal(16,6),
	xApplicableRate decimal(16,6) not null,
	xFrequency varchar(11) not null,
	xOnBalance varchar(10) not null,
	xPaymentDay varchar(22),
	xNumberOfDays int,
	xCurrency varchar(3),
	xCurrencyRateType varchar(16) for bit data,
	xMinimumInterest decimal(21,6),
	xMaximumInterest decimal(21,6),
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xUpdated timestamp not null with default,
	xUpdatedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xDueDiligenceBankDetails
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xContact varchar(16) for bit data not null,
	xBankName varchar(120) not null,
	xAccountNumber varchar(34),
	xAccountOpeningDate date,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xDueDiligenceVerification
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xContact varchar(16) for bit data not null,
	xPoliticallyExposedPerson char(1) not null,
	xNumberOfEmployees int,
	xBankrupted char(1) not null,
	xNotes varchar(500),
	xAMLChecked char(1) not null,
	xAMLStatus varchar(8),
	xPersonNonGrata char(1) not null,
	xAMLNotes varchar(500),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xExternalProductMapping
(
	xMasterId int not null,
	xEntityId int not null,
	xCode varchar(6) not null,
	xDescription varchar(125) not null,
	xExternalSystem varchar(16) for bit data not null,
	xAvailable char(1) not null,
	xProductDescription varchar(255),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCode)
);

create table xTermDepositRedemption_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xTermDepositRedemption varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xTermDepositRedemption, xStatusChange)
);

create table xTermDepositRedemption
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xClient varchar(16) for bit data not null,
	xAccountNumber varchar(16) for bit data not null,
	xCurrentBalance decimal(21,6) not null,
	xInterestPayableAccrued decimal(21,6) not null,
	xBlockedAmount decimal(21,6) not null,
	xAvailableBalance decimal(21,6) not null,
	xRedemptionOption varchar(7) not null,
	xRedemptionAmount decimal(21,6) not null,
	xPenaltyOption varchar(6) not null,
	xPenaltyAmount decimal(21,6),
	xAccrualAmount decimal(21,6),
	xPayableAmount decimal(21,6) not null,
	xPaymentOption varchar(22) not null,
	xToClient varchar(16) for bit data,
	xToExternalAccount varchar(34),
	xToInternalAccount varchar(16) for bit data,
	xToBranch varchar(120),
	xToBank varchar(16) for bit data,
	xBankName varchar(120),
	xDepositMaturedPayableGL varchar(12),
	xBICCode varchar(11),
	xBankClearingCode varchar(20),
	xRedemptionDate date not null with default,
	xStatus varchar(8) not null,
	xAdded date not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xAccruedInterest
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xAccount varchar(16) for bit data not null,
	xEvent varchar(6) not null,
	xBookingDate date not null with default,
	xValueDate date not null with default,
	xDueDate date,
	xPrincipalAmount decimal(21,6),
	xInterestRate decimal(16,6),
	xInterestType varchar(32),
	xAccrualAmount decimal(23,10),
	xCumulativeAccrualAmount decimal(23,10) not null,
	xRoundedCumulativeAccrAmount decimal(21,6) not null,
	xAccruedAmount decimal(21,6) not null,
	xTransactionRefNo varchar(16) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xAccruedInterestAdjustment
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xAccruedInterest varchar(16) for bit data not null,
	xBookingDate date not null with default,
	xValueDate date not null with default,
	xPrincipalAmount decimal(21,6) not null,
	xInterestRate decimal(16,6) not null,
	xAccrualAmount decimal(23,10) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xManualInterestAccrAdjustment
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xAccount varchar(16) for bit data not null,
	xEvent varchar(6) not null,
	xBookingDate date not null with default,
	xValueDate date not null with default,
	xPrincipalAmount decimal(21,6),
	xInterestRate decimal(16,6),
	xAccruedAmount decimal(21,6) not null,
	xTransactionRefNo varchar(16) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xAccountEventLog
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xAccount varchar(16) for bit data not null,
	xAccountBranch varchar(10) not null,
	xModuleId varchar(2) not null,
	xEventMaster varchar(16) for bit data not null,
	xAdditionalCharge varchar(16) for bit data,
	xBlockedAmount varchar(16) for bit data,
	xStatement varchar(16) for bit data,
	xEvent varchar(6) not null,
	xValueDate date not null with default,
	xBookDate date,
	xTransactionRefNo varchar(20),
	xStatus varchar(7),
	xAmount decimal(21,6),
	xReason varchar(500),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xEventMaster
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xModuleId varchar(2) not null,
	xEvent varchar(6) not null,
	xDescription varchar(120) not null,
	xEventType varchar(3) not null,
	xChargeEvent char(1) not null,
	xAccounting char(1) not null,
	xEventBatchTrigger varchar(6) not null,
	xView char(1) not null,
	xEOCOperations varchar(3),
	xPredecessorEvent varchar(6),
	xSuccessorEvent varchar(6),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xAccount_Statement_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xAccount varchar(16) for bit data not null,
	xStatement varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xAccount, xStatement)
);

create table xAccount
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xAccountNumber varchar(34),
	xBranch varchar(10) not null,
	xCurrency varchar(3) not null,
	xCurrentBalance decimal(21,6) not null,
	xIBAN varchar(34),
	xOldAccountNumber varchar(34),
	xChannel varchar(16) for bit data not null,
	xGenerateAccountNumber varchar(19) not null,
	xAccountName varchar(120),
	xAccountUsage varchar(120),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);
create unique index IX_AccountNumber on xAccount(xMasterId, xEntityId, xAccountNumber);

create table xTDAccount_Settings_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xTermDepositAccount varchar(16) for bit data not null,
	xTermDepositSetting varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xTermDepositAccount, xTermDepositSetting)
);

create table xTDAccount_Interest_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xTermDepositAccount varchar(16) for bit data not null,
	xTermDepositInterest varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xTermDepositAccount, xTermDepositInterest)
);

create table xTDAccount_BlockedAmounts_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xTermDepositAccount varchar(16) for bit data not null,
	xBlockedAmount varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xTermDepositAccount, xBlockedAmount)
);

create table xTDAccount_Status_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xTermDepositAccount varchar(16) for bit data not null,
	xTermDepositStatus varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xTermDepositAccount, xTermDepositStatus)
);

create table xTermDepositAccount
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xClient varchar(16) for bit data not null,
	xProduct varchar(6) not null,
	xAmountOfDeposit decimal(21,6) not null,
	xRollOverCount int not null,
	xBlockedAmount decimal(21,6) not null,
	xInterestPaid decimal(21,6) not null,
	xInterestPayableAccrued decimal(21,6) not null,
	xLastInterestPaidDate date,
	xBookDate date not null with default,
	xValueDate date not null with default,
	xTerm int not null,
	xMaturityDate date not null with default,
	xAgreementNumber varchar(20),
	xAccountStatus varchar(15) not null,
	xRecordStatus varchar(8) not null,
	xActionStatus varchar(8) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xClientAcc_BlockedAmount_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xClientAccount varchar(16) for bit data not null,
	xBlockedAmount varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xClientAccount, xBlockedAmount)
);

create table xClientAcc_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xClientAccount varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xClientAccount, xStatusChange)
);

create table xClientAccount
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xClient varchar(16) for bit data not null,
	xProduct varchar(6) not null,
	xInProcess decimal(21,6) not null,
	xBlockedAmount decimal(21,6) not null,
	xInterestPaid decimal(21,6) not null,
	xInterestPayableAccrued decimal(21,6) not null,
	xLastInterestPaidDate date,
	xInterestReceived decimal(21,6) not null,
	xInterestReceivableAccrued decimal(21,6) not null,
	xLastInterestReceivedDate date,
	xStatus varchar(9) not null,
	xRecordStatus varchar(8),
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xStatementGenerationLog
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xAccount varchar(16) for bit data not null,
	xBranch varchar(10) not null,
	xModuleId varchar(2) not null,
	xStatement varchar(16) for bit data not null,
	xStatementNumber int not null,
	xDateFrom date not null with default,
	xDateTo date not null with default,
	xGenerationDate date,
	xGenerated char(1),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xExternalTransfer_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xExternalTransfer varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xExternalTransfer, xStatusChange)
);

create table xExternalTransfer
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xCRNAccount varchar(34) not null,
	xModuleId varchar(2) not null,
	xTransactionRefNo varchar(16) not null,
	xGLCurrency varchar(3) not null,
	xAmount decimal(21,6) not null,
	xLedger varchar(12) not null,
	xValueDate date not null with default,
	xBookDate date,
	xOutgoing char(1) not null,
	xBranch varchar(120) not null,
	xAccount varchar(34) not null,
	xBankName varchar(120) not null,
	xBankIdentifierCode varchar(11),
	xBankClearingCode varchar(20),
	xPaymentRefNo varchar(16),
	xTransactionDate date,
	xAmountTransfered decimal(21,6),
	xStatus varchar(8),
	xRemarks varchar(500),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xPaymentTransaction_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xPaymentTransaction varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xPaymentTransaction, xStatusChange)
);

create table xPaymentTransaction
(
	xMasterId int not null,
	xEntityId int not null,
	xPaymentReferenceNumber varchar(16) for bit data not null,
	xPGReferenceNumber varchar(35) not null,
	xUserReferenceNumber varchar(35),
	xBookingDate date,
	xValueDate date,
	xPaymentDate date,
	xClient varchar(16) for bit data,
	xCreditBranch varchar(10),
	xCreditAccount varchar(16) for bit data,
	xDebitBranch varchar(10),
	xDebitAccount varchar(16) for bit data,
	xAccountCurrency varchar(3),
	xTransactionCurrency varchar(3),
	xTransactionAmount decimal(21,6),
	xTxnAmountInAccountCCY decimal(21,6),
	xExchangeRate decimal(16,6),
	xChargeAccount varchar(16) for bit data,
	xLastEvent varchar(6),
	xTransactionStatus varchar(20),
	xChannel varchar(16) for bit data,
	xNetwork varchar(12),
	xCreditProcessingDate date,
	xMessageDispatchDate date,
	xOrderingCustomer1 varchar(35),
	xOrderingCustomer2 varchar(35),
	xOrderingCustomer3 varchar(35),
	xOrderingCustomer4 varchar(35),
	xOrderingCustomer5 varchar(35),
	xOrderingInstitution1 varchar(35),
	xOrderingInstitution2 varchar(35),
	xOrderingInstitution3 varchar(35),
	xOrderingInstitution4 varchar(35),
	xOrderingInstitution5 varchar(35),
	xBeneficiaryDetails1 varchar(35),
	xBeneficiaryDetails2 varchar(35),
	xBeneficiaryDetails3 varchar(35),
	xBeneficiaryDetails4 varchar(35),
	xBeneficiaryDetails5 varchar(35),
	xRemittanceInformation1 varchar(35),
	xRemittanceInformation2 varchar(35),
	xRemittanceInformation3 varchar(35),
	xRemittanceInformation4 varchar(35),
	xChargeBearer varchar(3),
	xBeneficiaryBank1 varchar(35),
	xBeneficiaryBank2 varchar(35),
	xBeneficiaryBank3 varchar(35),
	xBeneficiaryBank4 varchar(35),
	xBeneficiaryBank5 varchar(35),
	xSendersCorrespondent1 varchar(35),
	xSendersCorrespondent2 varchar(35),
	xSendersCorrespondent3 varchar(35),
	xSendersCorrespondent4 varchar(35),
	xSendersCorrespondent5 varchar(35),
	xReceiverCorrespondent1 varchar(35),
	xReceiverCorrespondent2 varchar(35),
	xReceiverCorrespondent3 varchar(35),
	xReceiverCorrespondent4 varchar(35),
	xReceiverCorrespondent5 varchar(35),
	xReasonForPayment varchar(35),
	xSenderToReceiverInformation1 varchar(35),
	xSenderToReceiverInformation2 varchar(35),
	xSenderToReceiverInformation3 varchar(35),
	xSenderToReceiverInformation4 varchar(35),
	xSenderToReceiverInformation5 varchar(35),
	xSenderToReceiverInformation6 varchar(35),
	xIntermediary1 varchar(35),
	xIntermediary2 varchar(35),
	xIntermediary3 varchar(35),
	xIntermediary4 varchar(35),
	xIntermediary5 varchar(35),
	xAccountWithInst1 varchar(35),
	xAccountWithInst2 varchar(35),
	xAccountWithInst3 varchar(35),
	xAccountWithInst4 varchar(35),
	xAccountWithInst5 varchar(35),
	xPriority varchar(6),
	xErrorReason varchar(150),
	xAMLVerified varchar(1),
	xPDECheck char(1),
	xCoverFlag varchar(16),
	xMessageSent char(1),
	xIsWalkin char(1),
	xPGProduct varchar(10),
	xPaymentSetting varchar(6),
	xPaymentType varchar(8),
	xAbaRouting varchar(9),
	xBankCode varchar(20),
	xBranchCode varchar(6),
	xSortCode varchar(6),
	xCutoffTime varchar(22),
	xMessageType varchar(8),
	xConfirmNostro char(1),
	xAuthorizeAfterBook char(1),
	xAuthorizeAfterDebit char(1),
	xAction varchar(9),
	xStatus varchar(12),
	xBeneficiary varchar(8) not null,
	xBank varchar(8) not null,
	xAddToBeneficiaryList char(1),
	xOriginatorIDType varchar(4),
	xOriginatorIDNumber varchar(32),
	xBeneficiaryIDType varchar(4),
	xBeneficiaryIDNumber varchar(32),
	xCategoryPurposeCode varchar(4),
	xUniqueOriginatorReference varchar(35),
	xCreditorReference varchar(35),
	xAdded timestamp,
	xAddedBy varchar(16) for bit data,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xPaymentReferenceNumber)
);

create table xPaymentTransactionCharge
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xPaymentReferenceNumber varchar(16) for bit data not null,
	xBookingDate date not null with default,
	xValueDate date,
	xPaymentDate date,
	xClient varchar(16) for bit data not null,
	xLastEvent varchar(6) not null,
	xAction varchar(9) not null,
	xChargeScheme varchar(16) for bit data,
	xChargeAmount decimal(21,6) not null,
	xChargeCurrency varchar(3) not null,
	xChargeAccountCurrency varchar(3) not null,
	xChargeAmountInAcctCCY decimal(21,6) not null,
	xExchangeRate decimal(16,6),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xPaymentTrxnClientTransaction
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xPaymentReferenceNumber varchar(16) for bit data not null,
	xAccountingRefNumber bigint not null,
	xPaymentEvent varchar(6) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xPaymentTrxnGLTransaction
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xPaymentReferenceNumber varchar(16) for bit data not null,
	xAccountingRefNumber bigint not null,
	xPaymentEvent varchar(6) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xPaymentTrxnChargeClientTrxn
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xPaymentTrxnChargeId varchar(16) for bit data not null,
	xAccountingRefNumber bigint not null,
	xPaymentEvent varchar(6) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xPaymentTrxnChargeGLTrxn
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xPaymentTrxnChargeId varchar(16) for bit data not null,
	xAccountingRefNumber bigint not null,
	xPaymentEvent varchar(6) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xTermDepositPersonLink
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xTermDepositAccount varchar(16) for bit data not null,
	xPersonRole varchar(16) for bit data,
	xPerson varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xClientAccountPersonLink
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xClientAccount varchar(16) for bit data not null,
	xPerson varchar(16) for bit data not null,
	xPersonRole varchar(16) for bit data,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xAccountSignatory
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xGroup varchar(5) not null,
	xOperatingInstruction varchar(7) not null,
	xLimit decimal(21,6) not null,
	xNotes varchar(500),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCASignatoryy_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xClientAccountSignatoryy varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xClientAccountSignatoryy, xStatusChange)
);

create table xClientAccountSignatoryy
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xAccount varchar(16) for bit data not null,
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xUpdated timestamp not null with default,
	xUpdatedBy varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xTDASignatory_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xTermDepositAccountSignatory varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xTermDepositAccountSignatory, xStatusChange)
);

create table xTermDepositAccountSignatory
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xAccount varchar(16) for bit data not null,
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xUpdated timestamp not null with default,
	xUpdatedBy varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCASignatoryPersonLnk_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xClientAccountSigPersonLink varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xClientAccountSigPersonLink, xStatusChange)
);

create table xClientAccountSigPersonLink
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xClientAccountSignatoryy varchar(16) for bit data not null,
	xPerson varchar(16) for bit data not null,
	xNotes varchar(500),
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xTDSignatoryPersonLnk_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xTermDepositSigPersonLink varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xTermDepositSigPersonLink, xStatusChange)
);

create table xTermDepositSigPersonLink
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xTermDepositAccountSignatory varchar(16) for bit data not null,
	xPerson varchar(16) for bit data not null,
	xNotes varchar(500),
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xPaymentSetting_Branch_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xPaymentSetting varchar(6) not null,
	xBranch varchar(10) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xPaymentSetting, xBranch)
);

create table xPaymentSetting
(
	xMasterId int not null,
	xEntityId int not null,
	xCode varchar(6) not null,
	xDescription varchar(120) not null,
	xSettlementType varchar(5) not null,
	xPaymentType varchar(20) not null,
	xProcessOnlyOnRateUpdate char(1),
	xMatchBeneficiaryName char(1),
	xCurrencyRateType varchar(16) for bit data not null,
	xTransitLedger varchar(12),
	xInvestigationLedger varchar(12),
	xRepairLedger varchar(12),
	xClearingSettlementLedger varchar(12),
	xDebitProcessingClientDb varchar(4),
	xDebitProcessingGLDb varchar(4),
	xSystemDebitGLDb varchar(4),
	xSystemCreditGLCr varchar(4),
	xClientProcessingClientCr varchar(4),
	xClientProcessingGLCr varchar(4),
	xBENChargeTypeGLDb varchar(4),
	xSettlementProcessingClientCr varchar(4),
	xAMLRejectionClientCr varchar(4),
	xAMLRejectionGLCr varchar(4),
	xReversalClientDb varchar(4),
	xReversalGLDb varchar(4),
	xReversalClientCr varchar(4),
	xReversalGLCr varchar(4),
	xCancellationClientDb varchar(4),
	xCancellationGLDb varchar(4),
	xCancellationClientCr varchar(4),
	xCancellationGLCr varchar(4),
	xTransactionCharge varchar(16) for bit data,
	xAdviceCharge varchar(16) for bit data,
	xSuspended char(1) not null,
	xSelectedBranch char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCode)
);

create table xRLAccount_Setting_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xRetailLoanAccount varchar(16) for bit data not null,
	xRetailLoanAccSetting varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xRetailLoanAccount, xRetailLoanAccSetting)
);

create table xRLAccount_PaymentSettings_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xRetailLoanAccount varchar(16) for bit data not null,
	xRLAccountPaymentSetting varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xRetailLoanAccount, xRLAccountPaymentSetting)
);

create table xRLAccount_Interest_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xRetailLoanAccount varchar(16) for bit data not null,
	xRetailLoanAccountInterest varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xRetailLoanAccount, xRetailLoanAccountInterest)
);

create table xRLAccount_ASC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xRetailLoanAccount varchar(16) for bit data not null,
	xRetailLoanAccountStatus varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xRetailLoanAccount, xRetailLoanAccountStatus)
);

create table xRetailLoanAccount_Charges_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xRetailLoanAccount varchar(16) for bit data not null,
	xRLAccountCharges varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xRetailLoanAccount, xRLAccountCharges)
);

create table xRetailLoanAccount
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xClient varchar(16) for bit data not null,
	xProduct varchar(6) not null,
	xOriginBranch varchar(10) not null,
	xAmountSanctioned decimal(21,6) not null,
	xChooseLoanTermBy varchar(13) not null,
	xDaysOrMonthsOrYear varchar(6) not null,
	xTenor int not null,
	xMaturityDate date,
	xValueDate date not null with default,
	xDisbursementCurrency varchar(3),
	xAmountDisbursed decimal(21,6) not null,
	xInstallmentAmount decimal(21,6) not null,
	xInterestReceivableAccrued decimal(21,6) not null,
	xPrincipalOverdue decimal(21,6) not null,
	xInterestOverdue decimal(21,6) not null,
	xAgreementNumber varchar(60),
	xAccountStatus varchar(9) not null,
	xRecordStatus varchar(8) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xRetailLoanAccSetting
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xDisbursementCurrency varchar(3) not null,
	xDisbursementOption varchar(6) not null,
	xDisburseThroughMethod varchar(16) not null,
	xToLedger varchar(12) not null,
	xToClient varchar(16) for bit data,
	xToAccount varchar(34),
	xToBank varchar(16) for bit data,
	xToBankName varchar(120),
	xToBranch varchar(120),
	xToBICCode varchar(11),
	xToBankClearingCode varchar(20),
	xRePaymentOption varchar(6) not null,
	xRepayThroughMethod varchar(16) not null,
	xFromLedger varchar(12) not null,
	xFromClient varchar(16) for bit data,
	xFromAccount varchar(34),
	xFromBank varchar(16) for bit data,
	xFromBankName varchar(120),
	xFromBranch varchar(120),
	xFromBICCode varchar(11),
	xFromBankClearingCode varchar(20),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xRLAPayementStatus_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xRLAccountPaymentSetting varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xRLAccountPaymentSetting, xStatusChange)
);

create table xRLAccountPaymentSetting
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xPaymentFrequency varchar(10) not null,
	xFirstPaymentDate date not null with default,
	xFirstAnnuityPaymentDate date,
	xUserDefinedPaymentAmount decimal(21,6),
	xNumberOfInterestPayments int,
	xPrincipalPaymentFrequency varchar(10),
	xFirstPrincipalPaymentDate date,
	xNumberOfPrincipalPayments int,
	xPrincipalPaymentAmount decimal(21,6),
	xGraceDaysForPenalty int not null,
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xRLAccountInterest_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xRetailLoanAccountInterest varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xRetailLoanAccountInterest, xStatusChange)
);

create table xRetailLoanAccountInterest
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xLoanInterestScheme varchar(16) for bit data not null,
	xLoanInterestBase varchar(16) for bit data,
	xLoanInterestRate decimal(9,6) not null,
	xLoanMargin decimal(9,6) not null,
	xPrincipalOverdueScheme varchar(16) for bit data,
	xPrincipalOverdueBase varchar(16) for bit data,
	xPrincipalOverdueRate decimal(9,6),
	xPrincipalOverdueMargin decimal(9,6) not null,
	xInterestOverdueScheme varchar(16) for bit data,
	xInterestOverdueBase varchar(16) for bit data,
	xInterestOverdueRate decimal(9,6),
	xInterestOverdueMargin decimal(9,6) not null,
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xRLAccountStatus_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xRetailLoanAccountStatus varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xRetailLoanAccountStatus, xStatusChange)
);

create table xRetailLoanAccountStatus
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xAccountStatus varchar(9) not null,
	xReason varchar(500),
	xRecordStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xFXProduct_Currency_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xFXProduct varchar(6) not null,
	xGLCurrency varchar(3) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xFXProduct, xGLCurrency)
);

create table xFXProduct_Setting_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xFXProduct varchar(6) not null,
	xFXProductSetting varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xFXProduct, xFXProductSetting)
);

create table xFXProduct
(
	xMasterId int not null,
	xEntityId int not null,
	xCode varchar(6) not null,
	xFxType varchar(7) not null,
	xInterBankClient varchar(9) not null,
	xBuyGL varchar(12) not null,
	xSellGL varchar(12) not null,
	xUnrealisedProfitGL varchar(12) not null,
	xUnrealisedLossGL varchar(12) not null,
	xFXConsolidationProfitGL varchar(12) not null,
	xFXConsolidationLossGL varchar(12) not null,
	xRealisedProfitGL varchar(12) not null,
	xRealisedLossGL varchar(12) not null,
	xFXSettlementBridgeGL varchar(12) not null,
	xBuyDBGL varchar(4) not null,
	xBuyCRGL varchar(4) not null,
	xSellDBGL varchar(4) not null,
	xSellCRGL varchar(4) not null,
	xFXConsolidationProfitCRGL varchar(4) not null,
	xFXConsolidationLossDBGL varchar(4) not null,
	xUnrealizedProfitDBGL varchar(4) not null,
	xUnrealizedLossCRGL varchar(4) not null,
	xFXSettlementCRGL varchar(4) not null,
	xFXSettlementDBGL varchar(4) not null,
	xFXSettlementbridgeCRGL varchar(4) not null,
	xFXSettlementbridgeDBGL varchar(4) not null,
	xFXSettlementCRClient varchar(4) not null,
	xFXSettlementDBClient varchar(4) not null,
	xRealisedProfitCRGL varchar(4) not null,
	xRealisedLossDBGL varchar(4) not null,
	xBookingFee varchar(16) for bit data,
	xNonSettlementFee varchar(16) for bit data,
	xBrokerCommission varchar(16) for bit data,
	xSelectedCurrency char(1) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCode)
);

create table xFXProductSetting_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xFXProductSetting varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xFXProductSetting, xStatusChange)
);

create table xFXProductSetting
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xFXProduct varchar(6) not null,
	xRealisedProfitLossRateType varchar(16) for bit data,
	xAllowedVariance decimal(9,6) not null,
	xSendPaymentMessageOn varchar(26) not null,
	xSplitValueDatesAllowed char(1) not null,
	xFxConsolidationMethod varchar(6) not null,
	xMaximumDaysAllowed int,
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xUpdated timestamp not null with default,
	xUpdatedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xRLAccountPaymentSchedule
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xAccount varchar(16) for bit data not null,
	xPaymentNumber int not null,
	xComponent varchar(28) not null,
	xDueAmount decimal(21,6) not null,
	xPaidAmount decimal(21,6) not null,
	xPaidDate date,
	xDueDate date,
	xUnpaidAmount decimal(21,6) not null,
	xOutstandingPrincipal decimal(21,6),
	xTransactionRefNo varchar(16),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xRLAccountCharges_Status_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xRLAccountCharges varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xRLAccountCharges, xStatusChange)
);

create table xRLAccountCharges
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xProcessingFee varchar(16) for bit data,
	xServiceCharge varchar(16) for bit data,
	xDocumentationCharge varchar(16) for bit data,
	xLegalCharge varchar(16) for bit data,
	xPrePaymentCharge varchar(16) for bit data,
	xInstallmentFee varchar(16) for bit data,
	xLatePaymentFee varchar(16) for bit data,
	xChargeAccount varchar(16) for bit data,
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xRLAccountRepayment_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xRetailLoanAccountRepayment varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xRetailLoanAccountRepayment, xStatusChange)
);

create table xRetailLoanAccountRepayment
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xAccount varchar(16) for bit data not null,
	xValueDate date not null with default,
	xBookingDate date not null with default,
	xChargeDue decimal(21,6) not null,
	xPenaltyOnInterestOD decimal(21,6) not null,
	xPenaltyOnPrincipalOD decimal(21,6) not null,
	xInterestOD decimal(21,6) not null,
	xPrincipalOverdue decimal(21,6) not null,
	xInterestDue decimal(21,6) not null,
	xPrincipalDue decimal(21,6) not null,
	xPrincipalPrepayment decimal(21,6) not null,
	xPaidCharge decimal(21,6) not null,
	xPaidPenaltyOnInterestOverdue decimal(21,6) not null,
	xPaidPenaltyOnPrincipalOverdue decimal(21,6) not null,
	xPaidInterestOverdue decimal(21,6) not null,
	xPaidPrincipalOverdue decimal(21,6) not null,
	xPaidInterestDue decimal(21,6) not null,
	xPaidPrincipalDue decimal(21,6) not null,
	xAmountPaid decimal(21,6) not null,
	xWaivedCharge decimal(21,6) not null,
	xWaivedPenaltyOnInterestOD decimal(21,6) not null,
	xWaivedPenaltyOnPrincipalOD decimal(21,6) not null,
	xPrepaymentChargeToBeCollected decimal(21,6) not null,
	xStatus varchar(8) not null,
	xTransactionRefNo varchar(16) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xRLAccountDisbursement_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xRetailLoanAccountDisbursement varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xRetailLoanAccountDisbursement, xStatusChange)
);

create table xRetailLoanAccountDisbursement
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xAccount varchar(16) for bit data not null,
	xValueDate date not null with default,
	xBookingDate date not null with default,
	xAmountDisbursed decimal(21,6) not null,
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xFXContract_Charge_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xFXContract varchar(16) for bit data not null,
	xFXContractCharge varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xFXContract, xFXContractCharge)
);

create table xFXContract_SI_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xFXContract varchar(16) for bit data not null,
	xFXContractSettlementInstn varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xFXContract, xFXContractSettlementInstn)
);

create table xFXContract_Status_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xFXContract varchar(16) for bit data not null,
	xFXContractStatus varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xFXContract, xFXContractStatus)
);

create table xFXContracts_AO_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xFXContract varchar(16) for bit data not null,
	xFXContractAlertsOverrides varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xFXContract, xFXContractAlertsOverrides)
);

create table xFXContract
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xContractRefNo varchar(16) not null,
	xOwnerBranch varchar(10) not null,
	xProduct varchar(6) not null,
	xCounterParty varchar(16) for bit data not null,
	xDealType varchar(4) not null,
	xBoughtCurrency varchar(3) not null,
	xSoldCurrency varchar(3) not null,
	xBookDate date not null with default,
	xBuyValueDate date not null with default,
	xSellValueDate date not null with default,
	xBaseRate decimal(16,6) not null,
	xDealRate decimal(21,6) not null,
	xBoughtAmount decimal(21,6) not null,
	xSoldAmount decimal(21,6) not null,
	xBuySettlementAmount decimal(21,6),
	xSellSettlementAmount decimal(21,6),
	xBuyOutstandingAmount decimal(21,6),
	xSellOutstandingAmount decimal(21,6),
	xBuySettlementDate date,
	xSellSettlementDate date,
	xDealer varchar(150),
	xAdditionalRefNo varchar(16),
	xContractStatus varchar(16) not null,
	xStatus varchar(8) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xFXCCStatus_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xFXContractCharge varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xFXContractCharge, xStatusChange)
);

create table xFXContractCharge
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xFXContract varchar(16) for bit data not null,
	xChargeAccountCurrency varchar(3) not null,
	xChargeClientAccount varchar(16) for bit data,
	xChargeGLAccount varchar(12),
	xBookingFee varchar(16) for bit data,
	xBookingFeeChargeCurrency varchar(3),
	xBookingFeeAmtInChargeCCY decimal(21,6),
	xBookingFeeAmtInAccountCCY decimal(21,6),
	xBrokerCommission varchar(16) for bit data,
	xBrokerCommissionChargeCCY varchar(3),
	xBrokerCommAmtInChargeCCY decimal(21,6),
	xBrokerCommissionAmtInAcctCCY decimal(21,6),
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xUpdated timestamp not null with default,
	xUpdatedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xFXCSStatus_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xFXContractSettlementInstn varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xFXContractSettlementInstn, xStatusChange)
);

create table xFXContractSettlementInstn
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xFXContract varchar(16) for bit data not null,
	xBoughtCurrency varchar(3) not null,
	xBoughtSettlementBy varchar(16) not null,
	xDebitClientAccount varchar(16) for bit data,
	xDebitGLAccount varchar(12),
	xSoldCurrency varchar(3) not null,
	xSoldSettlementBy varchar(16) not null,
	xCreditClientAccount varchar(16) for bit data,
	xCreditGLAccount varchar(12),
	xChargeClientAccount varchar(16) for bit data,
	xChargeGLAccount varchar(12),
	xBeneficiaryBIC varchar(16) for bit data,
	xAWIBIC varchar(16) for bit data,
	xBeneficiaryAccount varchar(34),
	xNettingRequired char(1) not null,
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xUpdated timestamp not null with default,
	xUpdatedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xFXCStatus_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xFXContractStatus varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xFXContractStatus, xStatusChange)
);

create table xFXContractStatus
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xFXContract varchar(16) for bit data not null,
	xReason varchar(120),
	xContractStatus varchar(16) not null,
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xUpdated timestamp not null with default,
	xUpdatedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xFXContractAlertsOverrides
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xFXContract varchar(16) for bit data not null,
	xDate date not null with default,
	xUser varchar(16) for bit data not null,
	xAlertOverrideMessage varchar(2000) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xFXContractClientTrxn
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xFXContract varchar(16) for bit data not null,
	xAccountingRefNumber bigint not null,
	xEvent varchar(6) not null,
	xReversed char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xFXContractGLTrxn
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xFXContract varchar(16) for bit data not null,
	xAccountingRefNumber bigint not null,
	xEvent varchar(6) not null,
	xReversed char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xFXContractChargeClientTrxn
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xFXContractCharge varchar(16) for bit data not null,
	xAccountingRefNumber bigint not null,
	xEvent varchar(6) not null,
	xReversed char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xFXContractChargeGLTrxn
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xFXContractCharge varchar(16) for bit data not null,
	xAccountingRefNumber bigint not null,
	xEvent varchar(6) not null,
	xReversed char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xFXManualSettlement_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xFXManualSettlement varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xFXManualSettlement, xStatusChange)
);

create table xFXManualSettlement
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xFXContract varchar(16) for bit data not null,
	xChargeCurrency varchar(3),
	xAmountInChargeCurrency decimal(21,6),
	xChargeClientAccount varchar(16) for bit data,
	xChargeGLAccount varchar(12),
	xAccountCurrency varchar(3),
	xAmountInAccountCurrency decimal(21,6),
	xOperation varchar(17) not null,
	xContractStatusToBeProcessed varchar(16) not null,
	xRemarks varchar(120),
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xSecurityTokenLog
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xSecurityToken varchar(16) for bit data not null,
	xEventDateTime timestamp not null with default,
	xEvent varchar(11) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xPhone
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xPhoneType varchar(16) for bit data not null,
	xPhoneNumber varchar(20) not null,
	xExtension varchar(6),
	xHandleSms char(1) not null,
	xNotes varchar(500),
	xInvalid char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xCountry
(
	xMasterId int not null,
	xAlpha3Code varchar(3) not null,
	xAlpha2Code varchar(2) not null,
	xNumericCode varchar(3) not null,
	xCountryName varchar(80) not null,
	xCapital varchar(60),
	xCurrency varchar(3),
	xLanguage varchar(2),
	xISDCode varchar(6),
	xRequireZipCode char(1) not null,
	xHideForCustomers char(1) not null,
	xPersonalTaxWithhold decimal(10,5) not null,
	xCorporateTaxWithhold decimal(10,5) not null,
	xMinimumPersonalTaxWithhold decimal(21,6) not null,
	xMinimumCorporateTaxWithhold decimal(21,6) not null,
	xSuspended char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xAlpha3Code)
);
create unique index IX_Alpha2Code on xCountry(xMasterId, xAlpha2Code);
create unique index IX_NumericCode on xCountry(xMasterId, xNumericCode);

create table xCustomField
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xName varchar(120) not null,
	xNotes varchar(500),
	xType varchar(6) not null,
	xSuspended char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xCustomFieldModuleLink
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xModule varchar(16) not null,
	xCustomField varchar(16) for bit data not null,
	xSuspended char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xCustomFieldData
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xCustomFieldModuleLink varchar(16) for bit data not null,
	xRecord varchar(60) not null,
	xValue varchar(250),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xDiary
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xEnteredDate timestamp not null with default,
	xEnteredBy varchar(16) for bit data not null,
	xDiaryType varchar(16) for bit data not null,
	xSubject varchar(120) not null,
	xDiaryText varchar(500) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xSICCode
(
	xMasterId int not null,
	xCode varchar(4) not null,
	xDescription varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xCode)
);

create table xDocumentType
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xGeographicZone_Countries_Lnk
(
	xMasterId int not null,
	xGeographicZone varchar(10) not null,
	xCountry varchar(3) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xGeographicZone, xCountry)
);

create table xGeographicZone
(
	xMasterId int not null,
	xCode varchar(10) not null,
	xDescription varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xCode)
);

create table xBankClearingNumber
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xSettlementDirectory varchar(16) for bit data not null,
	xBankCodeFrom varchar(20) not null,
	xBankCodeTo varchar(20) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xEmail
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xEmailType varchar(16) for bit data not null,
	xAddress varchar(100) not null,
	xInvalid char(1) not null,
	xNotes varchar(500),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xPersonRole
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(120) not null,
	xForCRM char(1) not null,
	xForAccounts char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xBinaryData
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xAESKey varchar(32) for bit data not null,
	xSize bigint not null,
	xMediaType varchar(100) not null,
	xMD5 varchar(32) not null,
	xName varchar(256),
	xClassifier varchar(50),
	xDate timestamp not null with default,
	xCreatedBy varchar(16) for bit data not null,
	xCreated timestamp not null with default,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xUserSession
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xUser varchar(16) for bit data not null,
	xActiveBranch varchar(10) not null,
	xSessionStart timestamp not null with default,
	xSessionActive char(1) not null,
	xLastActive timestamp not null with default,
	xNumberOfRequests int not null,
	xIpAddress varchar(15) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCurrencyRate
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xEffectiveBy timestamp not null with default,
	xMidRate decimal(16,6) not null,
	xFromCurrency varchar(3) not null,
	xToCurrency varchar(3) not null,
	xCurrencyRateType varchar(16) for bit data not null,
	xMultiplierOrDivisor varchar(10) not null,
	xActiveBranch varchar(10) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xApproved timestamp,
	xApprovedBy varchar(16) for bit data,
	xStatus varchar(8) not null,
	xBuySpread decimal(21,6) not null,
	xBuyRate decimal(16,6) not null,
	xSellSpread decimal(21,6) not null,
	xSellRate decimal(16,6) not null,
	xUnits int not null,
	xPropagateRate char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xEventLog
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xLevel varchar(11) not null,
	xEventDateTime timestamp not null with default,
	xSource varchar(120) not null,
	xMessage varchar(2000) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xSecurityToken
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xUser varchar(16) for bit data,
	xTokenProvider varchar(6) not null,
	xSerialNumber varchar(10) not null,
	xAuthenticationMode varchar(18) not null,
	xStatus varchar(9) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xUserPrivateKey
(
	xMasterId int not null,
	xUser varchar(16) for bit data not null,
	xUserIdKey varchar(16) for bit data not null,
	xPrivateKey blob not null,
	xPasswordHash varchar(32) for bit data not null,
	xSalt varchar(16) for bit data not null,
	xCreated timestamp not null with default,
	xGeneratedPassword char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xUserIdKey)
);

create table xCountryZipCode
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xCode varchar(10) not null,
	xCountry varchar(3) not null,
	xCountryRegion varchar(16) for bit data,
	xDescription varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xLanguage
(
	xMasterId int not null,
	xCode varchar(2) not null,
	xName varchar(60) not null,
	xSuspended char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xCode)
);

create table xPhoneType
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xPhoneType varchar(9) not null,
	xDescription varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);


create sequence SEQ_RequestLog as bigint start with 1 increment by 1;

create table xRequestLog
(
	xAutoId bigint not null,
	xMasterId int not null,
	xEntityId int not null,
	xServerName varchar(100) not null,
	xMethod varchar(10) not null,
	xUrl varchar(4000) not null,
	xResponseStatus int not null,
	xUser varchar(16) for bit data,
	xUserAccountSession varchar(16) for bit data,
	xDateTime timestamp not null with default,
	xDuration int not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xAutoId, xMasterId, xEntityId)
);

create table xDocument_BinaryDatas_Lnk
(
	xMasterId int not null,
	xDocument varchar(16) for bit data not null,
	xBinaryData varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xDocument, xBinaryData)
);

create table xDocument
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(50) not null,
	xType varchar(16) for bit data not null,
	xIdentification varchar(5),
	xCreatedBy varchar(16) for bit data not null,
	xCreated timestamp not null with default,
	xDocumentRefNumber varchar(32),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xAddress
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xAddressType varchar(16) for bit data not null,
	xAddress1 varchar(50) not null,
	xAddress2 varchar(50),
	xAddress3 varchar(50),
	xAddress4 varchar(50),
	xCity varchar(30) not null,
	xState varchar(30),
	xZip varchar(10),
	xPostbox varchar(30),
	xCountry varchar(3) not null,
	xNotes varchar(500),
	xVerified char(1) not null,
	xInvalid char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xOrganisationPersonLink
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xOrganisation varchar(16) for bit data not null,
	xPerson varchar(16) for bit data not null,
	xPersonRole varchar(16) for bit data,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xCorebankEntity_BAccount_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCorebankEntity varchar(16) for bit data not null,
	xBankAccount varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCorebankEntity, xBankAccount)
);

create table xCorebankEntity_Addresses_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCorebankEntity varchar(16) for bit data not null,
	xAddress varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCorebankEntity, xAddress)
);

create table xCorebankEntity_Phones_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCorebankEntity varchar(16) for bit data not null,
	xPhone varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCorebankEntity, xPhone)
);

create table xCorebankEntity
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xMaster varchar(16) for bit data not null,
	xEntityName varchar(60) not null,
	xTimeZone varchar(100) not null,
	xEntityType varchar(10) not null,
	xBaseGLCurrency varchar(3) not null,
	xDefaultCurrencyRateType varchar(16) for bit data not null,
	xDefaultSpotRateType varchar(16) for bit data not null,
	xServiceDeliveryChannel varchar(16) for bit data not null,
	xMovePLToTransactionBranch char(1) not null,
	xCountry varchar(3) not null,
	xNationalBankCodeForIBAN varchar(8),
	xLanguage varchar(2) not null,
	xDefaultAddress varchar(16) for bit data,
	xDefaultPhone varchar(16) for bit data,
	xEmailAddress varchar(100),
	xHomePageUrl varchar(256),
	xClientNumberDigits int not null,
	xClientNumberCheckDigit char(1) not null,
	xDateFormat varchar(3) not null,
	xDateSeparator varchar(1) not null,
	xHourFormat varchar(3) not null,
	xFirstDayOfWeek varchar(9) not null,
	xFirstWeekOfYear varchar(13) not null,
	xThousandsSeparator varchar(1) not null,
	xDecimalSeparator varchar(1) not null,
	xIBANIdentifierForGL varchar(6),
	xIBANFormat varchar(24) not null,
	xAccountMask varchar(20) not null,
	xSuspended char(1) not null,
	xExternalTransferGL varchar(12),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xPublicHoliday
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xCountry varchar(3),
	xDate date not null with default,
	xDescription varchar(120) not null,
	xAnnual char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xCountryRegion
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xCode varchar(20) not null,
	xDescription varchar(120) not null,
	xCountry varchar(3) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xEmailType
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xCurrencyRateType
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xUserSettings
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xUser varchar(16) for bit data not null,
	xSettings varchar(4000) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xStatusChange
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xStatus varchar(32) not null,
	xDate timestamp not null with default,
	xSetBy varchar(16) for bit data not null,
	xNotes varchar(500),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xOrganisation_Categories_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xOrganisation varchar(16) for bit data not null,
	xCategory varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xOrganisation, xCategory)
);

create table xOrganisation_Documents_Lnk
(
	xMasterId int not null,
	xOrganisation varchar(16) for bit data not null,
	xDocument varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xOrganisation, xDocument)
);

create table xOrganisation_Communities_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xOrganisation varchar(16) for bit data not null,
	xOrganisationCommunity varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xOrganisation, xOrganisationCommunity)
);

create table xOrganisation_CredRating_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xOrganisation varchar(16) for bit data not null,
	xOrganisationCreditRating varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xOrganisation, xOrganisationCreditRating)
);

create table xOrganisation
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xJurisdiction varchar(3),
	xOrganisationType varchar(10) not null,
	xRegistrationNumber varchar(20),
	xUnderRegistration char(1) not null,
	xCorporateRegistrationCountry varchar(3),
	xDomicile varchar(3),
	xRegistrationDate date,
	xSWIFTCode varchar(11),
	xCreditRating varchar(10),
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xOrganisationOwners
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xOrganisation varchar(16) for bit data not null,
	xFirstName varchar(60) not null,
	xLastName varchar(60) not null,
	xFullName varchar(150) not null,
	xStakeholder varchar(3) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xUser
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xPerson varchar(16) for bit data not null,
	xUserName varchar(60) not null,
	xPublicKey varchar(2000) for bit data not null,
	xHomeBranch varchar(10) not null,
	xRoleBackOffice char(1) not null,
	xRoleCustomer char(1) not null,
	xRoleAuditor char(1) not null,
	xInvalidRequests int not null,
	xType varchar(8),
	xReportTo varchar(16) for bit data,
	xAllowAccessDuring varchar(14),
	xSuspended char(1) not null,
	xDeleted char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);
create unique index IX_User_UserName on xUser(xMasterId, xUserName);

create table xBankAccount_StatusChanges_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xBankAccount varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xBankAccount, xStatusChange)
);

create table xBankAccount
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xCountry varchar(3) not null,
	xBank varchar(16) for bit data,
	xCurrency varchar(3) not null,
	xBankName varchar(60),
	xSWIFT varchar(11),
	xAbaRouting varchar(9),
	xBankCode varchar(20),
	xBranchCode varchar(6),
	xSortCode varchar(6),
	xAccountHolder varchar(60) not null,
	xPaymentType varchar(8) not null,
	xAccountNumber varchar(34) not null,
	xIBAN varchar(34),
	xAutogiroNumber varchar(16),
	xDisplayFormat varchar(5) not null,
	xStatus varchar(10) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xVacmanSecurityToken
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xTokenType varchar(5) not null,
	xTokenBlob blob not null,
	xPinNumber varchar(10) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xCategoryType
(
	xMasterId int not null,
	xEntityId int not null,
	xCode varchar(10) not null,
	xDescription varchar(120) not null,
	xForPerson char(1) not null,
	xForOrganisation char(1) not null,
	xForClient char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCode)
);

create table xPayable_BinaryDatas_Lnk
(
	xMasterId int not null,
	xPayable varchar(16) for bit data not null,
	xBinaryData varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xPayable, xBinaryData)
);

create table xPayable_StatusChanges_Lnk
(
	xMasterId int not null,
	xPayable varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xPayable, xStatusChange)
);

create table xPayable
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xOrganisation varchar(16) for bit data not null,
	xInvoiceType varchar(11) not null,
	xInvoiceNumber varchar(35) not null,
	xInvoiceDate date not null with default,
	xDueDate date not null with default,
	xPaymentReference1 varchar(35) not null,
	xPaymentReference2 varchar(35),
	xPaymentReference3 varchar(35),
	xPaymentReference4 varchar(35),
	xOurReference varchar(16) for bit data not null,
	xYourReference varchar(16) for bit data,
	xCurrency varchar(3) not null,
	xNotes varchar(4000),
	xTaxAmount decimal(21,6) not null,
	xTotalAmount decimal(21,6) not null,
	xStatus varchar(10) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xCategory
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xCode varchar(10) not null,
	xCategoryType varchar(10) not null,
	xDescription varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCurrency
(
	xMasterId int not null,
	xCode varchar(3) not null,
	xNumericCode varchar(3) not null,
	xDescription varchar(120) not null,
	xDecimalName varchar(20),
	xNumberOfDecimals int not null,
	xSymbol varchar(5),
	xSettlementDays int not null,
	xSymbolPosition varchar(5),
	xPriority char(1) not null,
	xRoundingType varchar(4) not null,
	xCommodity char(1) not null,
	xHideForCustomer char(1) not null,
	xSuspended char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xCode)
);

create table xContact_StatusChange_Lnk
(
	xMasterId int not null,
	xContact varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xContact, xStatusChange)
);

create table xContact_BankAccounts_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xContact varchar(16) for bit data not null,
	xBankAccount varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xContact, xBankAccount)
);

create table xContact_Diaries_Lnk
(
	xMasterId int not null,
	xContact varchar(16) for bit data not null,
	xDiary varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xContact, xDiary)
);

create table xContact_Addresses_Lnk
(
	xMasterId int not null,
	xContact varchar(16) for bit data not null,
	xAddress varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xContact, xAddress)
);

create table xContact_Phones_Lnk
(
	xMasterId int not null,
	xContact varchar(16) for bit data not null,
	xPhone varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xContact, xPhone)
);

create table xContact_Emails_Lnk
(
	xMasterId int not null,
	xContact varchar(16) for bit data not null,
	xEmail varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xContact, xEmail)
);

create table xContact
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xContactNumber int not null,
	xName varchar(150) not null,
	xLanguage varchar(2) not null,
	xDefaultAddress varchar(16) for bit data,
	xDefaultPhone varchar(16) for bit data,
	xDefaultEmail varchar(16) for bit data,
	xTaxCountry varchar(3),
	xTaxId varchar(20),
	xCurrency varchar(3),
	xHomePageUrl varchar(256),
	xDueDiligenceStatus varchar(22) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xPaymentMethod
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xCorebankMaster
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xMasterName varchar(200) not null,
	xLicenseData blob not null,
	xContactNumberDigits int not null,
	xContactNumberCheckDigit char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xBranch_Addresses_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xBranch varchar(10) not null,
	xAddress varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xBranch, xAddress)
);

create table xBranch_Phones_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xBranch varchar(10) not null,
	xPhone varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xBranch, xPhone)
);

create table xBranch
(
	xMasterId int not null,
	xEntityId int not null,
	xCode varchar(10) not null,
	xDescription varchar(120) not null,
	xUnitType varchar(6),
	xDefaultAddress varchar(16) for bit data,
	xDefaultPhone varchar(16) for bit data,
	xManager varchar(16) for bit data,
	xParentBranch varchar(10),
	xBranchLevel varchar(16) for bit data,
	xBranchCodeForIBAN varchar(6),
	xPayableGLAccount varchar(12),
	xReceivableGLAccount varchar(12),
	xCorebankEntity varchar(16) for bit data not null,
	xInterBranchGLDbTC varchar(4),
	xInterBranchGLCrTC varchar(4),
	xContingentSuspenseGLAccount varchar(12),
	xRealSuspenseGLAccount varchar(12),
	xSWIFT varchar(11),
	xSuspended char(1) not null,
	xReceivePropagateCurrencyRates char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCode)
);

create table xSettlementDir_Addresses_Lnk
(
	xMasterId int not null,
	xSettlementDirectory varchar(16) for bit data not null,
	xAddress varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xSettlementDirectory, xAddress)
);

create table xSettlementDir_Phones_Lnk
(
	xMasterId int not null,
	xSettlementDirectory varchar(16) for bit data not null,
	xPhone varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xSettlementDirectory, xPhone)
);

create table xSettlementDirectory
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xBankName varchar(120) not null,
	xCountry varchar(3) not null,
	xSWIFT varchar(11),
	xAbaRoutingNumber varchar(9),
	xBankCode varchar(20),
	xBranchCode varchar(6),
	xSortCode varchar(6),
	xDefaultAddress varchar(16) for bit data,
	xDefaultPhone varchar(16) for bit data,
	xEmailAddress varchar(100) not null,
	xHomePageUrl varchar(256),
	xSuspended char(1) not null,
	xBankEntityType varchar(6) not null,
	xIBANNationalId varchar(34),
	xAdditionalInformation varchar(120),
	xSubTypeIndicator varchar(4) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);
create unique index IX_Bank_Name_Code_Branch on xSettlementDirectory(xMasterId, xBankName, xBranchCode, xBankCode);

create table xPaymentTerm
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(120) not null,
	xDays int not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xDiaryType
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xAddressType
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xAddressType varchar(6) not null,
	xDescription varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xPerson_Categories_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xPerson varchar(16) for bit data not null,
	xCategory varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xPerson, xCategory)
);

create table xPerson_Documents_Lnk
(
	xMasterId int not null,
	xPerson varchar(16) for bit data not null,
	xDocument varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xPerson, xDocument)
);

create table xPerson_PersonCommunities_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xPerson varchar(16) for bit data not null,
	xPersonCommunity varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xPerson, xPersonCommunity)
);

create table xPerson_PersonAliases_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xPerson varchar(16) for bit data not null,
	xPersonAlias varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xPerson, xPersonAlias)
);

create table xPerson
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xFirstName varchar(60) not null,
	xLastName varchar(60) not null,
	xTitle varchar(10),
	xHonours varchar(20),
	xInitials varchar(10),
	xGender varchar(6) not null,
	xDateOfBirth date,
	xKidsMale int,
	xKidsFemale int,
	xMaritalStatus varchar(8),
	xNameOfSpouse varchar(100),
	xSSN varchar(20),
	xCitizenCountry varchar(3),
	xDomicileCountry varchar(3),
	xCreditRating varchar(10),
	xSkypeId varchar(150),
	xTwitterId varchar(150),
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xBankDate
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xBranch varchar(10),
	xSignificance varchar(7) not null,
	xDateType varchar(4) not null,
	xDayOfWeek varchar(9),
	xYear int,
	xMonth int,
	xDay int,
	xDescription varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCurrencyHoliday
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xCurrency varchar(3),
	xSignificance varchar(7) not null,
	xDateType varchar(4) not null,
	xDayOfWeek varchar(9),
	xYear int,
	xMonth int,
	xDay int,
	xDescription varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCurrencyDenomination
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xCurrency varchar(3) not null,
	xType varchar(4) not null,
	xValue decimal(21,6) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xInterfaceDefinition
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xName varchar(120) not null,
	xDirection varchar(8) not null,
	xMode varchar(10) not null,
	xLookupName varchar(40),
	xEndPoint varchar(40),
	xUserAuthentication char(1) not null,
	xUserName varchar(40),
	xPassword varchar(40),
	xIncomingInterfaceUserName varchar(16) for bit data,
	xSuspended char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xInterfaceUserLink
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xUser varchar(16) for bit data not null,
	xInterface varchar(16) for bit data not null,
	xUserName varchar(120) not null,
	xPassword varchar(60) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xBranchLevel
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xAccessRight
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xRole varchar(16) for bit data not null,
	xKey varchar(120) not null,
	xAction varchar(11) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xProcessRight
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xRole varchar(16) for bit data not null,
	xProcessAuthorization bigint not null,
	xAction varchar(8) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xRole
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xRoleGroup_Roles_Lnk
(
	xMasterId int not null,
	xRoleGroup varchar(16) for bit data not null,
	xRole varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xRoleGroup, xRole)
);

create table xRoleGroup
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xStatementFormat
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xSecuritySettings
(
	xMasterId int not null,
	xStaticId int not null,
	xMaxInvalidRequests int not null,
	xMinPasswordLength int not null,
	xRequireLetters char(1) not null,
	xRequireMixedCase char(1) not null,
	xRequireNumbers char(1) not null,
	xRequireSpecialChars char(1) not null,
	xSecurityTokenGraceDays int not null,
	xSecurityTokenLevel varchar(8) not null,
	xIdleTime int not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xStaticId)
);

create table xTranslatedValue
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xOwnerId varchar(100) not null,
	xObjectTypeName varchar(60) not null,
	xProperty varchar(60) not null,
	xLanguage varchar(2) not null,
	xValue varchar(250) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xUserBranchLink
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xUser varchar(16) for bit data not null,
	xBranch varchar(10) not null,
	xRoleGroup varchar(16) for bit data not null,
	xSuspended char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);
create unique index IX_User_Branch on xUserBranchLink(xMasterId, xEntityId, xUser, xBranch);

create table xProcessReason
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xName varchar(120) not null,
	xGroup varchar(7) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xDocumentTemplate
(
	xMasterId int not null,
	xCode varchar(10) not null,
	xType varchar(16) for bit data not null,
	xDescription varchar(120) not null,
	xDocumentAction varchar(20) not null,
	xAutoGenerate char(1) not null,
	xLocationOfDocument varchar(200),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xCode)
);

create table xInterestScheme
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(120) not null,
	xSuspended char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xDeliveryChannel
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(150) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCharge
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(150) not null,
	xType varchar(11) not null,
	xFrequency varchar(11),
	xAppliesTo varchar(6),
	xAmountOrPercentage varchar(10) not null,
	xStatus char(1) not null,
	xTreatAsCommission char(1) not null,
	xChargeIncomeGL varchar(12),
	xChargeTransactionCodeClientDB varchar(4),
	xChargeTransactionCodeGLCR varchar(4),
	xChargeTransactionCodeGLDB varchar(4),
	xCommissionExpenseGL varchar(12),
	xCommissionPayableGL varchar(12),
	xCommissionTransactionCodeGLDB varchar(4),
	xCommissionTransactionCodeGLCR varchar(4),
	xCommissionTrnCodeClientDB varchar(4),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xChargeCombination
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xCharge varchar(16) for bit data not null,
	xBranch varchar(10),
	xChannel varchar(16) for bit data,
	xPricing varchar(16) for bit data,
	xBasisCurrency varchar(3),
	xChargeCurrency varchar(3) not null,
	xClientSpecific char(1) not null,
	xClientIdKey varchar(16) for bit data,
	xAccountOpeningPeriod char(1) not null,
	xAccountClosingPeriod char(1) not null,
	xWaiveCharge char(1) not null,
	xWaivePeriod varchar(11),
	xWaiveAmount decimal(21,6),
	xStatus char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xChargeCombinationBand
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xChargeCombination varchar(16) for bit data not null,
	xRangeLow decimal(21,6) not null,
	xRangeHigh decimal(21,6) not null,
	xAmountOrPercentageValue decimal(21,6) not null,
	xMinimumChargeAmount decimal(21,6),
	xMaximumChargeAmount decimal(21,6),
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xApproved timestamp,
	xApprovedBy varchar(16) for bit data,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xInterestSchemeCombination
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xCurrency varchar(3),
	xPricing varchar(16) for bit data,
	xClient varchar(16) for bit data,
	xSuspended char(1) not null,
	xInterestYear varchar(13) not null,
	xInterestScheme varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xInterestSchemeBand
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xInterestSchemeCombination varchar(16) for bit data not null,
	xRangeLow decimal(21,6) not null,
	xRangeHigh decimal(21,6) not null,
	xInterestSchemeBandMethod varchar(8) not null,
	xRate decimal(16,6),
	xInterestBaseCode varchar(16) for bit data,
	xOffset decimal(16,6),
	xStatus varchar(8) not null,
	xAdded timestamp,
	xAddedBy varchar(16) for bit data,
	xUpdated timestamp,
	xUpdatedBy varchar(16) for bit data,
	xApproved timestamp,
	xApprovedBy varchar(16) for bit data,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);


create sequence SEQ_PropertyChanged as bigint start with 1 increment by 1;

create table xPropertyChanged
(
	xAutoId bigint not null,
	xMasterId int not null,
	xObject varchar(60) not null,
	xObjectId varchar(100) not null,
	xProperty varchar(60) not null,
	xVersion int not null,
	xOldValue varchar(500),
	xNewValue varchar(500),
	xAction varchar(10) not null,
	xChangedBy varchar(16) for bit data not null,
	xChangedOn timestamp not null with default,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xAutoId, xMasterId)
);

create table xTaskForce
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xCode varchar(10) not null,
	xName varchar(120) not null,
	xNotes varchar(4000),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xBlockCategory
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(150) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xProcessAuthorization
(
	xMasterId int not null,
	xEntityId int not null,
	xProcessDefinitionId bigint not null,
	xProcessName varchar(255) not null,
	xProcessVersion int not null,
	xStatus varchar(9) not null,
	xProcessCode varchar(4) not null,
	xProcessType varchar(6) not null,
	xUserDeployed varchar(16) for bit data not null,
	xDeployedDate timestamp not null with default,
	xIPAddress varchar(15) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xProcessDefinitionId)
);

create table xBranchSubmenu
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xSubmenu varchar(120) not null,
	xGroup varchar(7) not null,
	xNotes varchar(500),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xProcessHelp
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xFormat varchar(4) not null,
	xLevel varchar(7) not null,
	xLanguage varchar(7) not null,
	xAccess varchar(8) not null,
	xPath varchar(150),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xAmlCategory
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(150) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xRelationshipPricing
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(150) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xOffering
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(150) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xProcessMapping_Channel_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xProcessMapping varchar(16) for bit data not null,
	xDeliveryChannel varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xProcessMapping, xDeliveryChannel)
);

create table xProcess_InternalProduct_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xProcessMapping varchar(16) for bit data not null,
	xProductProfile varchar(6) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xProcessMapping, xProductProfile)
);

create table xProcess_ExternalProduct_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xProcessMapping varchar(16) for bit data not null,
	xExternalProductMapping varchar(6) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xProcessMapping, xExternalProductMapping)
);

create table xProcessMapping_Branches_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xProcessMapping varchar(16) for bit data not null,
	xBranch varchar(10) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xProcessMapping, xBranch)
);

create table xProcessMapping
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xProcess bigint not null,
	xBranchSubmenu varchar(16) for bit data not null,
	xTillRequired char(1) not null,
	xDenominationTracking char(1) not null,
	xAllowOffline char(1) not null,
	xProductMapping varchar(8) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xProcessAutofillMapping
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xProcessMapping varchar(16) for bit data not null,
	xProcessVariable varchar(16) for bit data not null,
	xAutoFillVariable varchar(14) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xProcessChargeMapping
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xProcessMapping varchar(16) for bit data not null,
	xCharge varchar(16) for bit data not null,
	xChargeAmount varchar(16) for bit data not null,
	xChargeBasis varchar(16) for bit data not null,
	xWaiveCharge char(1) not null,
	xExcludeVAT char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xProcessAccountingMapping
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xProcessMapping varchar(16) for bit data not null,
	xProcessVariable varchar(16) for bit data not null,
	xReferenceVariable varchar(32) not null,
	xTransactionType varchar(6),
	xDenomination varchar(3),
	xAccountType varchar(7),
	xValue varchar(100),
	xRateMethod varchar(8),
	xRateType varchar(16) for bit data,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xLinkProcess
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xProcess bigint not null,
	xTask varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xLinkProcessWf
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xLinkProcess varchar(16) for bit data not null,
	xLinkedProcess bigint not null,
	xMessage varchar(150),
	xAutoCreate char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xLinkProcessWfVariable
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xLinkProcessWf varchar(16) for bit data not null,
	xProcessVariable varchar(16) for bit data not null,
	xLinkProcessVariable varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCommunity
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xCommunityName varchar(150) not null,
	xType varchar(7),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xPersonCommunity
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xPerson varchar(16) for bit data not null,
	xType varchar(16) for bit data not null,
	xNotes varchar(500),
	xCommunityLoginId varchar(60) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xOrganisationCommunity
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xType varchar(16) for bit data not null,
	xCommunityLoginId varchar(60) not null,
	xNotes varchar(500),
	xOrganisation varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xPersonAlias
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xAliasName varchar(60) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xClientKYCDetail
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xReasonForChoosingBank varchar(30),
	xPlannedCashTransaction varchar(15),
	xGLCurrency varchar(3),
	xServiceRequired varchar(11),
	xDirectMarketing char(1),
	xClient varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xClientActivity_Countries_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xClientActivity varchar(16) for bit data not null,
	xCountry varchar(3) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xClientActivity, xCountry)
);

create table xClientActivity
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xActivityType varchar(4) not null,
	xClient varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xClientAverageMonthlyBalance
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xGLCurrency varchar(3) not null,
	xAmount decimal(21,6) not null,
	xClient varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xClientAverageTurnOver
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xGLCurrency varchar(3) not null,
	xAmount decimal(21,6) not null,
	xDepositOrWithdrawal char(1) not null,
	xPurpose varchar(500) not null,
	xClient varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCreditAgency
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xAgencyName varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xOrganisationCreditRating
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xOrganisation varchar(16) for bit data not null,
	xCreditAgency varchar(16) for bit data not null,
	xRating varchar(10) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xRuleSnapshot
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xCode varchar(4) not null,
	xName varchar(255) not null,
	xDescription varchar(1000),
	xType varchar(255) not null,
	xStatus varchar(1) not null,
	xPackage blob,
	xPackageDrl blob,
	xVersion int not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xRuleConfiguration
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xName varchar(255) not null,
	xDescription varchar(1000),
	xConfigClass varchar(255) not null,
	xRuleSnapshot varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xRuleParam
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xName varchar(255) not null,
	xDescription varchar(1000),
	xMode int not null,
	xParamClass varchar(255) not null,
	xRuleSnapshot varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xProcessRuleConfig
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xProcessAuthorization bigint not null,
	xRuleConfigValue varchar(125),
	xRuleConfigExtractor varchar(500),
	xRuleConfigExtInfo varchar(500),
	xRuleConfigType varchar(255),
	xRuleSnapshot varchar(16) for bit data not null,
	xRuleConfiguration varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xTillVault
(
	xMasterId int not null,
	xEntityId int not null,
	xCode varchar(10) not null,
	xBranch varchar(10) not null,
	xLedger varchar(12),
	xGLCode varchar(10),
	xCurrentUser varchar(16) for bit data,
	xType varchar(5) not null,
	xReportingVault varchar(10),
	xDescription varchar(255) not null,
	xInternalOrExternal varchar(8) not null,
	xExcessLedgerCode varchar(10),
	xShortageLedgerCode varchar(10),
	xExcessLedger varchar(12),
	xShortageLedger varchar(12),
	xChanged timestamp not null with default,
	xStatus varchar(6) not null,
	xSuspended char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCode)
);

create table xTillVaultOperation
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xTillVault varchar(10) not null,
	xUser varchar(16) for bit data,
	xAdded timestamp,
	xOperation varchar(8) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xTillVaultCurrency
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xGLCurrency varchar(3) not null,
	xIntraday decimal(21,6) not null,
	xOvernight decimal(21,6) not null,
	xHoliday decimal(21,6) not null,
	xTillVault varchar(10) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xTillVaultBalance
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xTillVaultCurrency varchar(16) for bit data not null,
	xAmount decimal(21,6) not null,
	xDate date not null with default,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xTillVaultBalanceHistory
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xTillVault varchar(10) not null,
	xGLCurrency varchar(3) not null,
	xAmount decimal(21,6) not null,
	xDate date not null with default,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xChannelUser_IssueCodeCard_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xChannelUser varchar(16) for bit data not null,
	xChannelUserIssueCodeCard varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xChannelUser, xChannelUserIssueCodeCard)
);

create table xChannelUser_UserRole_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xChannelUser varchar(16) for bit data not null,
	xChannelUserRole varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xChannelUser, xChannelUserRole)
);

create table xChannelUser
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xUserID varchar(60) not null,
	xPassword clob not null,
	xPublicKey varchar(2000) for bit data,
	xPerson varchar(16) for bit data not null,
	xAllowInternetBanking char(1) not null,
	xAllowMobileApplication char(1) not null,
	xAllowAESEncryptPwd char(1) not null,
	xAllowPwdCard char(1) not null,
	xAllowESignature char(1) not null,
	xAllowSecurityToken char(1) not null,
	xStatus varchar(9) not null,
	xNickName varchar(60),
	xTransactionsPerPage int not null,
	xMessagesPerPage int not null,
	xLastaskedChallenge int,
	xLoginCount int,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);
create unique index IX_ChannelUser on xChannelUser(xMasterId, xUserID);

create table xCardBundle
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xBundleNumber int not null,
	xDescription varchar(150) not null,
	xNumberOfCards int not null,
	xNumberOfCodesPerCard int not null,
	xLengthOfTheCode varchar(5) not null,
	xBundleStatus varchar(11) not null,
	xNumberOfCardsUsed int not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xCardMaster_StatusChanges_Lnk
(
	xMasterId int not null,
	xCardMaster varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xCardMaster, xStatusChange)
);

create table xCardMaster
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xBundleNumber int not null,
	xCardNumber varchar(10) not null,
	xCARDStatus varchar(9) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xStatus varchar(8) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xCardDetails
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xCardMaster varchar(16) for bit data not null,
	xCodeNumber clob not null,
	xCodeSequence int not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xLocation_Photograph_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xLocation varchar(16) for bit data not null,
	xBinaryData varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xLocation, xBinaryData)
);

create table xLocation
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xBranch varchar(10) not null,
	xLongitude decimal(10,6) not null,
	xLatitude decimal(10,6) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xOperatingHours
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xBranch varchar(10) not null,
	xMon char(1) not null,
	xMonOpnHrs varchar(11) not null,
	xMonOpnMm varchar(11) not null,
	xMonClsHrs varchar(11) not null,
	xMonClsMm varchar(11) not null,
	xTue char(1) not null,
	xTueOpnHrs varchar(11) not null,
	xTueOpnMm varchar(11) not null,
	xTueClsHrs varchar(11) not null,
	xTueClsMm varchar(11) not null,
	xWed char(1) not null,
	xWedOpnHrs varchar(11) not null,
	xWedOpnMm varchar(11) not null,
	xWedClsHrs varchar(11) not null,
	xWedClsMm varchar(11) not null,
	xThur char(1) not null,
	xThurOpnHrs varchar(11) not null,
	xThurOpnMm varchar(11) not null,
	xThurClsHrs varchar(11) not null,
	xThurClsMm varchar(11) not null,
	xFri char(1) not null,
	xFriOpnHrs varchar(11) not null,
	xFriOpnMm varchar(11) not null,
	xFriClsHrs varchar(11) not null,
	xFriClsMm varchar(11) not null,
	xSat char(1) not null,
	xSatOpnHrs varchar(11) not null,
	xSatOpnMm varchar(11) not null,
	xSatClsHrs varchar(11) not null,
	xSatClsMm varchar(11) not null,
	xSun char(1) not null,
	xSunOpnHrs varchar(11) not null,
	xSunOpnMm varchar(11) not null,
	xSunClsHrs varchar(11) not null,
	xSunClsMm varchar(11) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xMenuMaster_IconFile_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xMenuMaster varchar(16) for bit data not null,
	xBinaryData varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xMenuMaster, xBinaryData)
);

create table xMenuMaster
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xActivity varchar(120) not null,
	xParentMenu varchar(120),
	xDisplayPriority int not null,
	xMenuType varchar(6) not null,
	xQuickLaunch char(1) not null,
	xCreateOrInputRights char(1) not null,
	xAuthorizationRights char(1) not null,
	xClassification varchar(7),
	xByPass char(1) not null,
	xNumberOfApprovers int not null,
	xActivityType varchar(13) not null,
	xApprovalForActivity varchar(120) not null,
	xApplicability varchar(10) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xMenuChild
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xMenuMaster varchar(16) for bit data not null,
	xLanguage varchar(2) not null,
	xMenuText varchar(120) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCBUserRole_MenuChild_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xChannelUserRole varchar(16) for bit data not null,
	xMenuChild varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xChannelUserRole, xMenuChild)
);

create table xChannelUserRole
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xClient varchar(16) for bit data not null,
	xRole varchar(16) for bit data not null,
	xLimitCurrency varchar(3) not null,
	xAdministrator char(1) not null,
	xAllowBank char(1) not null,
	xAllowBankPartner char(1) not null,
	xAllowSocialNetwork char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xChannelUserActivityLimit
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xMenuChild varchar(16) for bit data not null,
	xChannelUserRole varchar(16) for bit data not null,
	xTransactionLimit decimal(21,6),
	xAuthorisationLimit decimal(21,6),
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xChannelUserActivityLog
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xChannelUser varchar(16) for bit data not null,
	xClient varchar(16) for bit data not null,
	xActivity varchar(16) for bit data not null,
	xIPAddress varchar(200) not null,
	xCountry varchar(80) not null,
	xSessionID varchar(200) not null,
	xDateTime timestamp not null with default,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCountryIpLookup
(
	xMasterId int not null,
	xIdKey varchar(50) not null,
	xBeginIpNumber bigint not null,
	xEndIpNumber bigint not null,
	xCountryCode varchar(6) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xChannelUserExternalMapping
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xChannelUser varchar(16) for bit data not null,
	xClient varchar(16) for bit data not null,
	xInterface varchar(16) for bit data not null,
	xExternalId clob not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCBIssueCodeCard_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xChannelUserIssueCodeCard varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xChannelUserIssueCodeCard, xStatusChange)
);

create table xChannelUserIssueCodeCard
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xCardMaster varchar(16) for bit data not null,
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xFXForwardRate_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xFXForwardRate varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xFXForwardRate, xStatusChange)
);

create table xFXForwardRate_Period_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xFXForwardRate varchar(16) for bit data not null,
	xFXForwardRatePeriod varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xFXForwardRate, xFXForwardRatePeriod)
);

create table xFXForwardRate
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xEffectiveBy timestamp not null with default,
	xFromCurrency varchar(3) not null,
	xToCurrency varchar(3) not null,
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xApproved timestamp,
	xApprovedBy varchar(16) for bit data,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xFXForwardRatePeriod
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xFXForwardRate varchar(16) for bit data not null,
	xSpotRate decimal(16,6) not null,
	xPeriod int not null,
	xForwardPoint decimal(21,6) not null,
	xForwardRate decimal(21,6) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xProcessTask
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xTask varchar(50) not null,
	xProcessAuthorization bigint not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xProcessVariable
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xVariable varchar(50) not null,
	xProcessTask varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xChannelUserChallengeLog
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xChannelUser varchar(16) for bit data not null,
	xClient varchar(16) for bit data not null,
	xActivity varchar(16) for bit data not null,
	xIPAddress varchar(200) not null,
	xSessionID varchar(200) not null,
	xStatus varchar(7) not null,
	xCodeSequence int not null,
	xDateTime timestamp not null with default,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xChannelUserPassword
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xChannelUser varchar(16) for bit data not null,
	xNewPassword clob,
	xTempPassword clob,
	xCreated timestamp not null with default,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xDiscountRate_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xDiscountRate varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xDiscountRate, xStatusChange)
);

create table xDiscountRate
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xEffectiveBy timestamp not null with default,
	xCurrency varchar(3) not null,
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xDiscountRatePeriod
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xDiscountRate varchar(16) for bit data not null,
	xPeriod int not null,
	xDiscountPoints decimal(21,6) not null,
	xExpiryDate timestamp not null with default,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCardProduct_TrnsCodes_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCardProduct varchar(6) not null,
	xTransactionCode varchar(4) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCardProduct, xTransactionCode)
);

create table xCardProduct_Offerings_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCardProduct varchar(6) not null,
	xOffering varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCardProduct, xOffering)
);

create table xCardProduct_Clients_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCardProduct varchar(6) not null,
	xClient varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCardProduct, xClient)
);

create table xCardProduct_AccProducts_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCardProduct varchar(6) not null,
	xProductProfile varchar(6) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCardProduct, xProductProfile)
);

create table xCardProduct_Currency_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCardProduct varchar(6) not null,
	xGLCurrency varchar(3) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCardProduct, xGLCurrency)
);

create table xCardProduct_Designs_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCardProduct varchar(6) not null,
	xDesign varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCardProduct, xDesign)
);

create table xCardProduct_Notifications_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCardProduct varchar(6) not null,
	xNotification varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCardProduct, xNotification)
);

create table xCardProduct_AddCharges_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCardProduct varchar(6) not null,
	xAdditionalCharge varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCardProduct, xAdditionalCharge)
);

create table xCardProduct_Branches_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCardProduct varchar(6) not null,
	xBranch varchar(10) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCardProduct, xBranch)
);

create table xCardProduct
(
	xMasterId int not null,
	xEntityId int not null,
	xBinNumber varchar(6) not null,
	xDescription varchar(120) not null,
	xCardType varchar(8) not null,
	xCardProvider varchar(16) for bit data not null,
	xValidityPeriod int not null,
	xCardNumberLength int not null,
	xStatus varchar(9) not null,
	xCardIssuanceCharge varchar(16) for bit data,
	xProcessingCharge varchar(16) for bit data,
	xAnnualCharge varchar(16) for bit data,
	xServiceCharge varchar(16) for bit data,
	xLatePaymentCharge varchar(16) for bit data,
	xChargesOnExtendedCredit varchar(16) for bit data,
	xSelectedTransactionCode char(1) not null,
	xSelectedBranch char(1) not null,
	xSelectedClient char(1) not null,
	xSelectedOffering char(1) not null,
	xSelectedProduct char(1) not null,
	xSelectedCurrency char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xBinNumber)
);

create table xAdditionalCharge
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xChargeId int,
	xDescription varchar(120) not null,
	xChargeScheme varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xDesign_BinaryDatas_Lnk
(
	xMasterId int not null,
	xDesign varchar(16) for bit data not null,
	xBinaryData varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xDesign, xBinaryData)
);

create table xDesign
(
	xMasterId int not null,
	xIdKey varchar(16) for bit data not null,
	xImageID varchar(30),
	xDescription varchar(120) not null,
	xAdded timestamp not null with default,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xIdKey)
);

create table xNotification_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xNotification varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xNotification, xStatusChange)
);

create table xNotification
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xMessageType varchar(50) not null,
	xSubject varchar(120) not null,
	xMessage varchar(500) not null,
	xStatus varchar(9) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCardProvider
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xDescription varchar(120) not null,
	xInterface varchar(16) for bit data not null,
	xSuspended char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xMessageType
(
	xMasterId int not null,
	xEntityId int not null,
	xCode varchar(50) not null,
	xDescription varchar(120) not null,
	xSuspended char(1) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCode)
);

create table xCard_LinkedAccounts_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCard varchar(16) for bit data not null,
	xLinkedAccount varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCard, xLinkedAccount)
);

create table xCard
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xClient varchar(16) for bit data not null,
	xCardProduct varchar(6) not null,
	xHolderType varchar(9),
	xPrimaryCard varchar(16) for bit data,
	xAccount varchar(16) for bit data not null,
	xCurrency varchar(3) not null,
	xCardNumber varchar(16) not null,
	xMonthOfExpire int not null,
	xYearOfExpire int not null,
	xCardHolder varchar(16) for bit data,
	xEmbossedName varchar(120) not null,
	xStatus varchar(9) not null,
	xLinkedCard varchar(16) for bit data,
	xOverallLimit varchar(16) for bit data,
	xCashLimit varchar(16) for bit data,
	xUtilizedLimit varchar(16) for bit data,
	xAvailableLimit varchar(16) for bit data,
	xAvailableCashLimit varchar(16) for bit data,
	xTotalAmountDue decimal(21,6),
	xAmountDueDate date,
	xMinimumAmountDue decimal(21,6),
	xLastStatementDate date,
	xNextStatementDate date,
	xDefaultAccountNumber varchar(16) for bit data,
	xAdded timestamp not null with default,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCardCharges_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCardCharges varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCardCharges, xStatusChange)
);

create table xCardCharges
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xCard varchar(16) for bit data not null,
	xCardIssuanceCharge varchar(16) for bit data,
	xProcessingCharge varchar(16) for bit data,
	xAnnualCharge varchar(16) for bit data,
	xServiceCharge varchar(16) for bit data,
	xLatePaymentCharge varchar(16) for bit data,
	xChargesOnExtendedCredit varchar(16) for bit data,
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCardAdditionalCharges_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCardAdditionalCharges varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCardAdditionalCharges, xStatusChange)
);

create table xCardAdditionalCharges
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xCard varchar(16) for bit data not null,
	xChargeId int,
	xDescription varchar(120) not null,
	xChargeScheme varchar(16) for bit data not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xStatus varchar(8) not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCardStatus_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCardStatus varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCardStatus, xStatusChange)
);

create table xCardStatus
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xCard varchar(16) for bit data not null,
	xCardStatus varchar(9) not null,
	xReason varchar(120) not null,
	xStatus varchar(8) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xLinkedAccount
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xAccount varchar(16) for bit data not null,
	xClient varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xSI_SC_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xSettlementInstructions varchar(16) for bit data not null,
	xStatusChange varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xSettlementInstructions, xStatusChange)
);

create table xSettlementInstructions
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xClient varchar(16) for bit data,
	xClientSpecific char(1) not null,
	xCurrency varchar(3) not null,
	xModule varchar(2),
	xProduct varchar(6),
	xSettlementBy varchar(18) not null,
	xDebitAccount varchar(16) for bit data,
	xDebitGLAccount varchar(12),
	xCreditAccount varchar(16) for bit data,
	xCreditGLAccount varchar(12),
	xChargeAccount varchar(16) for bit data,
	xChargeGLAccount varchar(12),
	xBeneficiaryBIC varchar(16) for bit data,
	xAcctWithInstitutionBIC varchar(16) for bit data,
	xBeneficiaryAcct varchar(34),
	xNettingAllowed char(1),
	xRecordStatus varchar(8) not null,
	xInstructionStatus varchar(9) not null,
	xAddedBy varchar(16) for bit data not null,
	xAdded timestamp not null with default,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCollateral_Client_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCollateral varchar(16) for bit data not null,
	xClient varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCollateral, xClient)
);

create table xCollateral_Contact_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCollateral varchar(16) for bit data not null,
	xContact varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCollateral, xContact)
);

create table xCollateral
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xCollateralId int not null,
	xCollateralType varchar(22) not null,
	xDescription varchar(120) not null,
	xCollateralStatus varchar(9) not null,
	xRecordStatus varchar(8) not null,
	xCollateralCurrency varchar(3) not null,
	xAdded timestamp not null with default,
	xAddedBy varchar(16) for bit data not null,
	xApproved timestamp,
	xApprovedBy varchar(16) for bit data,
	xUpdated timestamp,
	xUpdatedBy varchar(16) for bit data,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);
create unique index IX_Collateral on xCollateral(xMasterId, xEntityId, xCollateralId);

create table xCollateralNotes
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xDate timestamp not null with default,
	xNotes varchar(500) not null,
	xCollateral varchar(16) for bit data not null,
	xRowVersion int not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCollateralCash
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xAccountType varchar(15) not null,
	xClientAccount varchar(16) for bit data,
	xTermDepositAccount varchar(16) for bit data,
	xBlockCategory varchar(16) for bit data not null,
	xCollateralAmount decimal(21,6) not null,
	xPercentageEligible decimal(10,5) not null,
	xAmountBlock varchar(16) for bit data,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCollateralFI
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xOwner varchar(12) not null,
	xFIType varchar(6) not null,
	xSecurityName varchar(150) not null,
	xIssuerName varchar(150) not null,
	xMarketTraded varchar(150) not null,
	xMarketSymbol varchar(60),
	xFaceValue decimal(21,6) not null,
	xUnits int not null,
	xMarketValue decimal(21,6) not null,
	xPercentageEligible decimal(10,5) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCollateralEMortgage
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xMortgageNumber varchar(150) not null,
	xRegistrarReferenceNumber varchar(150) not null,
	xMortgageValue decimal(21,6) not null,
	xPriority varchar(6) not null,
	xMortgagedTo varchar(10) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCollateralGuarantee
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xGuaranteeType varchar(8) not null,
	xGuaranteeNumber varchar(150) not null,
	xGuaranteeAmount decimal(21,6) not null,
	xGuaranteeValidTill date not null with default,
	xPercentageEligible decimal(10,5) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCollateralBHypothecation
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xValueofGoods decimal(21,6) not null,
	xGoodsVerifiedBy varchar(150) not null,
	xNextVerificationDate date not null with default,
	xPercentageEligible decimal(10,5) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCollateralPMetal
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xOwner varchar(12) not null,
	xPMetalType varchar(17) not null,
	xPMetalForm varchar(9) not null,
	xWeight decimal(18,6) not null,
	xRateperGram decimal(21,6) not null,
	xValueofPreciousStones decimal(21,6) not null,
	xDefectDeduction decimal(21,6) not null,
	xPercentageEligible decimal(10,5) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xProperty_CollateralEM_Lnk
(
	xMasterId int not null,
	xEntityId int not null,
	xCollateralProperty varchar(16) for bit data not null,
	xCollateralEMortgage varchar(16) for bit data not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xCollateralProperty, xCollateralEMortgage)
);

create table xCollateralProperty
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xOwner varchar(12) not null,
	xPropertyNumber varchar(150) not null,
	xPropertyType varchar(20) not null,
	xArea decimal(18,6) not null,
	xConstructedArea decimal(18,6),
	xYearOfConstruction int,
	xAddressType varchar(16) for bit data not null,
	xAddress1 varchar(100) not null,
	xAddress2 varchar(100),
	xCity varchar(30) not null,
	xState varchar(30),
	xZip varchar(10),
	xPostbox varchar(30),
	xCountry varchar(3) not null,
	xPropertyValue decimal(21,6) not null,
	xValuationDate date not null with default,
	xValuationDoneBy varchar(150) not null,
	xNextValuationDate date not null with default,
	xValuationBasedOn varchar(21) not null,
	xPercentageEligible decimal(10,5) not null,
	xValuationStatus varchar(8) not null,
	xValueAdded timestamp not null with default,
	xValueAddedBy varchar(16) for bit data not null,
	xValueApproved timestamp,
	xValueApprovedBy varchar(16) for bit data,
	xValueUpdated timestamp,
	xValueUpdatedBy varchar(16) for bit data,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);
create unique index IX_CollateralProperty on xCollateralProperty(xMasterId, xEntityId, xPropertyNumber);

create table xCollateralArt
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xOwner varchar(12) not null,
	xArtType varchar(9) not null,
	xValue decimal(21,6) not null,
	xValuedBy varchar(150) not null,
	xValuedOn date not null with default,
	xPercentageEligible decimal(10,5) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

create table xCollateralOthers
(
	xMasterId int not null,
	xEntityId int not null,
	xIdKey varchar(16) for bit data not null,
	xOwner varchar(12) not null,
	xOthersType varchar(150) not null,
	xValue decimal(21,6) not null,
	xValuedBy varchar(150) not null,
	xValuedOn date not null with default,
	xPercentageEligible decimal(10,5) not null,
	xLastUpdated timestamp not null with default,
	primary key (xMasterId, xEntityId, xIdKey)
);

alter table xGLCurrency add constraint FK_edf7320dfaef1b425f8b156d3b6ca9e3 foreign key (xMasterId, xCurrency)
		references xCurrency (xMasterId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_9d1d31362433516ff9ab573158a51756 foreign key (xMasterId, xEntityId, xTaxWitholdGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_78d6740c446b90be30331d53b4be4160 foreign key (xMasterId, xEntityId, xRetainedEarningsGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_040b27575cbeb46f17e14a0967275416 foreign key (xMasterId, xEntityId, xYearToDateProfitLossGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_bffed23cc2da1667e283cb979018f4b9 foreign key (xMasterId, xEntityId, xSuspenseBSGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_a226ef57609cda791b05643a05111dee foreign key (xMasterId, xEntityId, xFXTranslationReserveGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_af23efb1177f0871ed63953a0a668679 foreign key (xMasterId, xEntityId, xFXTranslationDiffGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_bfb04b17f6f6df0871846afd13cb5ffa foreign key (xMasterId, xEntityId, xProfitOnCurExchangeGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_1ae2d2c3182cf21e58534ec6e439a5d4 foreign key (xMasterId, xEntityId, xLossOnCurExchangeGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_adb39bbc4d4f4ca3ffbee28a420e0d3c foreign key (xMasterId, xEntityId, xNetProfitLossGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_5997ad5b539b85147c5e9747ea7bdc26 foreign key (xMasterId, xEntityId, xSuspenseISGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_f5b98dee36208c9742a25cca833d596c foreign key (xMasterId, xEntityId, xFXUnrealisedProfitGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_aed5efaa173d6881e9048328714cca92 foreign key (xMasterId, xEntityId, xFXUnrealisedLossGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_511e61218743a1c62952bd3891dae6f1 foreign key (xMasterId, xEntityId, xDefaultGLDBTransactionCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_1b22997be8ded1a0834247581c49d53d foreign key (xMasterId, xEntityId, xDefaultGLCRTransactionCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_73c3e9217617f0105c29af144de61fe9 foreign key (xMasterId, xEntityId, xDefaultClientDbTC)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_08f35fab7bd236a86ed047911c12a233 foreign key (xMasterId, xEntityId, xDefaultClientCrTC)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_a132764b8e69330e91d2d08a60a37d03 foreign key (xMasterId, xEntityId, xCurrencyPosGLDbTC)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_1071803bd719d15dace3a301b49fa117 foreign key (xMasterId, xEntityId, xCurrencyPosGLCrTC)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_d3372218ca7c852e0f9aaa8d6d517df6 foreign key (xMasterId, xEntityId, xClearToBaseCurGLDbTC)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_25e61c814dfce5c367d85060d7362232 foreign key (xMasterId, xEntityId, xClearToBaseCurGLCrTC)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_82b0f1969fab03df67f721d533560cdb foreign key (xMasterId, xEntityId, xProfitOnNonCashGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_8113b7538361ae6f8cfe7e8e1718d455 foreign key (xMasterId, xEntityId, xLossOnNonCashGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_1fccb7f01ae941589db6f8dd82e20751 foreign key (xMasterId, xEntityId, xCashRateType)
		references xCurrencyRateType (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_770761a9f44322ea407d49d3105cfe4f foreign key (xMasterId, xEntityId, xNonCashRateType)
		references xCurrencyRateType (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_20b944c75012c85bb4a1a5ca2c12fb57 foreign key (xMasterId, xEntityId, xRevaluationRateType)
		references xCurrencyRateType (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_47b4da9add2ff691a5b929a7672f0726 foreign key (xMasterId, xEntityId, xRevalOfCurExchangeDbTC)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_fbfbfb8f649e7126c6a34a460513b017 foreign key (xMasterId, xEntityId, xRevalOfCurExchangeCrTC)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_a2d3c5c0ed114a57cbed932570798c28 foreign key (xMasterId, xEntityId, xRevalOfNonCashDbTC)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_96c6564e08f29181edfc5f31d5027870 foreign key (xMasterId, xEntityId, xRevalOfNonCashCrTC)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_921eb09a1d2189568f72394377e6f5dd foreign key (xMasterId, xEntityId, xUnrealizedRevalDbTC)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_b4437aa068e6b3bd722f97f5d2521921 foreign key (xMasterId, xEntityId, xUnrealizedRevalCrTC)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_9e7fdbbe98bb335c7e0ffc2826ebf740 foreign key (xMasterId, xEntityId, xYearToDateDbTC)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrency add constraint FK_2dbaf07a8e94a609724c348f116e7861 foreign key (xMasterId, xEntityId, xYearToDateCrTC)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLJournal add constraint FK_96beb7741dccfb22ac3f01dbf32f1cf7 foreign key (xMasterId, xEntityId, xGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xGLJournal add constraint FK_09d5e3c3ae8b2d2a7fb18457df3e1567 foreign key (xMasterId, xEntityId, xGLJournalTemplate)
		references xGLJournalTemplate (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLJournal add constraint FK_ac5ee90975c44d1a82a9546302cf88bf foreign key (xMasterId, xEntityId, xGLAccountingPeriod)
		references xGLAccountingPeriod (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xGLJournal add constraint FK_8aab0154d6e59b0b0d70189d9905c554 foreign key (xMasterId, xEntityId, xOriginBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLJournal add constraint FK_03a7df3529307747a9f5d17a94b81074 foreign key (xMasterId, xLockedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xGLJournal_StatusChanges_Lnk add constraint FK_809e0387f968963802013e34f71da7c8 foreign key (xMasterId, xEntityId, xGLJournal)
		references xGLJournal (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xGLJournal_StatusChanges_Lnk add constraint FK_985f9b058314a86429bf1d3389ae8b3a foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xGLJournal add constraint FK_0aae2e7932dc0b72c858a57d010f3385 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xGLAccount add constraint FK_3e19db21ab26c305d8eb83f2fdc1e353 foreign key (xMasterId, xEntityId, xGLCurrencyPosition)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xGLAccount_GLCurrencies_Lnk add constraint FK_48810768dbe75f189f10007dffc90ac9 foreign key (xMasterId, xEntityId, xGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLAccount_GLCurrencies_Lnk add constraint FK_0bdcbc468632a8ce7b0d433257040ae0 foreign key (xMasterId, xEntityId, xGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xGLCurrencyExchange add constraint FK_0a19dcc742b4367e8d13a3b3f41b831e foreign key (xMasterId, xEntityId, xGLJournalTemplate)
		references xGLJournalTemplate (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrencyExchange add constraint FK_86fd94ce34c609ecf25876f81d7c58c0 foreign key (xMasterId, xEntityId, xTransactionCodeDB)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrencyExchange add constraint FK_ce41b965f3b8181223829e9a903fed30 foreign key (xMasterId, xEntityId, xGLAccountDB)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrencyExchange add constraint FK_b4d85c417fe9c79452d6a2d1aa597797 foreign key (xMasterId, xEntityId, xClientAccountDB)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xGLCurrencyExchange add constraint FK_193e3804df75496aa132edf5cfec6716 foreign key (xMasterId, xEntityId, xBranchDB)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrencyExchange add constraint FK_f528f894d0b02d9e54ddd8f4eba15a6c foreign key (xMasterId, xEntityId, xCurrencyDB)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xGLCurrencyExchange add constraint FK_1f7fcfd81a5bf5d400c7982ea47d2a61 foreign key (xMasterId, xEntityId, xTransactionCodeCR)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrencyExchange add constraint FK_63ef2bd590e544552042b7c2299df3be foreign key (xMasterId, xEntityId, xGLAccountCR)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrencyExchange add constraint FK_5d3a3e5ceb5175f0653ab25771993eec foreign key (xMasterId, xEntityId, xClientAccountCR)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xGLCurrencyExchange add constraint FK_062c122d4922f845f9ae2cac4c00af0e foreign key (xMasterId, xEntityId, xBranchCR)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrencyExchange add constraint FK_cb3ff10adf128a21f41d1cb6fa8fc537 foreign key (xMasterId, xEntityId, xCurrencyCR)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xGLCurrencyExchange add constraint FK_0973685d1d9f8a708f6b78d560230d01 foreign key (xMasterId, xEntityId, xRateType)
		references xCurrencyRateType (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xGLCurrencyExchange add constraint FK_10bed71dfdc7e56ffa6101523f55dd44 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xGLCurrencyExchange add constraint FK_59b603e7916e54e694df51c22d36e56c foreign key (xMasterId, xEntityId, xOriginBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLCurrencyExc_SC_Lnk add constraint FK_85e4d999d7c26e4bc9f789515e4ded51 foreign key (xMasterId, xEntityId, xGLCurrencyExchange)
		references xGLCurrencyExchange (xMasterId, xEntityId, xTransactionRefNo) on delete restrict on update restrict;

alter table xGLCurrencyExc_SC_Lnk add constraint FK_39b9fc232344763a10bef2cf676deb8c foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xGLChartOfAccountLinkage add constraint FK_4d8129b3a623e7c9b5ffd19af750e54f foreign key (xMasterId, xEntityId, xGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLChartOfAccountLinkage add constraint FK_0c58e6230400beed64155d60de2dfe53 foreign key (xMasterId, xEntityId, xGLChartOfAccountCR)
		references xGLChartOfAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xGLChartOfAccountLinkage add constraint FK_d6d318902c0aecb43398e79260ef39a2 foreign key (xMasterId, xEntityId, xGLChartOfAccountDB)
		references xGLChartOfAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xGLChartOfAccountLinkage add constraint FK_b14cd965e655b6fbb7a5e7387de140aa foreign key (xMasterId, xEntityId, xGLChartOfAccountName)
		references xGLChartOfAccountName (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTransactionDefault add constraint FK_caefd8cf7ed514424a0d50f7549474ad foreign key (xMasterId, xEntityId, xTransactionCodeGLDB)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTransactionDefault add constraint FK_8c8c023f3947362debb267c9eb0375c5 foreign key (xMasterId, xEntityId, xTransactionCodeGLCR)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTransactionDefault add constraint FK_e5a33e0dd9379470778d9d59fae19eb2 foreign key (xMasterId, xEntityId, xTransactionCodeClientDB)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTransactionDefault add constraint FK_94e46d816d1e9d4c681a7d4500312eb1 foreign key (xMasterId, xEntityId, xTransactionCodeClientCR)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTransactionDefault add constraint FK_b479f39bb00213c024687fa60456b2ab foreign key (xMasterId, xEntityId, xLiabilityTransactionDefault)
		references xTransactionDefault (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTransactionCode add constraint FK_994a8cd8b927deda3b41ac7e2ab3c473 foreign key (xMasterId, xEntityId, xCombinedChargeTransactionCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTransactionCode add constraint FK_38db3dbf0686302b0013f7fc2578862a foreign key (xMasterId, xEntityId, xReverseTransactionCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTransactionCode_Charges_Lnk add constraint FK_20cc0ec46fa0e93bc62698358f010978 foreign key (xMasterId, xEntityId, xTransactionCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTransactionCode_Charges_Lnk add constraint FK_ad2beec68052310305c212f623715f8d foreign key (xMasterId, xEntityId, xCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xGLChartOfAccount add constraint FK_d3a8a8e8b40456f9cb35b50c30ffce24 foreign key (xMasterId, xEntityId, xChartOfAccountName)
		references xGLChartOfAccountName (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xGLChartOfAccount add constraint FK_b6b433436789934a7c62beb92ffd48db foreign key (xMasterId, xEntityId, xParent)
		references xGLChartOfAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xGLChartOfAccount add constraint FK_be0cf023f80988f4a4ffe1abfba85b0a foreign key (xMasterId, xEntityId, xGLCurrencyPosition)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xGLChartOfAccount add constraint FK_f3f4a5caa6dbdfda4f8eab35536fbfd4 foreign key (xMasterId, xEntityId, xTrustGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTransDefGLLnk add constraint FK_5105c7bc9fb04a43d80e8af77af4eba3 foreign key (xMasterId, xEntityId, xTransactionDefault)
		references xTransactionDefault (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTransDefGLLnk add constraint FK_712805dada21f40683b912f06a31e7f6 foreign key (xMasterId, xEntityId, xGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTransDefGLLnk add constraint FK_4ec1028c22a2ede4c72cb294451e56d8 foreign key (xMasterId, xEntityId, xGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xGLBatch add constraint FK_c053a36a092a1c93054e29ae55bd5691 foreign key (xMasterId, xLockedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xGLBatch_StatusChanges_Lnk add constraint FK_e44aa4f8d780f863d39732036152f0d6 foreign key (xGLBatch, xMasterId, xEntityId)
		references xGLBatch (xAutoId, xMasterId, xEntityId) on delete restrict on update restrict;

alter table xGLBatch_StatusChanges_Lnk add constraint FK_42895915b460f0d174b13c7785e2f395 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xGLJournalTemplate_TC_Lnk add constraint FK_08ad15fb300e2db3b9056974a45b2976 foreign key (xMasterId, xEntityId, xGLJournalTemplate)
		references xGLJournalTemplate (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLJournalTemplate_TC_Lnk add constraint FK_10724de386710a9d0a8c010ca143744c foreign key (xMasterId, xEntityId, xTransactionCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLJournalTemplate_Client_Lnk add constraint FK_525badb5f70be780760ea9b3a2b72d2f foreign key (xMasterId, xEntityId, xGLJournalTemplate)
		references xGLJournalTemplate (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLJournalTemplate_Client_Lnk add constraint FK_a813197229f952ef086d95ba5bc6fc61 foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xGLChartOfAccountLanguage add constraint FK_3e506ed637ac5605990e1aa76eb96c79 foreign key (xMasterId, xEntityId, xGLChartOfAccount)
		references xGLChartOfAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xGLChartOfAccountLanguage add constraint FK_bae1bb035ec43172351dd5dd354f1cb7 foreign key (xMasterId, xLanguage)
		references xLanguage (xMasterId, xCode) on delete restrict on update restrict;

alter table xGLTransaction add constraint FK_8f1c47f282213c5a9ce41c496f7844cb foreign key (xMasterId, xEntityId, xGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLTransaction add constraint FK_739da8dec5c9ddc0980bcf24b720a2e8 foreign key (xMasterId, xEntityId, xAccountBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLTransaction add constraint FK_70e743948998f3b6958681a9d4dca213 foreign key (xMasterId, xEntityId, xTransactionBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLTransaction add constraint FK_50872162e8b664ab8a32115942f36a26 foreign key (xMasterId, xEntityId, xTransactionCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLTransaction add constraint FK_748f29db2cd95abcea00331499a49ae2 foreign key (xMasterId, xEntityId, xGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xGLTransaction add constraint FK_95ce502783916cb4cd0b2a17316000ae foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xJournalDetail add constraint FK_7d190a898db6794ad45a289c61dc2560 foreign key (xMasterId, xEntityId, xGLJournal)
		references xGLJournal (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xJournalDetail add constraint FK_9072eea07185520e160ada095d442ae0 foreign key (xMasterId, xEntityId, xGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xJournalDetail add constraint FK_5466826473d33ec320eb9e67c920b5f7 foreign key (xMasterId, xEntityId, xClientAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xJournalDetail add constraint FK_aa9109be25a9bfcf90d9f5afe6801fe9 foreign key (xMasterId, xEntityId, xTransactionCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xJournalDetail add constraint FK_fa5c15733804c1d3551e334a43953b11 foreign key (xMasterId, xEntityId, xAccountBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTCDefaultGL add constraint FK_935bf6d42fa0e4435654d2a94d038b90 foreign key (xMasterId, xEntityId, xTransactionCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTCDefaultGL add constraint FK_8a259df5013cc2e0b8f957b203ef1b19 foreign key (xMasterId, xEntityId, xGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xTCDefaultGL add constraint FK_7bf9faa2cb6f0c80586b1031f24cb366 foreign key (xMasterId, xEntityId, xGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLAccountingPeriod add constraint FK_4086edd4b78f92c3b0b591b28e9b9999 foreign key (xMasterId, xOpenedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xGLAccountingPeriod add constraint FK_de28e1252bf78b1096e9e110605f36bb foreign key (xMasterId, xClosedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xGLJournalBranchCombination add constraint FK_333f6041adbc3b5445e8e7368f92f459 foreign key (xMasterId, xEntityId, xGLJournalTemplate)
		references xGLJournalTemplate (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLJournalBranchCombination add constraint FK_16d1a024aa70a228548624f8b7b5cf5a foreign key (xMasterId, xEntityId, xBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xGLJournalBranchRateType add constraint FK_95c5ad78b3b2521cdd4d568baa7b7a22 foreign key (xMasterId, xEntityId, xGLJournalBranchCombination)
		references xGLJournalBranchCombination (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xGLJournalBranchRateType add constraint FK_aa522d296d9fe564be85656c0fd6fb28 foreign key (xMasterId, xEntityId, xCurrencyRateType)
		references xCurrencyRateType (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xValueDatedCABalance add constraint FK_8021e22f624d3a893c05cd40c1d65374 foreign key (xMasterId, xEntityId, xBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xValueDatedCABalance add constraint FK_19927a9e677424f25b89290b09663f26 foreign key (xMasterId, xEntityId, xClientAccount)
		references xAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xValueDatedCABalance add constraint FK_065885be97838435f59d9bd3d3c9bc8e foreign key (xMasterId, xEntityId, xGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xValueDatedGLBalance add constraint FK_97d9f2091c2558470455aebae6ff6d88 foreign key (xMasterId, xEntityId, xBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xValueDatedGLBalance add constraint FK_ffdcfeb159aec44a194c2bf8135fda5e foreign key (xMasterId, xEntityId, xGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xValueDatedGLBalance add constraint FK_c329f3244f914d58f7bc784b03647286 foreign key (xMasterId, xEntityId, xGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xTransactionFeeAccounting add constraint FK_119e76f41b7f49a42e05c57a73282cb8 foreign key (xMasterId, xEntityId, xTransactionFeeProfile)
		references xTransactionFeeProfile (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTransactionFeeAccounting add constraint FK_0c9e667f49c69ec04848e2e78dc02ef3 foreign key (xMasterId, xEntityId, xGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xTransactionFeeAccounting add constraint FK_52ade538f9652bbc5316b178ec1f6f9f foreign key (xMasterId, xEntityId, xGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTransactionFeeAccounting add constraint FK_980486556a2f0f5b423ce2df283a0a97 foreign key (xMasterId, xEntityId, xClientAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTransactionFeeAccounting add constraint FK_2fce20ebafcb4767e17a38ca0baf12c0 foreign key (xMasterId, xEntityId, xTransactionCodeCR)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTransactionFeeAccounting add constraint FK_2b371eda838b6c70d619331b0355c79b foreign key (xMasterId, xEntityId, xTransactionCodeDB)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xDueDiligenceIdentification add constraint FK_8538c79637c4fcedae54bf82734a960d foreign key (xMasterId, xContact)
		references xContact (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDueDiligenceIdentification add constraint FK_566bba47a3b7255093926d348b9d29fe foreign key (xMasterId, xIssuingCountry)
		references xCountry (xMasterId, xAlpha3Code) on delete restrict on update restrict;

alter table xDueDiligenceIdentification add constraint FK_084cd21274661dc4090e44ccc02fb06e foreign key (xMasterId, xIssuingCountryRegion)
		references xCountryRegion (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDueDiligenceIdentification add constraint FK_9c59ddb163a043994300e7b5c078ccdd foreign key (xMasterId, xBinaryData)
		references xBinaryData (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDueDiligenceIdentification add constraint FK_32de36ef35c08d65287ebe83118bc6d4 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDueDiligenceIdentification add constraint FK_fca259fe501b3a237f3fac91e8230c80 foreign key (xMasterId, xApprovedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDueDiligenceBinaryData_Lnk add constraint FK_0dad2ba07f19f1c841fe4c4702be8ea0 foreign key (xMasterId, xEntityId, xDueDiligenceIdentification)
		references xDueDiligenceIdentification (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xDueDiligenceBinaryData_Lnk add constraint FK_37998628576538bd505446cf101e0d36 foreign key (xMasterId, xBinaryData)
		references xBinaryData (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClientContactLink add constraint FK_1bb791bd304365ac1b9c3abbcafde053 foreign key (xMasterId, xContact)
		references xContact (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClientContactLink add constraint FK_e80317c2b3ca65a0632a819be7c2cde0 foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xInterestRate add constraint FK_56e97fd11f38a3551bff3298cd5814c5 foreign key (xMasterId, xEntityId, xInterestBase)
		references xInterestBase (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xInterestRate add constraint FK_52de4395938eec22e7ecace69743b5d0 foreign key (xMasterId, xEntityId, xCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xInterestRate add constraint FK_27388b85c09d563584088eb38c163396 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xInterestRate add constraint FK_707fb0914b6827f170efce82ac9bbac2 foreign key (xMasterId, xApprovedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClientTransactionNew add constraint FK_3b720caffe79149070fc4ebad242134c foreign key (xMasterId, xEntityId, xClientAccount)
		references xAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientTransactionNew add constraint FK_91c2631e05da0f7c1992ebcf46585934 foreign key (xMasterId, xEntityId, xAccountBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xClientTransactionNew add constraint FK_278036377ceace5e89f8c800c9e0fae0 foreign key (xMasterId, xEntityId, xTransactionBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xClientTransactionNew add constraint FK_08f455950757178c3232690e6e48a2ba foreign key (xMasterId, xEntityId, xTransactionCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xClientTransactionNew add constraint FK_b3a47fc59e3b5fce77fca81d53f959ea foreign key (xMasterId, xEntityId, xGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xClientTransactionNew add constraint FK_936ddaf559f6376844a6a02c6a61ce5f foreign key (xMasterId, xEntityId, xChannel)
		references xDeliveryChannel (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientTransactionNew add constraint FK_8571d074d278c0074391568886b3311c foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTransCodeTransFeeLink add constraint FK_f95e3c3ac7a3f4dd6725edfbb8f2f116 foreign key (xMasterId, xEntityId, xTransactionCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTransCodeTransFeeLink add constraint FK_381dbc0adc0ca18ea27455cba3d9c714 foreign key (xMasterId, xEntityId, xTransactionFee)
		references xTransactionFee (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountInterestPayable add constraint FK_aec4985a78595b7b84fe08ec7047a1b5 foreign key (xMasterId, xEntityId, xClientAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountInterestPayable add constraint FK_05f7c5f5077f9c5be4e08e823b2968aa foreign key (xMasterId, xEntityId, xInterestScheme)
		references xInterestScheme (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountInterestPayable add constraint FK_a090b8440acd591f72281b5bf9987edb foreign key (xMasterId, xEntityId, xCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xClientAccountInterestPayable add constraint FK_ff2fddcfb22b248fd3086d7179e75e90 foreign key (xMasterId, xEntityId, xCurrencyRateType)
		references xCurrencyRateType (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountInterestPayable add constraint FK_b5a477b0f6deab8d805aa16c797d252a foreign key (xMasterId, xEntityId, xInterestBase)
		references xInterestBase (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountInterestPayable add constraint FK_f83ff98ea833bca51dd887382d34fe26 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountInterestPayable add constraint FK_b88530a77509068f16b444f38b616dd1 foreign key (xMasterId, xUpdatedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCAInterestPayable_SC_Lnk add constraint FK_bd37d2e80c17d27e796df49c92502663 foreign key (xMasterId, xEntityId, xClientAccountInterestPayable)
		references xClientAccountInterestPayable (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCAInterestPayable_SC_Lnk add constraint FK_26fee866cc826b2e423e1142ca053c88 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCAInterestReceivable add constraint FK_2315428fac012e3d9416f198fd8001b0 foreign key (xMasterId, xEntityId, xClientAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCAInterestReceivable add constraint FK_408b137a41df2cf55116fed762f6a14c foreign key (xMasterId, xEntityId, xInterestSchemeAuth)
		references xInterestScheme (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCAInterestReceivable add constraint FK_0cec257210da2bb777b42d03f7d6ad25 foreign key (xMasterId, xEntityId, xInterestSchemeUnAuth)
		references xInterestScheme (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCAInterestReceivable add constraint FK_ffb4bd201c58a3d59156fd995c02bf1f foreign key (xMasterId, xEntityId, xCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xCAInterestReceivable add constraint FK_0e25791b1228b953226eef86c8c18e11 foreign key (xMasterId, xEntityId, xCurrencyRateType)
		references xCurrencyRateType (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCAInterestReceivable add constraint FK_dc215823b2cc31c8ef93b6e785bc7468 foreign key (xMasterId, xEntityId, xInterestBaseAuth)
		references xInterestBase (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCAInterestReceivable add constraint FK_df5089a5585a634c2352a94c494a59bf foreign key (xMasterId, xEntityId, xInterestBaseUnAuth)
		references xInterestBase (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCAInterestReceivable add constraint FK_c8f0d03da5da0ba3ee7860353594b558 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCAInterestReceivable add constraint FK_888ada37a10ae3d4abfb93aa245653b4 foreign key (xMasterId, xUpdatedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCAInterestReceivable_SC_Lnk add constraint FK_9571cd54f30ffc7b30d9230100021c12 foreign key (xMasterId, xEntityId, xCAInterestReceivable)
		references xCAInterestReceivable (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCAInterestReceivable_SC_Lnk add constraint FK_97d19b1ae7cdac200efc68a6e6ac8748 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountCharges add constraint FK_28a09d5ccbbfe77972fbb1514834b32f foreign key (xMasterId, xEntityId, xClientAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountCharges add constraint FK_0c532f9145a55e27abb25ed5e865c86a foreign key (xMasterId, xEntityId, xAccountOpeningFee)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountCharges add constraint FK_d68fd3af03653ddeaaabfe3ad713a768 foreign key (xMasterId, xEntityId, xServiceCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountCharges add constraint FK_1387375c1ca0c5682a3b657d628ccc6f foreign key (xMasterId, xEntityId, xMonthlyServiceCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountCharges add constraint FK_d5a6954597a15503dabb86cf8178ba2e foreign key (xMasterId, xEntityId, xNonOperatingFee)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountCharges add constraint FK_10721cc473b62299ccbe2558436f8757 foreign key (xMasterId, xEntityId, xAccountClosingFee)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountCharges add constraint FK_fe116bfc0594b54a4e4c877943e7969f foreign key (xMasterId, xEntityId, xAdditionalStatementFee)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountCharges add constraint FK_c3bd5ab6d01eb0b2dd264e46feb6de17 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountCharges add constraint FK_86fcd204021bdc7c008b34a438f483c6 foreign key (xMasterId, xUpdatedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCACharges_SC_Lnk add constraint FK_5cba89d9a74d93c4854d020d93e2cbf2 foreign key (xMasterId, xEntityId, xClientAccountCharges)
		references xClientAccountCharges (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCACharges_SC_Lnk add constraint FK_a43e0affc5cf9f7c3cb135bac9bf1217 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCAAdditionalCharges add constraint FK_46cf6b03742f285abbc5221b06cabbb2 foreign key (xMasterId, xEntityId, xClientAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCAAdditionalCharges add constraint FK_2a4648be3b09799cd528e829cdd76950 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCAAdditionalCharges add constraint FK_f8dad20ecbb67f63f6edb5d6334376b3 foreign key (xMasterId, xEntityId, xAdditionalCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCAAdditionalCharges_SC_Lnk add constraint FK_f71d3d1e874410b0705a3f98be73c5f4 foreign key (xMasterId, xEntityId, xCAAdditionalCharges)
		references xCAAdditionalCharges (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCAAdditionalCharges_SC_Lnk add constraint FK_a92cdae39ff7f6c0941f327e24d3698d foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountSettings add constraint FK_442854b9e46cd67841652b35276aa8f4 foreign key (xMasterId, xEntityId, xClientAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountSettings add constraint FK_b2dd495848ddf8cb3c835cdf4a728c4c foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountSettings add constraint FK_4d194bf7d780d2a2fc489caa3af17bd5 foreign key (xMasterId, xUpdatedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCASettings_SC_Lnk add constraint FK_2a5860ea16d37ab6d878ad6a4fa7d3ef foreign key (xMasterId, xEntityId, xClientAccountSettings)
		references xClientAccountSettings (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCASettings_SC_Lnk add constraint FK_cd249e038862194027e624a6b477db3e foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountSignatory add constraint FK_272a927c7a8b874bea921e3f525c0908 foreign key (xMasterId, xEntityId, xClientAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountSignatory add constraint FK_a44f1a7c4dcc294b0972503cbadae646 foreign key (xMasterId, xEntityId, xPerson)
		references xClientContactLink (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountSignatory add constraint FK_5320e8e1012a21ca642b18d02037183e foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountSignatory add constraint FK_f4acb75c160bc430188726c63b701059 foreign key (xMasterId, xUpdatedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCASignatory_SC_Lnk add constraint FK_d08331d1946e9212c76b1f92cd0aa859 foreign key (xMasterId, xEntityId, xClientAccountSignatory)
		references xClientAccountSignatory (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCASignatory_SC_Lnk add constraint FK_7416a7fd744a8352b7539bb8b9eed5a8 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountStatus add constraint FK_8fc834149ea611d05a1c444963b1b8ec foreign key (xMasterId, xEntityId, xClientAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountStatus add constraint FK_7509f980653679718d0bc87000254c18 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCAStatus_SC_Lnk add constraint FK_a28890768a6a3e28040e04ba20543001 foreign key (xMasterId, xEntityId, xClientAccountStatus)
		references xClientAccountStatus (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCAStatus_SC_Lnk add constraint FK_adfd93e15627012d991688cdac3d4da4 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountClosure add constraint FK_249494cf49d74b84ffb1dae50b441131 foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountClosure add constraint FK_044632b943e5ec4c56afd19892825ec9 foreign key (xMasterId, xEntityId, xAccountNumber)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountClosure add constraint FK_a141fdc0c8c0a106cacab32091358f32 foreign key (xMasterId, xEntityId, xClientTo)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountClosure add constraint FK_91439bdc14d76f747f4c3c6b6508f80b foreign key (xMasterId, xEntityId, xAccountTo)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountClosure add constraint FK_b2d3d9357b9bf77d860d72046be4a8b6 foreign key (xMasterId, xEntityId, xCashPayoutBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xClientAccountClosure add constraint FK_96fb814c9d1e9c767f1c9af41f8d52eb foreign key (xMasterId, xEntityId, xCashGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xClientAccountClosure add constraint FK_d48e294c6023be6c2bf0d1b1a81ce4b8 foreign key (xMasterId, xPayoutBank)
		references xSettlementDirectory (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountClosure add constraint FK_b5789de9aad0dec894e1be6d971e06fd foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCAClosure_SC_Lnk add constraint FK_a57570498f3d5e9938ff4a24f81f8b08 foreign key (xMasterId, xEntityId, xClientAccountClosure)
		references xClientAccountClosure (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCAClosure_SC_Lnk add constraint FK_31173bbd2847adff3c1828242bc89837 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xElectronicFundTransfer add constraint FK_e066031fc2acbb5d3b3335bac7f91732 foreign key (xMasterId, xAddress)
		references xAddress (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xElectronicFundTransfer add constraint FK_504a4155affd87dca4ee3caf9c37a38f foreign key (xMasterId, xEntityId, xBankAccount)
		references xBankAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTransactionFee add constraint FK_792a2746f74302126e3a56bcf2ba09aa foreign key (xMasterId, xEntityId, xTransactionFeeProfile)
		references xTransactionFeeProfile (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTransactionFee add constraint FK_57b430d41d17b7b9297a33fabc9ce7ff foreign key (xMasterId, xFeeSchedule)
		references xFeeSchedule (xMasterId, xCode) on delete restrict on update restrict;

alter table xTransactionFee add constraint FK_8cb3a3a49fa20320f4c707f604f21163 foreign key (xMasterId, xEntityId, xGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xPayment add constraint FK_81c52f4671d8b2594f1655a08c14e128 foreign key (xMasterId, xEntityId, xClientAccountToDebit)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xPayment add constraint FK_f15cc27756d604e2a8eb48745e8cc1cd foreign key (xMasterId, xEntityId, xGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xPayment add constraint FK_bb12cbe25220b5ea63aabeecabb35285 foreign key (xMasterId, xEntityId, xTransactionDefault)
		references xTransactionDefault (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPayment add constraint FK_3026a82d87f54ce500f0b33dee09d0d6 foreign key (xMasterId, xEntityId, xCashGLAccountGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xPayment add constraint FK_8608ca09830edcd6e5cb5a6b9576b0ab foreign key (xMasterId, xEntityId, xCashGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPayment add constraint FK_4ad412ae498ee0a1d66ba39cb129d0f6 foreign key (xMasterId, xEntityId, xTransactionCodeDB)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPayment add constraint FK_0c9b3e349723583528f16bfff7b1bc84 foreign key (xMasterId, xEntityId, xTransactionCodeCR)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPayment add constraint FK_cb618ee9d7ad564d034cb9e589ecb86b foreign key (xGLBatch, xMasterId, xEntityId)
		references xGLBatch (xAutoId, xMasterId, xEntityId) on delete restrict on update restrict;

alter table xPayment_BinaryDatas_Lnk add constraint FK_9b17547d13e4f9231737c0fe2deab1d2 foreign key (xMasterId, xEntityId, xPayment)
		references xPayment (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xPayment_BinaryDatas_Lnk add constraint FK_46bf8ad6a02e74471550711c28f12314 foreign key (xMasterId, xBinaryData)
		references xBinaryData (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPayment_StatusChanges_Lnk add constraint FK_4df2c3b2914c527c98e1b7fe0c5d3e40 foreign key (xMasterId, xEntityId, xPayment)
		references xPayment (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xPayment_StatusChanges_Lnk add constraint FK_93ff70776c5792f9db746cdf4847ddb4 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountIdentifier add constraint FK_d507c76f491955003862164e850db6bb foreign key (xMasterId, xEntityId, xClientAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClient add constraint FK_00e14d97799a009a51efefcd5020d0ae foreign key (xMasterId, xEntityId, xOwnerBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xClient add constraint FK_32754e1e35942d30e64c80680d12c4be foreign key (xMasterId, xEntityId, xOriginBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xClient add constraint FK_59b29f1def67343a0221b7cd4f962575 foreign key (xMasterId, xAccountManager)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClient add constraint FK_d13d41a3b9a9dd1e4a81a6703606bf86 foreign key (xMasterId, xEntityId, xAgent)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClient add constraint FK_9da284b0d83917660cf056abc21cece1 foreign key (xMasterId, xFeeSchedule)
		references xFeeSchedule (xMasterId, xCode) on delete restrict on update restrict;

alter table xClient add constraint FK_1b0c251c4443d362dadc091f28258dcd foreign key (xMasterId, xLanguageOfCommunication)
		references xLanguage (xMasterId, xCode) on delete restrict on update restrict;

alter table xClient add constraint FK_cf17d6ed5f09581950d8b1c823c977e4 foreign key (xMasterId, xEntityId, xAMLCategory)
		references xAmlCategory (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClient add constraint FK_d0beb24114720cca168ec5b2a76c7dbe foreign key (xMasterId, xEntityId, xPricingCategory)
		references xRelationshipPricing (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClient add constraint FK_9a16c3a3b222fd97c4009f1ff10609ec foreign key (xMasterId, xEntityId, xOfferingCategory)
		references xOffering (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClient add constraint FK_c60b509b7b0c806437dd3243772c078c foreign key (xMasterId, xRiskCountry)
		references xCountry (xMasterId, xAlpha3Code) on delete restrict on update restrict;

alter table xClient_Diaries_Lnk add constraint FK_bebec9dbf9a4f3cabcfc36d7be8b400e foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClient_Diaries_Lnk add constraint FK_8ea688eb8c677d9d048ebadaaeba5b12 foreign key (xMasterId, xDiary)
		references xDiary (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClient_Categories_Lnk add constraint FK_4da6c5c830e4f763d882e47828838449 foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClient_Categories_Lnk add constraint FK_195144d6f85da5d635fb12d8c3da1db7 foreign key (xMasterId, xEntityId, xCategory)
		references xCategory (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClient_Documents_Lnk add constraint FK_465f29e450b70c88cf865c9154a89242 foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClient_Documents_Lnk add constraint FK_3e419b88e651eebc9c6fe2990c9eef1b foreign key (xMasterId, xDocument)
		references xDocument (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClient_BankAccounts_Lnk add constraint FK_693249ffdcdcb12ec83243bed65f215c foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClient_BankAccounts_Lnk add constraint FK_481b8f65d3d2915ba00fcfbfeca3d409 foreign key (xMasterId, xEntityId, xBankAccount)
		references xBankAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTransfer add constraint FK_d8ca8df29b135e8dd42de693f733bf10 foreign key (xMasterId, xEntityId, xAccountToDebit)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTransfer add constraint FK_37bb3fc26b689159a8d9641d784c56a6 foreign key (xMasterId, xEntityId, xAccountToCredit)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTransfer add constraint FK_1fb62c2384aaba87decb9e8b1c3640a5 foreign key (xMasterId, xEntityId, xGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xTransfer add constraint FK_a3600c2196e0ddbe5b7d5942fd4fba8e foreign key (xMasterId, xEntityId, xTransactionDefault)
		references xTransactionDefault (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTransfer add constraint FK_788cff870e661dbc684244fb6bcc4a2f foreign key (xMasterId, xEntityId, xTransactionCodeDB)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTransfer add constraint FK_e6713386e1209a41e5bba89fa9261c92 foreign key (xMasterId, xEntityId, xTransactionCodeCR)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTransfer add constraint FK_9bd479dd489c2b855d35c0e54f3e8df8 foreign key (xGLBatch, xMasterId, xEntityId)
		references xGLBatch (xAutoId, xMasterId, xEntityId) on delete restrict on update restrict;

alter table xTransfer_BinaryDatas_Lnk add constraint FK_4c89d6b8feb0b7d9a4bba77985b9b540 foreign key (xMasterId, xEntityId, xTransfer)
		references xTransfer (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTransfer_BinaryDatas_Lnk add constraint FK_33b6c7801f75242c0bf454ffaf82f767 foreign key (xMasterId, xBinaryData)
		references xBinaryData (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTransfer_StatusChanges_Lnk add constraint FK_3a16ffba6d3ce51c126e10bb5210565a foreign key (xMasterId, xEntityId, xTransfer)
		references xTransfer (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTransfer_StatusChanges_Lnk add constraint FK_19f3627bff1de51be2f294a516b398ee foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xBankersDraft add constraint FK_47d78ff7d2cc692e3d625beff5805dba foreign key (xMasterId, xAddress)
		references xAddress (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDueDiligenceEmployment add constraint FK_98c6cceca25b95a11e0795d4e0d54ef9 foreign key (xMasterId, xContact)
		references xContact (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDueDiligenceEmployment add constraint FK_f11f07c8625b3d75ccdee01fe8ed8cd8 foreign key (xMasterId, xOrganization)
		references xOrganisation (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDueDiligenceEmployment add constraint FK_49dece8b28ce81142a984282e8bf2ebe foreign key (xMasterId, xSallaryCurrency)
		references xCurrency (xMasterId, xCode) on delete restrict on update restrict;

alter table xDueDiligenceEmployment add constraint FK_3a1dd0a0dbbfd2740033cc5d4c32d0fa foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDueDiligenceEmployment add constraint FK_6dd00093031f84c050aa5ded44c340f1 foreign key (xMasterId, xApprovedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xInterestSetting add constraint FK_1f5ee16831c866a61878dd8d9888b98e foreign key (xMasterId, xEntityId, xInterestBase)
		references xInterestBase (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xInterestSetting add constraint FK_3ac62f7109f4943dd7f8ad520af65b68 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xInterestSetting add constraint FK_d47f683ab25622c06af7fb8b08ae6b95 foreign key (xMasterId, xApprovedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDueDiligenceSourceOfFund add constraint FK_4b4bca91c942a563f1aa5d45e568ae44 foreign key (xMasterId, xContact)
		references xContact (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDueDiligenceSourceOfFund add constraint FK_d4bca42938604b9c1b1c55142049eaee foreign key (xMasterId, xCurrency)
		references xCurrency (xMasterId, xCode) on delete restrict on update restrict;

alter table xDueDiligenceSourceOfFund add constraint FK_c093995287d679f14460e51d1032b3ab foreign key (xMasterId, xEntityId, xSource)
		references xSourceOfFund (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xDueDiligenceSourceOfFund add constraint FK_5a18ea50bc4b6e142e0b84707770b31a foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDueDiligenceSourceOfFund add constraint FK_8f9b2f6a28634323e76dbf4fe79e73c1 foreign key (xMasterId, xApprovedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xProductInterestPayable add constraint FK_98f67996bd97c6c4375e979ea13eec44 foreign key (xMasterId, xEntityId, xInterestScheme)
		references xInterestScheme (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProductInterestPayable add constraint FK_d455fbffa77c251acc8d64adf51ac551 foreign key (xMasterId, xEntityId, xCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xProductInterestPayable add constraint FK_ac0efa95f2debbaa0398fb417784a2ec foreign key (xMasterId, xEntityId, xCurrencyRateType)
		references xCurrencyRateType (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProductInterestPayable add constraint FK_928ed9f1e858253c627d32f4672264f9 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xProductInterestPayable_SC_Lnk add constraint FK_0ef5c2ec64479e46e1cdfa5903bfc9f5 foreign key (xMasterId, xEntityId, xProductInterestPayable)
		references xProductInterestPayable (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProductInterestPayable_SC_Lnk add constraint FK_7eae8dcc9dafe691fa38df722b323a21 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xProductInterestReceivable add constraint FK_32bc3b178ff3f5623f636860b08f5c5a foreign key (xMasterId, xEntityId, xInterestSchemeAuthorised)
		references xInterestScheme (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProductInterestReceivable add constraint FK_f44de29d945fb38a41b212fc15b8f1b1 foreign key (xMasterId, xEntityId, xInterestSchemeUnAuthorised)
		references xInterestScheme (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProductInterestReceivable add constraint FK_6f357feb46164763f30ea9847552c4f4 foreign key (xMasterId, xEntityId, xCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xProductInterestReceivable add constraint FK_84985b181e3fe8e59b43c55e216d7abc foreign key (xMasterId, xEntityId, xCurrencyRateType)
		references xCurrencyRateType (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProductInterestReceivable add constraint FK_bb0d9905e7ff8c88ee12edd4a0e267f6 foreign key (xMasterId, xEntityId, xPrincipalOverDueScheme)
		references xInterestScheme (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProductInterestReceivable add constraint FK_169564db7bdfc27b2921f5a3afa5324c foreign key (xMasterId, xEntityId, xInterestOverDueScheme)
		references xInterestScheme (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProductInterestReceivable add constraint FK_d649188e7c7876450563a34255316232 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xProductInterestRec_SC_Lnk add constraint FK_77af894b2e37925fd457abb893f03ca4 foreign key (xMasterId, xEntityId, xProductInterestReceivable)
		references xProductInterestReceivable (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProductInterestRec_SC_Lnk add constraint FK_107453ff5cf03d5c96a5841fc20a4b87 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xProductProfileGLCurrencyLink add constraint FK_5eb2adf60176e0a5dd88179c7e2123c6 foreign key (xMasterId, xEntityId, xProductProfile)
		references xProductProfile (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfileGLCurrencyLink add constraint FK_89b0434f0d74532d616143de9dc5dc54 foreign key (xMasterId, xEntityId, xLoanProduct)
		references xLoanProduct (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfileGLCurrencyLink add constraint FK_0d4e46392b6b1267245d6053fbd9b385 foreign key (xMasterId, xEntityId, xCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xTermBand add constraint FK_a5ff652bae6f389ab93e11308183d6ff foreign key (xMasterId, xEntityId, xInterestScheme)
		references xInterestScheme (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermBand add constraint FK_538119fcea19888f07f0cce5e1833841 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTermBand_StatusChanges_Lnk add constraint FK_d929d3c990df4268f20ca8b5a108c06a foreign key (xMasterId, xEntityId, xTermBand)
		references xTermBand (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermBand_StatusChanges_Lnk add constraint FK_326628e90f45db461b0e505f77c5ee72 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xProduct add constraint FK_f2a43a4781fa6171036047db557f848b foreign key (xMasterId, xEntityId, xMasterGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct add constraint FK_4eff2b9e6c0dce8256024b4410bf2620 foreign key (xMasterId, xEntityId, xTaxWithHeld)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct add constraint FK_fe28fa7fd7f7fd3cf756191006c7b1cc foreign key (xMasterId, xEntityId, xAgentCommission)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct add constraint FK_dc58c4a11b72b29a8fd756de495a7854 foreign key (xMasterId, xEntityId, xMasterLegDBGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct add constraint FK_36ef03510d7b276a6ad5578fc0331694 foreign key (xMasterId, xEntityId, xMasterLegCRGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct add constraint FK_ccf7d3cac091a58a056867e37818ad9e foreign key (xMasterId, xEntityId, xInterestAccruedDBGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct add constraint FK_b4fce4fb4b319a91d7e61df2289f91d7 foreign key (xMasterId, xEntityId, xInterestAccruedCRGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct add constraint FK_f62a59315cb16a056293c90c21f8c6e4 foreign key (xMasterId, xEntityId, xInterestAdjustmentDBGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct add constraint FK_8ee0805628b10190ba45c9f79be123e4 foreign key (xMasterId, xEntityId, xInterestAdjustmentCRGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct add constraint FK_1fcde1b640d3909ed07d9fe76c8999f2 foreign key (xMasterId, xEntityId, xTaxWithheldDBClient)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct add constraint FK_5f5352de28016d5edcf25aa001324225 foreign key (xMasterId, xEntityId, xTaxWithheldCRGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct add constraint FK_d10c5a1170f6b1d479119a0dd861bfc9 foreign key (xMasterId, xEntityId, xTaxWithheldDBGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct add constraint FK_3d12d7316ba6e6fb50aaa162e1c91ed2 foreign key (xMasterId, xEntityId, xCommissionExpensesDBGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct add constraint FK_15c6de02f3733d5d793c196a0bfc59ab foreign key (xMasterId, xEntityId, xCommissionExpensesCRClient)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct add constraint FK_839949f9fedcf2d43a3f056e46cfefd4 foreign key (xMasterId, xEntityId, xFromClientAccountDBClient)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct add constraint FK_dcc0a302922c570b350da4acb87868ce foreign key (xMasterId, xEntityId, xToClientAccountCRClient)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct add constraint FK_a1c29b7ac39fe8294dee416411754852 foreign key (xMasterId, xEntityId, xStatementFormat)
		references xStatementFormat (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProduct_InterestPayables_Lnk add constraint FK_60df49a20c0f6881aae191dec3061e15 foreign key (xMasterId, xEntityId, xProduct)
		references xProduct (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct_InterestPayables_Lnk add constraint FK_3a9ba75bad1364d4edf49e9b34445621 foreign key (xMasterId, xEntityId, xProductInterestPayable)
		references xProductInterestPayable (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProduct_InterestRec_Lnk add constraint FK_20a9770127f22e3956090ed49300c6e1 foreign key (xMasterId, xEntityId, xProduct)
		references xProduct (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct_InterestRec_Lnk add constraint FK_aebcaca28d80871a028049ce706b4c95 foreign key (xMasterId, xEntityId, xProductInterestReceivable)
		references xProductInterestReceivable (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProduct_Branches_Lnk add constraint FK_0270f5b36a0665a3b260c61efd595796 foreign key (xMasterId, xEntityId, xProduct)
		references xProduct (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct_Branches_Lnk add constraint FK_48409b01efd706927a779166e3a333de foreign key (xMasterId, xEntityId, xBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct_TransactionCodes_Lnk add constraint FK_76d0a02aca2d8afee73ddbebfb14f7a9 foreign key (xMasterId, xEntityId, xProduct)
		references xProduct (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct_TransactionCodes_Lnk add constraint FK_ca6d98936d1957967f4fa27555c4cd7d foreign key (xMasterId, xEntityId, xTransactionCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct_Clients_Lnk add constraint FK_ae9277b66cd3953b01f425f3a4e5ce5d foreign key (xMasterId, xEntityId, xProduct)
		references xProduct (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct_Clients_Lnk add constraint FK_709fb503de7b21281d0bebdd84d70940 foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProduct_Offerings_Lnk add constraint FK_2233e816e7b45628fe0df0b52f8da581 foreign key (xMasterId, xEntityId, xProduct)
		references xProduct (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct_Offerings_Lnk add constraint FK_9eacae43123a356ebd102447731e5e23 foreign key (xMasterId, xEntityId, xOffering)
		references xOffering (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProduct_TermBands_Lnk add constraint FK_04f73756d97d9d0321b3fab258a2c388 foreign key (xMasterId, xEntityId, xProduct)
		references xProduct (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProduct_TermBands_Lnk add constraint FK_21e7a629c3bec86f1ba3d3b04324f130 foreign key (xMasterId, xEntityId, xTermBand)
		references xTermBand (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProduct add constraint FK_c43b1927537e8f150e72892904999ad2 foreign key (xMasterId, xEntityId, xAccountOpeningCommission)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProduct add constraint FK_0e31a7c2038996c8427bfc1a3651dcb9 foreign key (xMasterId, xEntityId, xAccountManagementCommission)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_1728af08e2db1bbf1c43911066937733 foreign key (xMasterId, xEntityId, xAccountOpeningFee)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_2f73659eaa9970a447c6728358aa7275 foreign key (xMasterId, xEntityId, xServiceChargeAmount)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_f381acd39f3d1d58a5f587b98c375c4b foreign key (xMasterId, xEntityId, xServiceChargePercentage)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_acfd5ce145d558ebab656126fbe3d14c foreign key (xMasterId, xEntityId, xNonOperationFee)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_54949c67ac0627945f1835cb6e45d728 foreign key (xMasterId, xEntityId, xAccountClosingFee)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_f8a7f5493663470becdefa076da267f2 foreign key (xMasterId, xEntityId, xStatementFee)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_aa5534384ebba2d39d12aaaba9cc8a88 foreign key (xMasterId, xEntityId, xAdditionalStatementFee)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_a43928bb653c544e435f5bac5f077dd7 foreign key (xMasterId, xEntityId, xInterestPaid)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_f5226178d40088b921fc1d51b3b0cb69 foreign key (xMasterId, xEntityId, xInterestEarned)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_4b1c81461d5ee24b0eb46c729c7cdf91 foreign key (xMasterId, xEntityId, xInterestAccruedPayable)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_2bfdb67afdd95f83c54333055b793395 foreign key (xMasterId, xEntityId, xInterestAccruedReceivable)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_cc0368a403daa61fedf368cb79428439 foreign key (xMasterId, xEntityId, xInterestAdjustmentIncome)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_a76f437f529ece2530ffe2577c71c682 foreign key (xMasterId, xEntityId, xInterestAdjustmentExpense)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_81b522e966054818512ae400d7d0a39c foreign key (xMasterId, xEntityId, xDepositMaturedPayableGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_18d7f6a4ba7aab5988e5e626b91a2474 foreign key (xMasterId, xEntityId, xPayoutGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_614b4c98358850e506ddba5544534591 foreign key (xMasterId, xEntityId, xDepositOpeningReceivableGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_bbca68ef42fef9d5e3ec93c8d6ab7f70 foreign key (xMasterId, xEntityId, xPrematurePenaltyGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_83f410424c7bd108aef91289141c125a foreign key (xMasterId, xEntityId, xInterestPaidDBGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_0f925cc5a82c1ce6c7996f31e66441c3 foreign key (xMasterId, xEntityId, xInterestPaidCRClient)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_5ece2f8868be2c46bea155174e902d67 foreign key (xMasterId, xEntityId, xInterestPaidCRGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_037bf50f2c6b8c2641734bdbaa206354 foreign key (xMasterId, xEntityId, xInterestReceivedDBClient)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_9e7e3a70c1b786f9b657e5265e641b97 foreign key (xMasterId, xEntityId, xInterestReceivedCRGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_de37a691a47208ec5cca5fa1d772d7c8 foreign key (xMasterId, xEntityId, xDepositOpeningReceivableDBGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_3f602866cf8024a46963c218ccea977f foreign key (xMasterId, xEntityId, xByCashDBGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_9d46c279a960ba82d2f43081360f33d3 foreign key (xMasterId, xEntityId, xTermDepositClientAccCRClient)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_d3ebc1493cc3cc354f5a4d797255bac9 foreign key (xMasterId, xEntityId, xTermDepositAccountDBClient)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_0500783b8eac1a0e3c2aad4d96af76f3 foreign key (xMasterId, xEntityId, xDepositMaturedPayableCRGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_bcc722f22d9bdc8c7afbe3c4f0dce3b2 foreign key (xMasterId, xEntityId, xDepositMaturedPayableDBGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_c1dcd0e7dd3cec240ef6696c43530c3d foreign key (xMasterId, xEntityId, xByCashCRGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_5e6426b675b3a7ce6e68ee865de90a84 foreign key (xMasterId, xEntityId, xPenaltyAmountCRGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_0032081edbc327f7b90668827aee6ad7 foreign key (xMasterId, xEntityId, xAccountClosureDBClient)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_293682e6094feafaf392dc8ed022da06 foreign key (xMasterId, xEntityId, xAccountClosureCRClient)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductProfile add constraint FK_a8b08217bab348869645299088512c6f foreign key (xMasterId, xEntityId, xAccountClosureCRGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_c473636b0d7c8561b42ef7fc28732134 foreign key (xMasterId, xEntityId, xInterestEarned)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_16f52ff85bda2c9ac8695b31408c3d88 foreign key (xMasterId, xEntityId, xInterestAccruedReceivable)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_aa556e429318ab9471576066328b1b95 foreign key (xMasterId, xEntityId, xInterestReceivedDBClient)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_14821ecfbfee4f760594ca1eb68f7684 foreign key (xMasterId, xEntityId, xInterestReceivedDBGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_bb0f5c8f9c7d141392fbb4de9d496fd1 foreign key (xMasterId, xEntityId, xInterestReceivedCRGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_4fa58c12f6c245edf520020ec0e036e9 foreign key (xMasterId, xEntityId, xCcyRateForDisbursement)
		references xCurrencyRateType (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_1cf446dfdf6629bc584e8d2780c39a23 foreign key (xMasterId, xEntityId, xCcyRateForRepayment)
		references xCurrencyRateType (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_7dfbb3b5a526fbe77a8c2f89f825042b foreign key (xMasterId, xEntityId, xCcyRateForCharge)
		references xCurrencyRateType (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_67bd014fa68f3f818f7bef434adc3464 foreign key (xMasterId, xEntityId, xPenalInterestEarnedGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_e5f665d2c5fbb35a824fdf173c4df11c foreign key (xMasterId, xEntityId, xPenalInterestAccruedGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_623d61fd39082c7b6afd2fafed6f231c foreign key (xMasterId, xEntityId, xSuspenseGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_fb42ca460aab850c0c795bced3347f5a foreign key (xMasterId, xEntityId, xCashGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_18c7c6e920b2c9415ab7f7a0e6a8ff67 foreign key (xMasterId, xEntityId, xLoanDisbursementDBGLTxnCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_a674e907c3ddc894c2885443ff8ae525 foreign key (xMasterId, xEntityId, xLoanDisbursementCRGLTxnCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_69f7fd4648deb67bdf32361acb13f42b foreign key (xMasterId, xEntityId, xLoanDisbursementDBACTxnCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_74ac55a0412045ddc30931e3bce12155 foreign key (xMasterId, xEntityId, xLoanDisbursementCRACTxnCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_3fe047ca617e4cfce57015158cc105bb foreign key (xMasterId, xEntityId, xLoanPaymentDBACTxnCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_fc47596a4c4b8e6a1baf88c1819bd6ed foreign key (xMasterId, xEntityId, xLoanPaymentCRACTxnCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_0c0c3598fc84d52621afd4dfd41e3c77 foreign key (xMasterId, xEntityId, xLoanPaymentDBGLTxnCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_2fd51d2bc2c19dc4b8896f239a3dfa79 foreign key (xMasterId, xEntityId, xLoanPaymentCRGLTxnCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_2dc15b005ceb7ae65bb45cad533276be foreign key (xMasterId, xEntityId, xPenalIntAccruedDBGLTxnCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_af3d771cda36aba6444c38ef0aec5e6a foreign key (xMasterId, xEntityId, xPenalIntAccruedCRGLTxnCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_ae8a178d8d1e5bfbdcc83233d4a77c98 foreign key (xMasterId, xEntityId, xPenalIntReceivedDBACTxnCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_9ac7bf642c2973ce95eded40d4ae071c foreign key (xMasterId, xEntityId, xPenalIntReceivedDBGLTxnCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_d59cb1d7f22d09924779cc3e293715c5 foreign key (xMasterId, xEntityId, xPenalIntReceivedCRGLTxnCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_d8ca0f08264fddb8dac8872ece98066a foreign key (xMasterId, xEntityId, xProcessingFee)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_d52e7ae755c91df117c722d20cbebfef foreign key (xMasterId, xEntityId, xServiceCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_29fe2557fcadbc01bafeefc6a61b9cc5 foreign key (xMasterId, xEntityId, xDocumentationCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_8e64ca053ccc087219a832c81b7efc3c foreign key (xMasterId, xEntityId, xLegalCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_48b0d61ca8e9c71f911bd20375306170 foreign key (xMasterId, xEntityId, xPrePaymentCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_84b2e0060ca07a0f758b9bc818e5de9c foreign key (xMasterId, xEntityId, xInstallmentFee)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_2100df030b226de86484a2fa54720702 foreign key (xMasterId, xEntityId, xLatePaymentFee)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_eaf6477445ef4d83b8f3b9a2c097790f foreign key (xMasterId, xEntityId, xNPLLedger)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLoanProduct add constraint FK_f9c464ae288d72aee3e77ff53a4964e4 foreign key (xMasterId, xEntityId, xStatementFee)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProductAdditionalCharge add constraint FK_2951e3b8a146c5547e33359fecfc32ae foreign key (xMasterId, xEntityId, xProductProfile)
		references xProductProfile (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProductAdditionalCharge add constraint FK_0a76121c4d9a53dd253037cca3f2b3c2 foreign key (xMasterId, xEntityId, xCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositStatus add constraint FK_da0f8fd1aba1217cdeaa469696eacf76 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositStatus_SC_Lnk add constraint FK_c730a96e8b60319994614e392121fb37 foreign key (xMasterId, xEntityId, xTermDepositStatus)
		references xTermDepositStatus (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositStatus_SC_Lnk add constraint FK_71d1b58ea6b5eb3b0a69a0eef4a861a5 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositSetting add constraint FK_b4e5226b2532fa6ae842fdeb17922053 foreign key (xMasterId, xEntityId, xFromClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositSetting add constraint FK_83514572c95ab288883a13118dab5582 foreign key (xMasterId, xEntityId, xFromLedger)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTermDepositSetting add constraint FK_c1f1cf55060ad96dccc6a90b15062900 foreign key (xMasterId, xFromBank)
		references xSettlementDirectory (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositSetting add constraint FK_8562bfda5f2b530c3788d50283bcffb6 foreign key (xMasterId, xEntityId, xToClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositSetting add constraint FK_74ce5623e4b9417dc4470aedc7f9583b foreign key (xMasterId, xToBank)
		references xSettlementDirectory (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositSetting add constraint FK_b089e8c0384a04eb444a28acb86321ee foreign key (xMasterId, xEntityId, xPayoutClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositSetting add constraint FK_fa589c007eb5ddcf99a9d0540a939bff foreign key (xMasterId, xPayoutBank)
		references xSettlementDirectory (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositSetting add constraint FK_860677ef575e2b9843d2ec6df5a63aea foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositSetting add constraint FK_2f714c05e22e6180fbc99b8161eac2b8 foreign key (xMasterId, xUpdatedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositSetting_SC_Lnk add constraint FK_32ed01cde3e17e895043dcb1eb3d87b5 foreign key (xMasterId, xEntityId, xTermDepositSetting)
		references xTermDepositSetting (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositSetting_SC_Lnk add constraint FK_d7765c8fe63cd3dee45c262b07b669b8 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xBlockedAmount add constraint FK_c0447c954b893225955889a45e352ddc foreign key (xMasterId, xEntityId, xCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xBlockedAmount add constraint FK_ce8336f6aa423b695726226d3276d268 foreign key (xMasterId, xEntityId, xRateType)
		references xCurrencyRateType (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xBlockedAmount add constraint FK_d4e3a4c3db2e507b21dab6948b66eb3d foreign key (xMasterId, xEntityId, xCategory)
		references xBlockCategory (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xBlockedAmount add constraint FK_1c02f448b197663cb08e7eba14872723 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xBlockedAmount_SC_Lnk add constraint FK_afe20def5c978d2cd2e2fd6a3bd5b7d2 foreign key (xMasterId, xEntityId, xBlockedAmount)
		references xBlockedAmount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xBlockedAmount_SC_Lnk add constraint FK_8842e7a479426df574982cacc33a5092 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xStatement add constraint FK_dfcaa9a3ab51c24df8954b99c45dd967 foreign key (xMasterId, xEntityId, xFormat)
		references xStatementFormat (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xStatement add constraint FK_05519798c7e6cdf08227185c0fa0eebf foreign key (xMasterId, xEntityId, xStatementFee)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositInterest add constraint FK_c2e5f3b74ba8154cb7709d209e6685cc foreign key (xMasterId, xEntityId, xInterestBase)
		references xInterestBase (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositInterest add constraint FK_34fddbf7cbaf0d7ce2498ba817d0a394 foreign key (xMasterId, xEntityId, xCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xTermDepositInterest add constraint FK_bedc0f93ff781b4c169a2ec68e96893e foreign key (xMasterId, xEntityId, xCurrencyRateType)
		references xCurrencyRateType (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositInterest add constraint FK_fce3d3ce1fdc665284be44032d0ffed3 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositInterest add constraint FK_a40d2f7730a61e0346e4756392619162 foreign key (xMasterId, xUpdatedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositInterest_SC_Lnk add constraint FK_8cd9b8fc806336e38fa02a1b425f4e35 foreign key (xMasterId, xEntityId, xTermDepositInterest)
		references xTermDepositInterest (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositInterest_SC_Lnk add constraint FK_67436dad0d0294e6c98f2df895bc4c70 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDueDiligenceBankDetails add constraint FK_f483162d877629969b31130a9935b9aa foreign key (xMasterId, xContact)
		references xContact (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDueDiligenceVerification add constraint FK_0da46405d758ef4b45cf672d08ffc210 foreign key (xMasterId, xContact)
		references xContact (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xExternalProductMapping add constraint FK_b0d02fa7ba279e9c88a2ee719f7be6be foreign key (xMasterId, xExternalSystem)
		references xInterfaceDefinition (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositRedemption add constraint FK_7dcde9276b93ae592da6ec6f1bc899ce foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositRedemption add constraint FK_aa4616b3fd2031a6e0807b375707c70a foreign key (xMasterId, xEntityId, xAccountNumber)
		references xTermDepositAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositRedemption add constraint FK_0e0f59441e85a7e77b49ea484039b6cc foreign key (xMasterId, xEntityId, xToClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositRedemption add constraint FK_aa83df767066a248bc331c7d9130d06a foreign key (xMasterId, xEntityId, xToInternalAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositRedemption add constraint FK_eb2e5eae2d5febcaab1673098e374c0e foreign key (xMasterId, xToBank)
		references xSettlementDirectory (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositRedemption add constraint FK_1f1f47c59fb8690dfebde3bd99b9038c foreign key (xMasterId, xEntityId, xDepositMaturedPayableGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTermDepositRedemption add constraint FK_7aa629711e6715893ea2459d1f5ea8f9 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositRedemption_SC_Lnk add constraint FK_551b85b220561db6fbe61c58605588ff foreign key (xMasterId, xEntityId, xTermDepositRedemption)
		references xTermDepositRedemption (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositRedemption_SC_Lnk add constraint FK_e73a90e9ba743d5e718edf05450b249f foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xAccruedInterest add constraint FK_614c5436e6b2581b07e0b0a366d35a08 foreign key (xMasterId, xEntityId, xAccount)
		references xAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xManualInterestAccrAdjustment add constraint FK_2506329b4b3595dc8823fcd64fffe5d7 foreign key (xMasterId, xEntityId, xAccount)
		references xAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xAccountEventLog add constraint FK_e127643ada57b46bf190022eb055cb20 foreign key (xMasterId, xEntityId, xAccount)
		references xAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xAccountEventLog add constraint FK_a3d4304ad3f4b2601575e9f5a62a9415 foreign key (xMasterId, xEntityId, xAccountBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xAccountEventLog add constraint FK_a20a101bcc379bc4fe73d77e2a9a4bc6 foreign key (xMasterId, xEntityId, xEventMaster)
		references xEventMaster (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xAccountEventLog add constraint FK_c7ef37b24f2b2f67879661fa4dc0ee36 foreign key (xMasterId, xEntityId, xAdditionalCharge)
		references xCAAdditionalCharges (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xAccountEventLog add constraint FK_5fd785310310d07c53afb38408da0382 foreign key (xMasterId, xEntityId, xBlockedAmount)
		references xBlockedAmount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xAccountEventLog add constraint FK_ada26a01876f9bb202ad09cb652e98b5 foreign key (xMasterId, xEntityId, xStatement)
		references xStatement (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xAccount add constraint FK_486cfda92ba182ede59063d63646cf81 foreign key (xMasterId, xEntityId, xBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xAccount add constraint FK_06da3aa9cddcc23e5e6acc99ff6b7565 foreign key (xMasterId, xEntityId, xCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xAccount add constraint FK_bfd7716cc4da2d35466fc0cb532d5353 foreign key (xMasterId, xEntityId, xChannel)
		references xDeliveryChannel (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xAccount_Statement_Lnk add constraint FK_0ec4e88ff81a048985c494c66b751970 foreign key (xMasterId, xEntityId, xAccount)
		references xAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xAccount_Statement_Lnk add constraint FK_3b9aaedf0c184fb33d1380d4698424b9 foreign key (xMasterId, xEntityId, xStatement)
		references xStatement (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositAccount add constraint FK_22d7b9ed17233861948377f91af4f9db foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositAccount add constraint FK_2f6a4cccadd01ac610eacede64a51541 foreign key (xMasterId, xEntityId, xProduct)
		references xProductProfile (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTDAccount_Settings_Lnk add constraint FK_934f7a049890e3fcd24fd7cc9fc164a0 foreign key (xMasterId, xEntityId, xTermDepositAccount)
		references xTermDepositAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTDAccount_Settings_Lnk add constraint FK_9d974769615d0942b5e41e9291e6acd8 foreign key (xMasterId, xEntityId, xTermDepositSetting)
		references xTermDepositSetting (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTDAccount_Interest_Lnk add constraint FK_572cca2af1afff5f7abfc7e6f2dc3f96 foreign key (xMasterId, xEntityId, xTermDepositAccount)
		references xTermDepositAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTDAccount_Interest_Lnk add constraint FK_ea6ea749d04e494f0228354f110f3062 foreign key (xMasterId, xEntityId, xTermDepositInterest)
		references xTermDepositInterest (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTDAccount_BlockedAmounts_Lnk add constraint FK_11a0b226dec6072f692835b8f3c1cb46 foreign key (xMasterId, xEntityId, xTermDepositAccount)
		references xTermDepositAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTDAccount_BlockedAmounts_Lnk add constraint FK_346fb83e1ff9218cbd623cffda18128e foreign key (xMasterId, xEntityId, xBlockedAmount)
		references xBlockedAmount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTDAccount_Status_Lnk add constraint FK_6b07f00490e0603b221ac1c7a65ed6d0 foreign key (xMasterId, xEntityId, xTermDepositAccount)
		references xTermDepositAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTDAccount_Status_Lnk add constraint FK_24e025f2e8bfa7ba953a7a1d1f67704d foreign key (xMasterId, xEntityId, xTermDepositStatus)
		references xTermDepositStatus (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccount add constraint FK_ca2f2dc082a6ccd8c352af7c451722d9 foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccount add constraint FK_a76f86b183574bf49bfc7917f761fc6e foreign key (xMasterId, xEntityId, xProduct)
		references xProductProfile (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xClientAcc_BlockedAmount_Lnk add constraint FK_fa86d9427758d0afa1c3624b9507e537 foreign key (xMasterId, xEntityId, xClientAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAcc_BlockedAmount_Lnk add constraint FK_f6f8cc42fc416bfcceffe4b5e14aa79a foreign key (xMasterId, xEntityId, xBlockedAmount)
		references xBlockedAmount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAcc_SC_Lnk add constraint FK_e7fc04065afc259466d091de4cbe84bc foreign key (xMasterId, xEntityId, xClientAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAcc_SC_Lnk add constraint FK_74281b5b463d8339f6491a017a8e26c9 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xStatementGenerationLog add constraint FK_c0d5d625415de8a73ca5fea60cbca432 foreign key (xMasterId, xEntityId, xAccount)
		references xAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xStatementGenerationLog add constraint FK_0f456e377bbc88820a32786ab5c8f88d foreign key (xMasterId, xEntityId, xBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xStatementGenerationLog add constraint FK_de04f46ea4c87425f9905bd0ae1fd99c foreign key (xMasterId, xEntityId, xStatement)
		references xStatement (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xExternalTransfer add constraint FK_117082f3f58928f9adfb6c6b1b4c10c2 foreign key (xMasterId, xEntityId, xGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xExternalTransfer add constraint FK_63984eff6c650a000c6fc0122f4386a5 foreign key (xMasterId, xEntityId, xLedger)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xExternalTransfer_SC_Lnk add constraint FK_177c85ee8b1102a000119593a20edec8 foreign key (xMasterId, xEntityId, xExternalTransfer)
		references xExternalTransfer (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xExternalTransfer_SC_Lnk add constraint FK_9f112971333c4a8f925aebc6e49aa415 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPaymentTransaction add constraint FK_acf4e1787f80fb660acb464cc057208a foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xPaymentTransaction add constraint FK_38484f2c3a73a7fe7003bdaf4162ba03 foreign key (xMasterId, xEntityId, xCreditBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentTransaction add constraint FK_8a68605721a9a877e7b1fa60b47135af foreign key (xMasterId, xEntityId, xCreditAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xPaymentTransaction add constraint FK_d3e35aebceffa3a71b03742f6579398d foreign key (xMasterId, xEntityId, xDebitBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentTransaction add constraint FK_f94421681ca74e6438bd1a007fd8ed6f foreign key (xMasterId, xEntityId, xDebitAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xPaymentTransaction add constraint FK_7e0ac746dd9d43588c0675b76a1e3057 foreign key (xMasterId, xEntityId, xAccountCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xPaymentTransaction add constraint FK_e4221b88c3c5b895999b237b4ce7ffe3 foreign key (xMasterId, xTransactionCurrency)
		references xCurrency (xMasterId, xCode) on delete restrict on update restrict;

alter table xPaymentTransaction add constraint FK_54aef0d0e3aca558d6a96fa578c79f16 foreign key (xMasterId, xEntityId, xChargeAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xPaymentTransaction add constraint FK_4e4c6897746eafc6e4600906257dfd34 foreign key (xMasterId, xEntityId, xChannel)
		references xDeliveryChannel (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xPaymentTransaction add constraint FK_b3e90b675a9d0fdf79a946d00a7d9a60 foreign key (xMasterId, xEntityId, xPaymentSetting)
		references xPaymentSetting (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentTransaction add constraint FK_6f311c64e012b56ddc166c69e2eb8dd0 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPaymentTransaction_SC_Lnk add constraint FK_605aeba92d47557d845413a229d9d8ad foreign key (xMasterId, xEntityId, xPaymentTransaction)
		references xPaymentTransaction (xMasterId, xEntityId, xPaymentReferenceNumber) on delete restrict on update restrict;

alter table xPaymentTransaction_SC_Lnk add constraint FK_55c8492fdfc96624bea8abb160208eb5 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPaymentTransactionCharge add constraint FK_bdb1668fee9d913a5cc79b8820983d9a foreign key (xMasterId, xEntityId, xPaymentReferenceNumber)
		references xPaymentTransaction (xMasterId, xEntityId, xPaymentReferenceNumber) on delete restrict on update restrict;

alter table xPaymentTransactionCharge add constraint FK_be8d4b74b5a790f5d02c7d72aedbf30f foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xPaymentTransactionCharge add constraint FK_6565e18afb79c81981344ab79585ac74 foreign key (xMasterId, xEntityId, xChargeScheme)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xPaymentTransactionCharge add constraint FK_d42748cd4a8884d5fbe80c3912ed238b foreign key (xMasterId, xEntityId, xChargeCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xPaymentTransactionCharge add constraint FK_67ccc9565816a098888478b06821d702 foreign key (xMasterId, xEntityId, xChargeAccountCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xPaymentTrxnClientTransaction add constraint FK_caaaf98404229adf2c5d3836c3987203 foreign key (xMasterId, xEntityId, xPaymentReferenceNumber)
		references xPaymentTransaction (xMasterId, xEntityId, xPaymentReferenceNumber) on delete restrict on update restrict;

alter table xPaymentTrxnClientTransaction add constraint FK_be0be620ce9d79cf8c231153cd1eb897 foreign key (xAccountingRefNumber, xMasterId, xEntityId)
		references xClientTransactionNew (xAutoId, xMasterId, xEntityId) on delete restrict on update restrict;

alter table xPaymentTrxnGLTransaction add constraint FK_a8dddcf26ebab45535d92139bdef68a0 foreign key (xMasterId, xEntityId, xPaymentReferenceNumber)
		references xPaymentTransaction (xMasterId, xEntityId, xPaymentReferenceNumber) on delete restrict on update restrict;

alter table xPaymentTrxnGLTransaction add constraint FK_509672f533ff22644aeaaa4e59f51f78 foreign key (xAccountingRefNumber, xMasterId, xEntityId)
		references xGLTransaction (xAutoId, xMasterId, xEntityId) on delete restrict on update restrict;

alter table xPaymentTrxnChargeClientTrxn add constraint FK_23350c6c5e01eb426bd252282d0367cd foreign key (xMasterId, xEntityId, xPaymentTrxnChargeId)
		references xPaymentTransactionCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xPaymentTrxnChargeClientTrxn add constraint FK_9d8551e1cdd2fed77026c64211b9ccf3 foreign key (xAccountingRefNumber, xMasterId, xEntityId)
		references xClientTransactionNew (xAutoId, xMasterId, xEntityId) on delete restrict on update restrict;

alter table xPaymentTrxnChargeGLTrxn add constraint FK_19c441a09c1f86d032b7c5132e42cd7f foreign key (xMasterId, xEntityId, xPaymentTrxnChargeId)
		references xPaymentTransactionCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xPaymentTrxnChargeGLTrxn add constraint FK_62b649f6e59b16a6aa011558239aaf99 foreign key (xAccountingRefNumber, xMasterId, xEntityId)
		references xGLTransaction (xAutoId, xMasterId, xEntityId) on delete restrict on update restrict;

alter table xTermDepositPersonLink add constraint FK_34ecb5616894a15cb021f1a311188cad foreign key (xMasterId, xEntityId, xTermDepositAccount)
		references xTermDepositAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositPersonLink add constraint FK_f2ebbfd9b4d68cdc0346d8575d0f7aa0 foreign key (xMasterId, xPersonRole)
		references xPersonRole (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositPersonLink add constraint FK_e7b60a0f7bd790cc54a9384a2b6bc207 foreign key (xMasterId, xPerson)
		references xPerson (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountPersonLink add constraint FK_776e876a596314c97b2ec99a7237ff71 foreign key (xMasterId, xEntityId, xClientAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountPersonLink add constraint FK_a1badbda04a37db90d5ffe5dd7cc546e foreign key (xMasterId, xPerson)
		references xPerson (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountPersonLink add constraint FK_a223d973bdbdae8b214c019dfdb6989d foreign key (xMasterId, xPersonRole)
		references xPersonRole (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountSignatoryy add constraint FK_24bae4d08ce4c8a865db565848db2072 foreign key (xMasterId, xEntityId, xAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountSignatoryy add constraint FK_20db1d8763d1dee866e625464669f730 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountSignatoryy add constraint FK_f0ce68af9d25b1fd2b1eaf64fa8e9704 foreign key (xMasterId, xUpdatedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCASignatoryy_SC_Lnk add constraint FK_7b9d53f29169c320feab0a6e43ffe8f1 foreign key (xMasterId, xEntityId, xClientAccountSignatoryy)
		references xClientAccountSignatoryy (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCASignatoryy_SC_Lnk add constraint FK_8869682eb94e85091bdbeb662ab871ca foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositAccountSignatory add constraint FK_4ae38e8170b30e842a94e5b60eb7f335 foreign key (xMasterId, xEntityId, xAccount)
		references xTermDepositAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositAccountSignatory add constraint FK_3439ab6bfa9aca37973c41f6a0956225 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositAccountSignatory add constraint FK_f388fea6942b7d58d288ba44aed9767d foreign key (xMasterId, xUpdatedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTDASignatory_SC_Lnk add constraint FK_53ca3c775e94df35c29fc60ac97673db foreign key (xMasterId, xEntityId, xTermDepositAccountSignatory)
		references xTermDepositAccountSignatory (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTDASignatory_SC_Lnk add constraint FK_346d6c252b8c2c98e87650248fa20a02 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountSigPersonLink add constraint FK_dee191db019b8721fdc33d3751842613 foreign key (xMasterId, xEntityId, xClientAccountSignatoryy)
		references xClientAccountSignatoryy (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountSigPersonLink add constraint FK_e5050c6e800d874d18da697f8946f8a7 foreign key (xMasterId, xEntityId, xPerson)
		references xClientContactLink (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAccountSigPersonLink add constraint FK_c9f13849d53bda6c60493a025dfc62bb foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCASignatoryPersonLnk_SC_Lnk add constraint FK_3e82e405313d174c1e58a69781e350f0 foreign key (xMasterId, xEntityId, xClientAccountSigPersonLink)
		references xClientAccountSigPersonLink (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCASignatoryPersonLnk_SC_Lnk add constraint FK_8e6157bfb97f798d062ed1f4d6d7738f foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositSigPersonLink add constraint FK_ad4852d97d79ba3eb8c0d43fb8616a2c foreign key (xMasterId, xEntityId, xTermDepositAccountSignatory)
		references xTermDepositAccountSignatory (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositSigPersonLink add constraint FK_e2a9856420901d6042cf1f0d082b9255 foreign key (xMasterId, xEntityId, xPerson)
		references xClientContactLink (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTermDepositSigPersonLink add constraint FK_17aaee8179a03259272d35b60e5db086 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTDSignatoryPersonLnk_SC_Lnk add constraint FK_d231928a0f1e200605db6307d101dc9b foreign key (xMasterId, xEntityId, xTermDepositSigPersonLink)
		references xTermDepositSigPersonLink (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTDSignatoryPersonLnk_SC_Lnk add constraint FK_19d2baace2c4cbad09bf939834fa5dbf foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_dee9325644c0908cdb0b247682ea0334 foreign key (xMasterId, xEntityId, xCurrencyRateType)
		references xCurrencyRateType (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_6324159eb5a9209052e906cb7d53243e foreign key (xMasterId, xEntityId, xTransitLedger)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_1efb52b379759ba40a09765efd1afce6 foreign key (xMasterId, xEntityId, xInvestigationLedger)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_4531f9ea087a05c93b098e896ec9f5bd foreign key (xMasterId, xEntityId, xRepairLedger)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_82cf5f0f474f8652d4eb2c5dcd106520 foreign key (xMasterId, xEntityId, xClearingSettlementLedger)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_24a0153088b0a27e6ace2d7e682ac0eb foreign key (xMasterId, xEntityId, xDebitProcessingClientDb)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_fdb5959eb15613adf7cd7a4ce01b3db4 foreign key (xMasterId, xEntityId, xDebitProcessingGLDb)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_806acd011df08ad837870eb6c7c03db6 foreign key (xMasterId, xEntityId, xSystemDebitGLDb)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_4d07018f0078c898622690f81aff2c2c foreign key (xMasterId, xEntityId, xSystemCreditGLCr)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_c623eb907f5be36339752700e34963aa foreign key (xMasterId, xEntityId, xClientProcessingClientCr)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_78d34300edf525e7524f5222b44bcbeb foreign key (xMasterId, xEntityId, xClientProcessingGLCr)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_c7d92a354a1e890d9018b9cf9175fd34 foreign key (xMasterId, xEntityId, xBENChargeTypeGLDb)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_ac5bb0cf5d7c13fa46b3c2181aacbc0f foreign key (xMasterId, xEntityId, xSettlementProcessingClientCr)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_ed4e6f852b96f1e7d7af5120deb401cf foreign key (xMasterId, xEntityId, xAMLRejectionClientCr)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_409cc41ea8ee5198281a3b8b896fab2d foreign key (xMasterId, xEntityId, xAMLRejectionGLCr)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_751ab8710ce204b9cf83a9f2b4d24053 foreign key (xMasterId, xEntityId, xReversalClientDb)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_c3b8b441a73720a7a5c700862698c212 foreign key (xMasterId, xEntityId, xReversalGLDb)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_580a63dbc481866888dc75321a351b38 foreign key (xMasterId, xEntityId, xReversalClientCr)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_77e645822e4767cf4841997af9d577ca foreign key (xMasterId, xEntityId, xReversalGLCr)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_e827ef691d1dc4b56a655122f47c2a79 foreign key (xMasterId, xEntityId, xCancellationClientDb)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_436d01a72102fe959be1ae65e1621f7e foreign key (xMasterId, xEntityId, xCancellationGLDb)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_f5b4ea350529bf0e8a12182c400028e2 foreign key (xMasterId, xEntityId, xCancellationClientCr)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_b727e215aa9a2b0dea748c5408c20ceb foreign key (xMasterId, xEntityId, xCancellationGLCr)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_47261c0701f176534cd40ae32fef16ae foreign key (xMasterId, xEntityId, xTransactionCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xPaymentSetting add constraint FK_dca7009efbd2597eb37c392da96cd10f foreign key (xMasterId, xEntityId, xAdviceCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xPaymentSetting_Branch_Lnk add constraint FK_8b57285e2ff0bfd4db45401910b3d142 foreign key (xMasterId, xEntityId, xPaymentSetting)
		references xPaymentSetting (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xPaymentSetting_Branch_Lnk add constraint FK_5ff0861a5f3833775424630ad7ab7c0a foreign key (xMasterId, xEntityId, xBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xRetailLoanAccount add constraint FK_8b8bc599b971e950667d7046f32c98b0 foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRetailLoanAccount add constraint FK_e2cf44db307882ff938b05d7c5ced29e foreign key (xMasterId, xEntityId, xProduct)
		references xLoanProduct (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xRetailLoanAccount add constraint FK_f276ec72328d4021b321d780069c9aa8 foreign key (xMasterId, xEntityId, xOriginBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xRetailLoanAccount add constraint FK_c52a3951682f1fedfa982f0606ed8187 foreign key (xMasterId, xEntityId, xDisbursementCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xRLAccount_Setting_Lnk add constraint FK_661e593dfc21c80a3d531ff47c9d10d1 foreign key (xMasterId, xEntityId, xRetailLoanAccount)
		references xRetailLoanAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccount_Setting_Lnk add constraint FK_cffd35b551098f516dd3017ee6d9283b foreign key (xMasterId, xEntityId, xRetailLoanAccSetting)
		references xRetailLoanAccSetting (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccount_PaymentSettings_Lnk add constraint FK_4328f4f2eb5b1ecf2cbcb4644c8cbfeb foreign key (xMasterId, xEntityId, xRetailLoanAccount)
		references xRetailLoanAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccount_PaymentSettings_Lnk add constraint FK_fff3e1b16b9a63364735a85c51b50192 foreign key (xMasterId, xEntityId, xRLAccountPaymentSetting)
		references xRLAccountPaymentSetting (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccount_Interest_Lnk add constraint FK_3ce8cfc130f9d1e157750087ccaa01e2 foreign key (xMasterId, xEntityId, xRetailLoanAccount)
		references xRetailLoanAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccount_Interest_Lnk add constraint FK_363886fed2bef74d45af8d08457fcaa2 foreign key (xMasterId, xEntityId, xRetailLoanAccountInterest)
		references xRetailLoanAccountInterest (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccount_ASC_Lnk add constraint FK_01794304e8c93a44abeb465626be36a8 foreign key (xMasterId, xEntityId, xRetailLoanAccount)
		references xRetailLoanAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccount_ASC_Lnk add constraint FK_dd34f3ab926982f557f49b856808c3fd foreign key (xMasterId, xEntityId, xRetailLoanAccountStatus)
		references xRetailLoanAccountStatus (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRetailLoanAccount_Charges_Lnk add constraint FK_0c669852ac39cdeec06b2f9f1cb24093 foreign key (xMasterId, xEntityId, xRetailLoanAccount)
		references xRetailLoanAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRetailLoanAccount_Charges_Lnk add constraint FK_b6982ef6e3a647caa11ff786c79e2401 foreign key (xMasterId, xEntityId, xRLAccountCharges)
		references xRLAccountCharges (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRetailLoanAccSetting add constraint FK_627b4719a68c85ef6885118cae2350ea foreign key (xMasterId, xEntityId, xDisbursementCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xRetailLoanAccSetting add constraint FK_2c1ee5bfde0a2fa87682e52767ad6de5 foreign key (xMasterId, xEntityId, xToLedger)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xRetailLoanAccSetting add constraint FK_8126387320a948fc2fe5d404be2968bf foreign key (xMasterId, xEntityId, xToClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRetailLoanAccSetting add constraint FK_056c5f3e6e8893027b20192e5a920a92 foreign key (xMasterId, xToBank)
		references xSettlementDirectory (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xRetailLoanAccSetting add constraint FK_27f773955fcd188e387e3c7e65bc0f08 foreign key (xMasterId, xEntityId, xFromLedger)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xRetailLoanAccSetting add constraint FK_6ebda7ed75b536c840e8c12269c2ab0d foreign key (xMasterId, xEntityId, xFromClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRetailLoanAccSetting add constraint FK_446b0ad6a0b2d9c3a9bb85b640a907b7 foreign key (xMasterId, xFromBank)
		references xSettlementDirectory (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountPaymentSetting add constraint FK_43e9607847862032fd07539441f63f9d foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xRLAPayementStatus_SC_Lnk add constraint FK_2857765c4334d8162f7f7bd8fabbf52a foreign key (xMasterId, xEntityId, xRLAccountPaymentSetting)
		references xRLAccountPaymentSetting (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAPayementStatus_SC_Lnk add constraint FK_15ff1f3717879024ff839ce1440b6345 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xRetailLoanAccountInterest add constraint FK_772e17b8ed97688ae962aca5f1ad43ed foreign key (xMasterId, xEntityId, xLoanInterestScheme)
		references xInterestScheme (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRetailLoanAccountInterest add constraint FK_483bd5674d579640be7446a449b54c42 foreign key (xMasterId, xEntityId, xLoanInterestBase)
		references xInterestBase (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRetailLoanAccountInterest add constraint FK_6363ce9ea64d118b5d862ce53f1e81c2 foreign key (xMasterId, xEntityId, xPrincipalOverdueScheme)
		references xInterestScheme (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRetailLoanAccountInterest add constraint FK_a8230a2f0ce900fec7c2c4d17a455829 foreign key (xMasterId, xEntityId, xPrincipalOverdueBase)
		references xInterestBase (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRetailLoanAccountInterest add constraint FK_b369b93af4d1ce5849776e3d6952a085 foreign key (xMasterId, xEntityId, xInterestOverdueScheme)
		references xInterestScheme (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRetailLoanAccountInterest add constraint FK_87e6789bfe07d815918f8f1b74ad3348 foreign key (xMasterId, xEntityId, xInterestOverdueBase)
		references xInterestBase (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRetailLoanAccountInterest add constraint FK_ddb9c0ea77761dafc74f3d74dfae4edd foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountInterest_SC_Lnk add constraint FK_e7540aad72d38ef61151c6d3cd6e4c44 foreign key (xMasterId, xEntityId, xRetailLoanAccountInterest)
		references xRetailLoanAccountInterest (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountInterest_SC_Lnk add constraint FK_d2ddd8fd9e6b2ccbf025e844e88abe1b foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xRetailLoanAccountStatus add constraint FK_b8a2980923a6c40458a904be74728d56 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountStatus_SC_Lnk add constraint FK_9d8aa3d0b777564f1206fdf9445ef00a foreign key (xMasterId, xEntityId, xRetailLoanAccountStatus)
		references xRetailLoanAccountStatus (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountStatus_SC_Lnk add constraint FK_8aa1ccee575adc83377684b61230e8b2 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_3d511449a17ba0500261a0d01642eb66 foreign key (xMasterId, xEntityId, xBuyGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_8fbbe5b6d64f2089b13be8430e6425cb foreign key (xMasterId, xEntityId, xSellGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_646e46f844561dbc4dc6adfa72939ae3 foreign key (xMasterId, xEntityId, xUnrealisedProfitGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_6b8c858734b3f4069b0312f4ca4ef6fd foreign key (xMasterId, xEntityId, xUnrealisedLossGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_ce436b29b164db35546adef5fc9383c8 foreign key (xMasterId, xEntityId, xFXConsolidationProfitGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_5212aa6796fb1cce4d8809ef14fe98fb foreign key (xMasterId, xEntityId, xFXConsolidationLossGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_3e0dac5965995f84d3d69e90f3043d63 foreign key (xMasterId, xEntityId, xRealisedProfitGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_e60db23e47e62388831a206aa499a0b4 foreign key (xMasterId, xEntityId, xRealisedLossGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_c275b7b315f8a77df497cfbefd499109 foreign key (xMasterId, xEntityId, xFXSettlementBridgeGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_9871b6acf03e24f455f7d4823122f525 foreign key (xMasterId, xEntityId, xBuyDBGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_f18978070138fe6a0ebdcfa122c20254 foreign key (xMasterId, xEntityId, xBuyCRGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_3a29ac7737d19f91417e96189a70b1a2 foreign key (xMasterId, xEntityId, xSellDBGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_e53e871292d3cbe2d45cfc87e0cf633f foreign key (xMasterId, xEntityId, xSellCRGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_1bcaaf6594f2bd0886230cef1f0643bb foreign key (xMasterId, xEntityId, xFXConsolidationProfitCRGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_3930fe7ea3ae52b66a990dbee264266e foreign key (xMasterId, xEntityId, xFXConsolidationLossDBGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_df416c22389717e47c23a01f8d560a0f foreign key (xMasterId, xEntityId, xUnrealizedProfitDBGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_2fd94ac76781e58034d5b3ace8884618 foreign key (xMasterId, xEntityId, xUnrealizedLossCRGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_0958321a05846d61dcc824df8d617d7e foreign key (xMasterId, xEntityId, xFXSettlementCRGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_1851142caac2d9307c0a1e9bdecc34a1 foreign key (xMasterId, xEntityId, xFXSettlementDBGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_681dc6d42a870006170f3a8e9b11524f foreign key (xMasterId, xEntityId, xFXSettlementbridgeCRGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_ef9b72468fd776506f4edb34d70759e7 foreign key (xMasterId, xEntityId, xFXSettlementbridgeDBGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_0ddddaecb92317feff0ca0b64c5a552a foreign key (xMasterId, xEntityId, xFXSettlementCRClient)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_0cf6a5d7eabc90b8b3ca1be510df98e7 foreign key (xMasterId, xEntityId, xFXSettlementDBClient)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_c6878bdaf645b9da9cb0eeccd098fadc foreign key (xMasterId, xEntityId, xRealisedProfitCRGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_aa28c12f915d331476ac73441de02959 foreign key (xMasterId, xEntityId, xRealisedLossDBGL)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_215c693d2906ebdb888ecb075719b5b5 foreign key (xMasterId, xEntityId, xBookingFee)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_2539f150ec48718dc90f98f37b31c014 foreign key (xMasterId, xEntityId, xNonSettlementFee)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXProduct add constraint FK_0e6a60007bda97186151301c8b489218 foreign key (xMasterId, xEntityId, xBrokerCommission)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXProduct_Currency_Lnk add constraint FK_fd3bfdb26c9892ca699a7dcabfe3a0cc foreign key (xMasterId, xEntityId, xFXProduct)
		references xFXProduct (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct_Currency_Lnk add constraint FK_32e1218921290a5fc902c9d264a4ee59 foreign key (xMasterId, xEntityId, xGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xFXProduct_Setting_Lnk add constraint FK_61472cd86a17554754a1a8a6d4e2e35e foreign key (xMasterId, xEntityId, xFXProduct)
		references xFXProduct (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProduct_Setting_Lnk add constraint FK_845875e951165c1144fddd430ec9c4dd foreign key (xMasterId, xEntityId, xFXProductSetting)
		references xFXProductSetting (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXProductSetting add constraint FK_b79667d60842e524fe6fba6d44fff2b4 foreign key (xMasterId, xEntityId, xFXProduct)
		references xFXProduct (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXProductSetting add constraint FK_bafa3c6260ed0a54fbbb42f30ef63af3 foreign key (xMasterId, xEntityId, xRealisedProfitLossRateType)
		references xCurrencyRateType (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXProductSetting add constraint FK_5f09e819e3230d7dc9e10cc6fa1ed445 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXProductSetting add constraint FK_0d22ab41231f5dc1e1c1405611fbea16 foreign key (xMasterId, xUpdatedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXProductSetting_SC_Lnk add constraint FK_e8f61d6fbcc34711173fb02f7f7cd2aa foreign key (xMasterId, xEntityId, xFXProductSetting)
		references xFXProductSetting (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXProductSetting_SC_Lnk add constraint FK_4510ab98819b88dbbe4fcea4804e07e1 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountPaymentSchedule add constraint FK_b3e5b234cf6c5da96e5573c191d17aa9 foreign key (xMasterId, xEntityId, xAccount)
		references xRetailLoanAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountCharges add constraint FK_e1f76ed69a9565a6844425238e66a107 foreign key (xMasterId, xEntityId, xProcessingFee)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountCharges add constraint FK_48a240a83d733346d534f4871e0e67a9 foreign key (xMasterId, xEntityId, xServiceCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountCharges add constraint FK_e0a514f02e5cf18aaf2cd9005c2adc1f foreign key (xMasterId, xEntityId, xDocumentationCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountCharges add constraint FK_dc36e233173788d60aa8b2bfa3fbf2cc foreign key (xMasterId, xEntityId, xLegalCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountCharges add constraint FK_860fe7fdd5b797dd7813ed3f6ed70529 foreign key (xMasterId, xEntityId, xPrePaymentCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountCharges add constraint FK_76a65520c499c90940ff81c495a24450 foreign key (xMasterId, xEntityId, xInstallmentFee)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountCharges add constraint FK_4d45c61820dd5a0ec4c3eaff9907eaf8 foreign key (xMasterId, xEntityId, xLatePaymentFee)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountCharges add constraint FK_4f8bc9b7fa642ba5200062ddb35188b7 foreign key (xMasterId, xEntityId, xChargeAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountCharges add constraint FK_28de23966674aa8f629c63115e128d9b foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountCharges_Status_Lnk add constraint FK_1d369ba6c5493bdb2051b9cae0783526 foreign key (xMasterId, xEntityId, xRLAccountCharges)
		references xRLAccountCharges (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountCharges_Status_Lnk add constraint FK_7587cbee32d382ceb6144866105db7df foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xRetailLoanAccountRepayment add constraint FK_6b9a521fe44935c26370924a35950e21 foreign key (xMasterId, xEntityId, xAccount)
		references xRetailLoanAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRetailLoanAccountRepayment add constraint FK_1e860249c44fe320b0b083acf388a4bc foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountRepayment_SC_Lnk add constraint FK_ae214a47afc9b3fa291523d079a9fc0a foreign key (xMasterId, xEntityId, xRetailLoanAccountRepayment)
		references xRetailLoanAccountRepayment (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountRepayment_SC_Lnk add constraint FK_c3f3cd210d1ad7a26fc3539a71e2be33 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xRetailLoanAccountDisbursement add constraint FK_59a8202fd6420fa869c8131d54f1c358 foreign key (xMasterId, xEntityId, xAccount)
		references xRetailLoanAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRetailLoanAccountDisbursement add constraint FK_5fd1389ccc1088b5d03945f76f8a8068 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountDisbursement_SC_Lnk add constraint FK_45b293d2eccc8c55a6ab456ed066e115 foreign key (xMasterId, xEntityId, xRetailLoanAccountDisbursement)
		references xRetailLoanAccountDisbursement (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRLAccountDisbursement_SC_Lnk add constraint FK_2897a86276145850da21464e89fda0cc foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXContract add constraint FK_32859fd3c51031c1b2e900ba1052dd99 foreign key (xMasterId, xEntityId, xOwnerBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXContract add constraint FK_7904d24c76ec54e43713b19da625a122 foreign key (xMasterId, xEntityId, xProduct)
		references xFXProduct (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXContract add constraint FK_b706a074cf5fd97a6ba8d011ab049f20 foreign key (xMasterId, xEntityId, xCounterParty)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContract add constraint FK_dc182367636f16f9630a0635494cdaf3 foreign key (xMasterId, xEntityId, xBoughtCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xFXContract add constraint FK_e35cd5a36945b52098ec5477492a2da3 foreign key (xMasterId, xEntityId, xSoldCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xFXContract_Charge_Lnk add constraint FK_6f8e6a01545a2bf1dab2d40653f40a37 foreign key (xMasterId, xEntityId, xFXContract)
		references xFXContract (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContract_Charge_Lnk add constraint FK_5f641f4e2a39044612e4cea23dbb346a foreign key (xMasterId, xEntityId, xFXContractCharge)
		references xFXContractCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContract_SI_Lnk add constraint FK_feb3fd9c2011319039fcc8e8ee635669 foreign key (xMasterId, xEntityId, xFXContract)
		references xFXContract (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContract_SI_Lnk add constraint FK_4a7ffa4b21f682cfbfb0b8e1dfb09c4f foreign key (xMasterId, xEntityId, xFXContractSettlementInstn)
		references xFXContractSettlementInstn (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContract_Status_Lnk add constraint FK_4a0081214cdab15ffb1a8cf4021cb1a0 foreign key (xMasterId, xEntityId, xFXContract)
		references xFXContract (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContract_Status_Lnk add constraint FK_b7192c749d4a3c620607aec2a432e16d foreign key (xMasterId, xEntityId, xFXContractStatus)
		references xFXContractStatus (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContracts_AO_Lnk add constraint FK_62cfccf523ceccdfaf1c22834ddf17dd foreign key (xMasterId, xEntityId, xFXContract)
		references xFXContract (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContracts_AO_Lnk add constraint FK_801913dbe56a6f484f005b0bf3b3b9ee foreign key (xMasterId, xEntityId, xFXContractAlertsOverrides)
		references xFXContractAlertsOverrides (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContractCharge add constraint FK_37255fc94d7ca00b4abcbd88f2cfdb74 foreign key (xMasterId, xEntityId, xFXContract)
		references xFXContract (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContractCharge add constraint FK_c6e4f4f9267caf197b06c3f03267c504 foreign key (xMasterId, xEntityId, xChargeAccountCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xFXContractCharge add constraint FK_4644f4d035b5420fe387fc227067103e foreign key (xMasterId, xEntityId, xChargeClientAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContractCharge add constraint FK_2ba267d2c5aa90f74545bd1723eb0582 foreign key (xMasterId, xEntityId, xChargeGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXContractCharge add constraint FK_1399b7404c350db7c324107068a6222d foreign key (xMasterId, xEntityId, xBookingFee)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContractCharge add constraint FK_753f42e7ccda7c0d3d0150828a2f3504 foreign key (xMasterId, xEntityId, xBookingFeeChargeCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xFXContractCharge add constraint FK_459e3b1141c9421d552feb439b6acce5 foreign key (xMasterId, xEntityId, xBrokerCommission)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContractCharge add constraint FK_b245263c6821a7442bc3477143f3b4c6 foreign key (xMasterId, xEntityId, xBrokerCommissionChargeCCY)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xFXContractCharge add constraint FK_30a81d2d9da97b775e631e7044a14a45 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXContractCharge add constraint FK_f33252752006ee54219455db70994657 foreign key (xMasterId, xUpdatedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXCCStatus_SC_Lnk add constraint FK_8ebdc48e071a6abf032921683e0b0ebc foreign key (xMasterId, xEntityId, xFXContractCharge)
		references xFXContractCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXCCStatus_SC_Lnk add constraint FK_7228fe95d886726be271680a1819f549 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXContractSettlementInstn add constraint FK_7fe73476ed7b69fc89e7569437c3ec4d foreign key (xMasterId, xEntityId, xFXContract)
		references xFXContract (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContractSettlementInstn add constraint FK_56853b897664417812c98125f2f1902e foreign key (xMasterId, xEntityId, xBoughtCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xFXContractSettlementInstn add constraint FK_01822e20200c28654687718522d76e52 foreign key (xMasterId, xEntityId, xDebitClientAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContractSettlementInstn add constraint FK_5c06650c1b4c245071454f1065c6b1ac foreign key (xMasterId, xEntityId, xDebitGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXContractSettlementInstn add constraint FK_6b4e289fb01e577bfa6bad8324b2d6a9 foreign key (xMasterId, xEntityId, xSoldCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xFXContractSettlementInstn add constraint FK_d5fd916cb216b7eb31712f93004b2da1 foreign key (xMasterId, xEntityId, xCreditClientAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContractSettlementInstn add constraint FK_71eb1a4a8ad041d9168e1eaf748cde69 foreign key (xMasterId, xEntityId, xCreditGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXContractSettlementInstn add constraint FK_eaf8a1d2081c73d9b1226b59565f23d3 foreign key (xMasterId, xEntityId, xChargeClientAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContractSettlementInstn add constraint FK_284f22ac69920dbfbd8219ab0791cc42 foreign key (xMasterId, xEntityId, xChargeGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXContractSettlementInstn add constraint FK_8f7070c1da60aebc84de0812e44e4659 foreign key (xMasterId, xBeneficiaryBIC)
		references xSettlementDirectory (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXContractSettlementInstn add constraint FK_93f5805c07dc0b9a4e7f53e7d62d7762 foreign key (xMasterId, xAWIBIC)
		references xSettlementDirectory (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXContractSettlementInstn add constraint FK_c75a2adb8e505aec813e2b5d4c7d2142 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXContractSettlementInstn add constraint FK_3cd3447b7fcd6ed4e96cb9e220840bb1 foreign key (xMasterId, xUpdatedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXCSStatus_SC_Lnk add constraint FK_09d34bdc9cc174daccadaf29a0a32682 foreign key (xMasterId, xEntityId, xFXContractSettlementInstn)
		references xFXContractSettlementInstn (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXCSStatus_SC_Lnk add constraint FK_243f380432098abc39fbf883a861b335 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXContractStatus add constraint FK_d35ed2276205f0b9a703ed5d9629be92 foreign key (xMasterId, xEntityId, xFXContract)
		references xFXContract (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContractStatus add constraint FK_97ce7873c6cb0cce5e7fe592cd98ebf0 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXContractStatus add constraint FK_bf00591e189164b271684fcbbef2d683 foreign key (xMasterId, xUpdatedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXCStatus_SC_Lnk add constraint FK_8733c62a1302ba1d43469a18dd951397 foreign key (xMasterId, xEntityId, xFXContractStatus)
		references xFXContractStatus (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXCStatus_SC_Lnk add constraint FK_a98bcd17a4cf937a6290f514d60d6761 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXContractAlertsOverrides add constraint FK_7006962a8c40a5699f390c24a0d1be56 foreign key (xMasterId, xEntityId, xFXContract)
		references xFXContract (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContractAlertsOverrides add constraint FK_077e57de20aea86be317362acfb04a94 foreign key (xMasterId, xUser)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXContractClientTrxn add constraint FK_e167e0605f9296a79e7946d2a6d84bd7 foreign key (xMasterId, xEntityId, xFXContract)
		references xFXContract (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContractClientTrxn add constraint FK_95604d219e981b3bd044991f634a98ce foreign key (xAccountingRefNumber, xMasterId, xEntityId)
		references xClientTransactionNew (xAutoId, xMasterId, xEntityId) on delete restrict on update restrict;

alter table xFXContractGLTrxn add constraint FK_3a980802fb501c9bdd4ca272e5056463 foreign key (xMasterId, xEntityId, xFXContract)
		references xFXContract (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContractGLTrxn add constraint FK_9bfa3ff9ff5e49706dae330e9e779fa3 foreign key (xAccountingRefNumber, xMasterId, xEntityId)
		references xGLTransaction (xAutoId, xMasterId, xEntityId) on delete restrict on update restrict;

alter table xFXContractChargeClientTrxn add constraint FK_2d352902f28602f55b3a2aeeda1f415c foreign key (xMasterId, xEntityId, xFXContractCharge)
		references xFXContractCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContractChargeClientTrxn add constraint FK_6cba694e00cb4c31dceae06285967021 foreign key (xAccountingRefNumber, xMasterId, xEntityId)
		references xClientTransactionNew (xAutoId, xMasterId, xEntityId) on delete restrict on update restrict;

alter table xFXContractChargeGLTrxn add constraint FK_0b552da3abec8dcd2c51f7ee3bcd8272 foreign key (xMasterId, xEntityId, xFXContractCharge)
		references xFXContractCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXContractChargeGLTrxn add constraint FK_dff008b2ea92f457f7026102bc3d771d foreign key (xAccountingRefNumber, xMasterId, xEntityId)
		references xGLTransaction (xAutoId, xMasterId, xEntityId) on delete restrict on update restrict;

alter table xFXManualSettlement add constraint FK_89e6329dda8e9219dee124bd80516b5f foreign key (xMasterId, xEntityId, xFXContract)
		references xFXContract (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXManualSettlement add constraint FK_d906a87dbd3118262be0e0d777efb500 foreign key (xMasterId, xEntityId, xChargeCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xFXManualSettlement add constraint FK_eeae8ff6046ca5c911093c855c717a01 foreign key (xMasterId, xEntityId, xChargeClientAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXManualSettlement add constraint FK_24e175314a6468fef0f1449fe8a0c8a1 foreign key (xMasterId, xEntityId, xChargeGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xFXManualSettlement add constraint FK_098dfb4207ce9b704fa4fc3d873becdc foreign key (xMasterId, xEntityId, xAccountCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xFXManualSettlement add constraint FK_49ab437ca05f3debddc83e2e4efd7f8a foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXManualSettlement_SC_Lnk add constraint FK_2b9d88866ef615e052f9157a95469d65 foreign key (xMasterId, xEntityId, xFXManualSettlement)
		references xFXManualSettlement (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXManualSettlement_SC_Lnk add constraint FK_7154ee0eae4e15d5183155b937463546 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xSecurityTokenLog add constraint FK_791c7a54b96180d21e4b9a138b27b0aa foreign key (xMasterId, xSecurityToken)
		references xSecurityToken (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPhone add constraint FK_c0458fd64f49d796fdfcda0080cdced9 foreign key (xMasterId, xPhoneType)
		references xPhoneType (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCountry add constraint FK_75d39a4f492b89c81f4a54ef5fbb9e61 foreign key (xMasterId, xCurrency)
		references xCurrency (xMasterId, xCode) on delete restrict on update restrict;

alter table xCountry add constraint FK_09e9f3d35d0cdd54196cc6b7fad59c59 foreign key (xMasterId, xLanguage)
		references xLanguage (xMasterId, xCode) on delete restrict on update restrict;

alter table xCustomFieldModuleLink add constraint FK_1ec727f1639a98fc54d61493b9680561 foreign key (xMasterId, xCustomField)
		references xCustomField (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCustomFieldData add constraint FK_9637192ed891e3069e6fc28ca3138934 foreign key (xMasterId, xCustomFieldModuleLink)
		references xCustomFieldModuleLink (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDiary add constraint FK_6918712224b8c51d83a810b2b3420519 foreign key (xMasterId, xEnteredBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDiary add constraint FK_3d465ea856f384295e262dbcf2152c1d foreign key (xMasterId, xDiaryType)
		references xDiaryType (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xGeographicZone_Countries_Lnk add constraint FK_224e91e86c2d5b0934ff1c5c0b17650b foreign key (xMasterId, xGeographicZone)
		references xGeographicZone (xMasterId, xCode) on delete restrict on update restrict;

alter table xGeographicZone_Countries_Lnk add constraint FK_efa793951b03cfb7f1ebe8b537218700 foreign key (xMasterId, xCountry)
		references xCountry (xMasterId, xAlpha3Code) on delete restrict on update restrict;

alter table xBankClearingNumber add constraint FK_f2c2ecefb88daf295ba97cd2ea8dd179 foreign key (xMasterId, xSettlementDirectory)
		references xSettlementDirectory (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xEmail add constraint FK_24f2029e331a4166631c45dbbdbfd70c foreign key (xMasterId, xEmailType)
		references xEmailType (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xBinaryData add constraint FK_3299b2c38e131103ac0ef657f7763f33 foreign key (xMasterId, xCreatedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xUserSession add constraint FK_b80f2c4d9ffecc07aa6b356235b89802 foreign key (xMasterId, xUser)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xUserSession add constraint FK_455a5db859825395be83294846ea7b56 foreign key (xMasterId, xEntityId, xActiveBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xCurrencyRate add constraint FK_4e1936a4a5b2da7af1b9e44e8ab03321 foreign key (xMasterId, xFromCurrency)
		references xCurrency (xMasterId, xCode) on delete restrict on update restrict;

alter table xCurrencyRate add constraint FK_898e91e3327fc67aec2184a4d287d3c2 foreign key (xMasterId, xToCurrency)
		references xCurrency (xMasterId, xCode) on delete restrict on update restrict;

alter table xCurrencyRate add constraint FK_f3cb3fce1f1b3de390ae10c13412cbac foreign key (xMasterId, xEntityId, xCurrencyRateType)
		references xCurrencyRateType (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCurrencyRate add constraint FK_102d41ca69bc12e476fc9dbae48ee4c7 foreign key (xMasterId, xEntityId, xActiveBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xCurrencyRate add constraint FK_e431a66ade8f0562eb719b948858fa66 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCurrencyRate add constraint FK_7b54dbcba749bc9e2b903fd7957d21c8 foreign key (xMasterId, xApprovedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xSecurityToken add constraint FK_7399ca952a755402211cc27a3a3b8391 foreign key (xMasterId, xUser)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xUserPrivateKey add constraint FK_3dce9d728fa6ddb5003d8b73a97a83bf foreign key (xMasterId, xUser)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCountryZipCode add constraint FK_629f48dee13ac1fa7800405149302008 foreign key (xMasterId, xCountry)
		references xCountry (xMasterId, xAlpha3Code) on delete restrict on update restrict;

alter table xCountryZipCode add constraint FK_04fb46e0d66b565d11595c977387b6a5 foreign key (xMasterId, xCountryRegion)
		references xCountryRegion (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xRequestLog add constraint FK_52d3a64f7ec1bbaa6620189575061b75 foreign key (xMasterId, xUser)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xRequestLog add constraint FK_0eb0bba799107d3bb515fa099c11e67d foreign key (xMasterId, xEntityId, xUserAccountSession)
		references xUserSession (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xDocument add constraint FK_f1e0b7b8e5b4c874abb8b17adb8e34ff foreign key (xMasterId, xType)
		references xDocumentType (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDocument add constraint FK_5c58778160e4896ffbb8ee67375ca0cb foreign key (xMasterId, xCreatedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDocument_BinaryDatas_Lnk add constraint FK_1031e4b21ffc16a8e6a2a0a200627f0f foreign key (xMasterId, xDocument)
		references xDocument (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDocument_BinaryDatas_Lnk add constraint FK_89cbc48161ae4f4c46d7748dca097994 foreign key (xMasterId, xBinaryData)
		references xBinaryData (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xAddress add constraint FK_8962c4688b5285b0ef24e9bdc5e93f3c foreign key (xMasterId, xAddressType)
		references xAddressType (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xAddress add constraint FK_4e25eee697a8e707787e4f06f1c82630 foreign key (xMasterId, xCountry)
		references xCountry (xMasterId, xAlpha3Code) on delete restrict on update restrict;

alter table xOrganisationPersonLink add constraint FK_7fbbabcf09e7facc752b6187c462fc86 foreign key (xMasterId, xOrganisation)
		references xOrganisation (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xOrganisationPersonLink add constraint FK_4c94535e433fca0bf65155a832f01417 foreign key (xMasterId, xPerson)
		references xPerson (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xOrganisationPersonLink add constraint FK_ef88f1d143bf35ee5a03b75661d47c6a foreign key (xMasterId, xPersonRole)
		references xPersonRole (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCorebankEntity add constraint FK_632e54347e557719a71047919cfafd50 foreign key (xMasterId, xMaster)
		references xCorebankMaster (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCorebankEntity add constraint FK_69ba3d238fe61956f9ad26977a37899a foreign key (xMasterId, xEntityId, xBaseGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xCorebankEntity add constraint FK_33d51ae04f256cfcc57778d0cefb89e7 foreign key (xMasterId, xEntityId, xDefaultCurrencyRateType)
		references xCurrencyRateType (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCorebankEntity add constraint FK_9b522273a0b726745b3669aff4557b80 foreign key (xMasterId, xEntityId, xDefaultSpotRateType)
		references xCurrencyRateType (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCorebankEntity add constraint FK_15fef9c1227dc28c0db8380b57fa64ed foreign key (xMasterId, xEntityId, xServiceDeliveryChannel)
		references xDeliveryChannel (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCorebankEntity add constraint FK_ea00f3f8928aa3eee746769a92cc82ce foreign key (xMasterId, xCountry)
		references xCountry (xMasterId, xAlpha3Code) on delete restrict on update restrict;

alter table xCorebankEntity add constraint FK_5158cf54238affcad5252a0660973277 foreign key (xMasterId, xLanguage)
		references xLanguage (xMasterId, xCode) on delete restrict on update restrict;

alter table xCorebankEntity add constraint FK_725ed2e79da01b0ae3771158fa0fba41 foreign key (xMasterId, xDefaultAddress)
		references xAddress (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCorebankEntity add constraint FK_95a23e8145acb0ac607822999c8a5747 foreign key (xMasterId, xDefaultPhone)
		references xPhone (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCorebankEntity add constraint FK_d130ad5614bbd174e14d71f4004b4fdc foreign key (xMasterId, xEntityId, xExternalTransferGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xCorebankEntity_BAccount_Lnk add constraint FK_7d358b4ec637b8e0f43e557c6bedc80c foreign key (xMasterId, xEntityId, xCorebankEntity)
		references xCorebankEntity (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCorebankEntity_BAccount_Lnk add constraint FK_9fb17b1dd4fe3f346cd5407a97282098 foreign key (xMasterId, xEntityId, xBankAccount)
		references xBankAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCorebankEntity_Addresses_Lnk add constraint FK_507269224db7016ce195809a948eb87f foreign key (xMasterId, xEntityId, xCorebankEntity)
		references xCorebankEntity (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCorebankEntity_Addresses_Lnk add constraint FK_f6d92931b11c0ff91389c76f6d651e8a foreign key (xMasterId, xAddress)
		references xAddress (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCorebankEntity_Phones_Lnk add constraint FK_1e9c139e72b4c48fceebf63984739002 foreign key (xMasterId, xEntityId, xCorebankEntity)
		references xCorebankEntity (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCorebankEntity_Phones_Lnk add constraint FK_89ca06bf5f6c715ccce2cc3e947cc27a foreign key (xMasterId, xPhone)
		references xPhone (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPublicHoliday add constraint FK_df6ace74b376b222d9314195048521d3 foreign key (xMasterId, xCountry)
		references xCountry (xMasterId, xAlpha3Code) on delete restrict on update restrict;

alter table xCountryRegion add constraint FK_2fe042573c56abc5a2a1719c0d8726aa foreign key (xMasterId, xCountry)
		references xCountry (xMasterId, xAlpha3Code) on delete restrict on update restrict;

alter table xUserSettings add constraint FK_913d5bd1d0855119bcb1b8f95a41b46a foreign key (xMasterId, xUser)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xStatusChange add constraint FK_ee4143f913e09843bd70d0657e09f24c foreign key (xMasterId, xSetBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xOrganisation add constraint FK_d7504886b6a85fffc2963b6d06c3ec41 foreign key (xMasterId, xJurisdiction)
		references xCountry (xMasterId, xAlpha3Code) on delete restrict on update restrict;

alter table xOrganisation add constraint FK_9673c6977f2b2ea143774ce7e6be3d8a foreign key (xMasterId, xCorporateRegistrationCountry)
		references xCountry (xMasterId, xAlpha3Code) on delete restrict on update restrict;

alter table xOrganisation add constraint FK_c7994d14689ea6d83aaafd2978dc55cc foreign key (xMasterId, xDomicile)
		references xCountry (xMasterId, xAlpha3Code) on delete restrict on update restrict;

alter table xOrganisation_Categories_Lnk add constraint FK_8b17d5bec7d0f30c28aa5f71c2610258 foreign key (xMasterId, xOrganisation)
		references xOrganisation (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xOrganisation_Categories_Lnk add constraint FK_b1903e64d6371eb55c03f76d757adb0e foreign key (xMasterId, xEntityId, xCategory)
		references xCategory (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xOrganisation_Documents_Lnk add constraint FK_d8e341120c22ad3e290d13a1cca6d0f3 foreign key (xMasterId, xOrganisation)
		references xOrganisation (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xOrganisation_Documents_Lnk add constraint FK_10a8e29f820eb21dba0534c865b5b4ca foreign key (xMasterId, xDocument)
		references xDocument (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xOrganisation_Communities_Lnk add constraint FK_2729a051b7946367ba2562215800a55c foreign key (xMasterId, xOrganisation)
		references xOrganisation (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xOrganisation_Communities_Lnk add constraint FK_6be44e78391782bc869117c2eff75b36 foreign key (xMasterId, xEntityId, xOrganisationCommunity)
		references xOrganisationCommunity (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xOrganisation_CredRating_Lnk add constraint FK_6695df7e484b0baf021f95136deb56ea foreign key (xMasterId, xOrganisation)
		references xOrganisation (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xOrganisation_CredRating_Lnk add constraint FK_c958b9263ecafd52a870446fa1c6e02b foreign key (xMasterId, xEntityId, xOrganisationCreditRating)
		references xOrganisationCreditRating (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xOrganisationOwners add constraint FK_a06ddc58ff2affcc243253311f424734 foreign key (xMasterId, xOrganisation)
		references xOrganisation (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xUser add constraint FK_9b8ef4ba6a6409b86d1ceba494b57e60 foreign key (xMasterId, xPerson)
		references xPerson (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xUser add constraint FK_8a3fdf55a1158cea1a1602be6da840d1 foreign key (xMasterId, xReportTo)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xBankAccount add constraint FK_2966ecb97f5cc210ac23a21e055d6075 foreign key (xMasterId, xCountry)
		references xCountry (xMasterId, xAlpha3Code) on delete restrict on update restrict;

alter table xBankAccount add constraint FK_cf6d87311d09f3de23afaf8e318e0cca foreign key (xMasterId, xBank)
		references xSettlementDirectory (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xBankAccount add constraint FK_9dd0db6310f511690871e69dc1ac8eed foreign key (xMasterId, xCurrency)
		references xCurrency (xMasterId, xCode) on delete restrict on update restrict;

alter table xBankAccount_StatusChanges_Lnk add constraint FK_f57537547976dadd0da3710ca041c955 foreign key (xMasterId, xEntityId, xBankAccount)
		references xBankAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xBankAccount_StatusChanges_Lnk add constraint FK_20daa2c5cd9aa0e77193165185a85b96 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPayable add constraint FK_e5c7d1ef7994ba82c0e5079e4af343b0 foreign key (xMasterId, xOrganisation)
		references xOrganisation (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPayable add constraint FK_9b55e2284027438b85c4e4dfb4749bda foreign key (xMasterId, xOurReference)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPayable add constraint FK_5acca3333675efac1615e6ba4ce2c89b foreign key (xMasterId, xYourReference)
		references xPerson (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPayable add constraint FK_3453509a30c7f7d09454339d63bfa8d5 foreign key (xMasterId, xCurrency)
		references xCurrency (xMasterId, xCode) on delete restrict on update restrict;

alter table xPayable_BinaryDatas_Lnk add constraint FK_733d32df46d515f5ddf6a311e31cc39c foreign key (xMasterId, xPayable)
		references xPayable (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPayable_BinaryDatas_Lnk add constraint FK_42f65e2b329e9270aaf53a2b906d335e foreign key (xMasterId, xBinaryData)
		references xBinaryData (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPayable_StatusChanges_Lnk add constraint FK_a0a0fec030e9433f142c08fa089357a1 foreign key (xMasterId, xPayable)
		references xPayable (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPayable_StatusChanges_Lnk add constraint FK_9f4797812e36bc178428695728d6f4b5 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCategory add constraint FK_e04032523fb4a79f576b4789e390fcfd foreign key (xMasterId, xEntityId, xCategoryType)
		references xCategoryType (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xContact add constraint FK_5ccc245230cecdc0092da098b91966a0 foreign key (xMasterId, xLanguage)
		references xLanguage (xMasterId, xCode) on delete restrict on update restrict;

alter table xContact add constraint FK_cbf75ecff55a8bd32262b7f8a9d053d0 foreign key (xMasterId, xDefaultAddress)
		references xAddress (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xContact add constraint FK_cf3421f333abbba9e1b08360bdeb0e5c foreign key (xMasterId, xDefaultPhone)
		references xPhone (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xContact add constraint FK_95ccea9401bb95042cb978d12f6305c5 foreign key (xMasterId, xDefaultEmail)
		references xEmail (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xContact add constraint FK_5e6b7d08dc514bc751c99b8b352ce9e9 foreign key (xMasterId, xTaxCountry)
		references xCountry (xMasterId, xAlpha3Code) on delete restrict on update restrict;

alter table xContact add constraint FK_69e8d2f5d1fd8200cd8cecd6e1b4f996 foreign key (xMasterId, xCurrency)
		references xCurrency (xMasterId, xCode) on delete restrict on update restrict;

alter table xContact_StatusChange_Lnk add constraint FK_32038495a01fd2ab82c92bfa027cfd41 foreign key (xMasterId, xContact)
		references xContact (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xContact_StatusChange_Lnk add constraint FK_a0d33d8509705396231b50a0027f507f foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xContact_BankAccounts_Lnk add constraint FK_39d3f4f3049c1b235644f6967712e928 foreign key (xMasterId, xContact)
		references xContact (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xContact_BankAccounts_Lnk add constraint FK_c89146d62f0effde28f364ca84225581 foreign key (xMasterId, xEntityId, xBankAccount)
		references xBankAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xContact_Diaries_Lnk add constraint FK_908a6bc050b259d82608051e30aa17a7 foreign key (xMasterId, xContact)
		references xContact (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xContact_Diaries_Lnk add constraint FK_b86dfe66218278ccae6bd099a971e819 foreign key (xMasterId, xDiary)
		references xDiary (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xContact_Addresses_Lnk add constraint FK_6deb02557d5bcaf71016b6458f08fd20 foreign key (xMasterId, xContact)
		references xContact (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xContact_Addresses_Lnk add constraint FK_512e41ea5db9e73eaa675d576823941f foreign key (xMasterId, xAddress)
		references xAddress (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xContact_Phones_Lnk add constraint FK_8a7b00ef42396fb4a24c86be3a8c7515 foreign key (xMasterId, xContact)
		references xContact (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xContact_Phones_Lnk add constraint FK_0ede4e0b49c4f41f88d3c07441ff5edc foreign key (xMasterId, xPhone)
		references xPhone (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xContact_Emails_Lnk add constraint FK_fa4ea41775cb045fc9ea45795024e0a9 foreign key (xMasterId, xContact)
		references xContact (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xContact_Emails_Lnk add constraint FK_8f5c155a7ffa67dc65bdcbbc3147facb foreign key (xMasterId, xEmail)
		references xEmail (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xBranch add constraint FK_92913f5e7db4be9ac54dfa2aa497540b foreign key (xMasterId, xDefaultAddress)
		references xAddress (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xBranch_Addresses_Lnk add constraint FK_3f5411cf1d6896547709b0fa9a53b8f9 foreign key (xMasterId, xEntityId, xBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xBranch_Addresses_Lnk add constraint FK_25ba4744f8bfa37a7b7ad889a8b66a67 foreign key (xMasterId, xAddress)
		references xAddress (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xBranch add constraint FK_842fcf08b8bf0500c0f423438ddcd10a foreign key (xMasterId, xDefaultPhone)
		references xPhone (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xBranch_Phones_Lnk add constraint FK_8a11fcc51d37eb6c85789e7718f2ae50 foreign key (xMasterId, xEntityId, xBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xBranch_Phones_Lnk add constraint FK_25bfdffa9e8e4936d2ccf865be3629ad foreign key (xMasterId, xPhone)
		references xPhone (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xBranch add constraint FK_d951eeb9226a7e7599ec9bf7c793646e foreign key (xMasterId, xManager)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xBranch add constraint FK_9f18a10132616168b2c4c0bd123946e2 foreign key (xMasterId, xEntityId, xParentBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xBranch add constraint FK_34b0baff4b259c926ef31ed764d7bf53 foreign key (xMasterId, xEntityId, xBranchLevel)
		references xBranchLevel (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xBranch add constraint FK_dc317ef4fd868df885911584a4f3df6c foreign key (xMasterId, xEntityId, xPayableGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xBranch add constraint FK_49895646c80ca49fb814332024a0be14 foreign key (xMasterId, xEntityId, xReceivableGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xBranch add constraint FK_979b8fbeb0c34b71a62fde8cd94e8bc4 foreign key (xMasterId, xEntityId, xCorebankEntity)
		references xCorebankEntity (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xBranch add constraint FK_8e68e9899787200bd1032dfd453289db foreign key (xMasterId, xEntityId, xInterBranchGLDbTC)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xBranch add constraint FK_5f5e6e9b37594957793faf2363cee188 foreign key (xMasterId, xEntityId, xInterBranchGLCrTC)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xBranch add constraint FK_0663d0f68b32629c852c9fa580dac33e foreign key (xMasterId, xEntityId, xContingentSuspenseGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xBranch add constraint FK_fc571bd49c64123c3fda23cfacd712e7 foreign key (xMasterId, xEntityId, xRealSuspenseGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xSettlementDirectory add constraint FK_97ec6fba2109293ee2894ec98744477a foreign key (xMasterId, xCountry)
		references xCountry (xMasterId, xAlpha3Code) on delete restrict on update restrict;

alter table xSettlementDirectory add constraint FK_4bbf3cde0c7688e1f93beef1d6d310fb foreign key (xMasterId, xDefaultAddress)
		references xAddress (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xSettlementDirectory add constraint FK_e4e5d7e59c447d9a3f04b374a7335894 foreign key (xMasterId, xDefaultPhone)
		references xPhone (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xSettlementDir_Addresses_Lnk add constraint FK_ba3b27b7f81147cd9ab063d1be2babe9 foreign key (xMasterId, xSettlementDirectory)
		references xSettlementDirectory (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xSettlementDir_Addresses_Lnk add constraint FK_e2053f2d2363a6d9fcbfd414b5b530cf foreign key (xMasterId, xAddress)
		references xAddress (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xSettlementDir_Phones_Lnk add constraint FK_f211b438255cb4496577d8560cdaf467 foreign key (xMasterId, xSettlementDirectory)
		references xSettlementDirectory (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xSettlementDir_Phones_Lnk add constraint FK_412d1f397d922cb0acbd125c2ac64a96 foreign key (xMasterId, xPhone)
		references xPhone (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPerson add constraint FK_3c93c2cf73226316bda8e566b0bf5ba8 foreign key (xMasterId, xCitizenCountry)
		references xCountry (xMasterId, xAlpha3Code) on delete restrict on update restrict;

alter table xPerson add constraint FK_015c431d0ebf03545168dd403d201f21 foreign key (xMasterId, xDomicileCountry)
		references xCountry (xMasterId, xAlpha3Code) on delete restrict on update restrict;

alter table xPerson_Categories_Lnk add constraint FK_3b7103ceb8f90f8249b967ef26643dc4 foreign key (xMasterId, xPerson)
		references xPerson (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPerson_Categories_Lnk add constraint FK_3040b1714d1934eefee28d53f25c6a55 foreign key (xMasterId, xEntityId, xCategory)
		references xCategory (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xPerson_Documents_Lnk add constraint FK_191b5953e5cc9e19cf9f5c7a887b8488 foreign key (xMasterId, xPerson)
		references xPerson (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPerson_Documents_Lnk add constraint FK_e8d9dc38cc0415487f623715902e80e8 foreign key (xMasterId, xDocument)
		references xDocument (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPerson_PersonCommunities_Lnk add constraint FK_3c52915736fb805523686260498afe9d foreign key (xMasterId, xPerson)
		references xPerson (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPerson_PersonCommunities_Lnk add constraint FK_26c54dc8a33ce89e0bd37abc19a7632b foreign key (xMasterId, xEntityId, xPersonCommunity)
		references xPersonCommunity (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xPerson_PersonAliases_Lnk add constraint FK_767918567daee97a6ed5f0a34fbdd0f1 foreign key (xMasterId, xPerson)
		references xPerson (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPerson_PersonAliases_Lnk add constraint FK_5e4b06bd765c87a17fe34f9f4bd78ae7 foreign key (xMasterId, xEntityId, xPersonAlias)
		references xPersonAlias (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xBankDate add constraint FK_ba20e68e8d7898068d1c3e39317fde02 foreign key (xMasterId, xEntityId, xBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xCurrencyHoliday add constraint FK_0b149da31025d8f8996401353b313f4d foreign key (xMasterId, xCurrency)
		references xCurrency (xMasterId, xCode) on delete restrict on update restrict;

alter table xCurrencyDenomination add constraint FK_27cdcc8748a52692d9f6afe1cfd49e10 foreign key (xMasterId, xCurrency)
		references xCurrency (xMasterId, xCode) on delete restrict on update restrict;

alter table xInterfaceDefinition add constraint FK_3e5cea1cdc6091b26afea2dadff28aba foreign key (xMasterId, xIncomingInterfaceUserName)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xInterfaceUserLink add constraint FK_95905b2c12e59d3f7391a2c7a8d7f818 foreign key (xMasterId, xUser)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xInterfaceUserLink add constraint FK_0a33b1aedc39d0a7d158b41cd70001f6 foreign key (xMasterId, xInterface)
		references xInterfaceDefinition (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xAccessRight add constraint FK_8159c00071957402516630d73c54504a foreign key (xMasterId, xRole)
		references xRole (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xProcessRight add constraint FK_7c318af27690c1f4fc13d8b0cd5301e8 foreign key (xMasterId, xRole)
		references xRole (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xProcessRight add constraint FK_0f95dab72b63356c38fae483ffbc9737 foreign key (xMasterId, xEntityId, xProcessAuthorization)
		references xProcessAuthorization (xMasterId, xEntityId, xProcessDefinitionId) on delete restrict on update restrict;

alter table xRoleGroup_Roles_Lnk add constraint FK_2d7007565191cc9a74a4662fa648d511 foreign key (xMasterId, xRoleGroup)
		references xRoleGroup (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xRoleGroup_Roles_Lnk add constraint FK_fea8e4584d4d5afc5ece4f74a3c403da foreign key (xMasterId, xRole)
		references xRole (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTranslatedValue add constraint FK_ea3560ead4c6b253e6f3cc82cb85abae foreign key (xMasterId, xLanguage)
		references xLanguage (xMasterId, xCode) on delete restrict on update restrict;

alter table xUserBranchLink add constraint FK_86bdd5f6779a33587918ce287131770d foreign key (xMasterId, xUser)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xUserBranchLink add constraint FK_1aad3c4823a6250b6454ad16833da8ee foreign key (xMasterId, xEntityId, xBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xUserBranchLink add constraint FK_de6a56840c2bac5e09acf08a69b4c047 foreign key (xMasterId, xRoleGroup)
		references xRoleGroup (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDocumentTemplate add constraint FK_0de37c75a525e2cc031c7be5771c2c87 foreign key (xMasterId, xType)
		references xDocumentType (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCharge add constraint FK_0366e1756500ee5d4627348cde50ea48 foreign key (xMasterId, xEntityId, xChargeIncomeGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xCharge add constraint FK_c3e72a6a58655230671f4024e557f15a foreign key (xMasterId, xEntityId, xChargeTransactionCodeClientDB)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xCharge add constraint FK_67e0c9e16355b9d180f1218a06aad5f9 foreign key (xMasterId, xEntityId, xChargeTransactionCodeGLCR)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xCharge add constraint FK_20b8790c0d1c3f9b40b6658314e2e1dd foreign key (xMasterId, xEntityId, xChargeTransactionCodeGLDB)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xCharge add constraint FK_99affe1162c2712980ef5bfae5bf77c7 foreign key (xMasterId, xEntityId, xCommissionExpenseGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xCharge add constraint FK_241863adc17a21ccc1ca1d8b43420ed3 foreign key (xMasterId, xEntityId, xCommissionPayableGL)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xCharge add constraint FK_d4ff4610494cd7564d88dc17e18ecb72 foreign key (xMasterId, xEntityId, xCommissionTransactionCodeGLDB)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xCharge add constraint FK_ad447be40de7788d8fcbe756c5f5bab5 foreign key (xMasterId, xEntityId, xCommissionTransactionCodeGLCR)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xCharge add constraint FK_30488546a8e89e741f89e28e9e6501b3 foreign key (xMasterId, xEntityId, xCommissionTrnCodeClientDB)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xChargeCombination add constraint FK_8cb40447d666c8c33e5f7634f8ebdcff foreign key (xMasterId, xEntityId, xCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xChargeCombination add constraint FK_170bee42212c42fa3840671c778b6a23 foreign key (xMasterId, xEntityId, xBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xChargeCombination add constraint FK_fd8f165c83ee08d816177b7913f3add3 foreign key (xMasterId, xEntityId, xChannel)
		references xDeliveryChannel (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xChargeCombination add constraint FK_1e8680fb045e8cf5db69caf2b15b3b6d foreign key (xMasterId, xEntityId, xPricing)
		references xRelationshipPricing (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xChargeCombination add constraint FK_6d332c63ea7a66fed76f8efc4bf1d6a7 foreign key (xMasterId, xEntityId, xBasisCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xChargeCombination add constraint FK_9455366c11846347fd793afa83488204 foreign key (xMasterId, xEntityId, xChargeCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xChargeCombination add constraint FK_0c132010ecf4d709e52434f6b0a147b5 foreign key (xMasterId, xEntityId, xClientIdKey)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xChargeCombinationBand add constraint FK_00c0b6fcb8693651c135fbbe6d09aeef foreign key (xMasterId, xEntityId, xChargeCombination)
		references xChargeCombination (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xChargeCombinationBand add constraint FK_cf00b0dbe7a75c7c5a65df7ec2665900 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xChargeCombinationBand add constraint FK_c0b1ad6fddad3a40206c270828d31c4c foreign key (xMasterId, xApprovedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xInterestSchemeCombination add constraint FK_33e85f9aae0c87c8ba2e69c1f258a21a foreign key (xMasterId, xCurrency)
		references xCurrency (xMasterId, xCode) on delete restrict on update restrict;

alter table xInterestSchemeCombination add constraint FK_3a9a23fd19e3affbf46b6c90f495a352 foreign key (xMasterId, xEntityId, xPricing)
		references xRelationshipPricing (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xInterestSchemeCombination add constraint FK_33b87b61e8dbb50587b0ba1ef99c0046 foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xInterestSchemeCombination add constraint FK_0e24dbe442cbb22805505dcc290ad83e foreign key (xMasterId, xEntityId, xInterestScheme)
		references xInterestScheme (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xInterestSchemeBand add constraint FK_aff47960725f7a1ae61e2c83aaaab913 foreign key (xMasterId, xEntityId, xInterestSchemeCombination)
		references xInterestSchemeCombination (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xInterestSchemeBand add constraint FK_b3a6323edf410cb1394a8f786da603a2 foreign key (xMasterId, xEntityId, xInterestBaseCode)
		references xInterestBase (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xInterestSchemeBand add constraint FK_c05177972d915b8fb26085b2d55089b2 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xInterestSchemeBand add constraint FK_d582926eada7cd88759e9409644796cb foreign key (xMasterId, xUpdatedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xInterestSchemeBand add constraint FK_3fd864535832d5287b733a6d7de8e8be foreign key (xMasterId, xApprovedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPropertyChanged add constraint FK_0eafdba6e4914f06a7ed3efc06907865 foreign key (xMasterId, xChangedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xProcessAuthorization add constraint FK_42164d1c9a1b95311452317e916fdc86 foreign key (xMasterId, xUserDeployed)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xProcessMapping add constraint FK_09f394ad26c4cc7310872addbee63ae8 foreign key (xMasterId, xEntityId, xProcess)
		references xProcessAuthorization (xMasterId, xEntityId, xProcessDefinitionId) on delete restrict on update restrict;

alter table xProcessMapping add constraint FK_ea9853c2622c403986e33605e85dd74c foreign key (xMasterId, xEntityId, xBranchSubmenu)
		references xBranchSubmenu (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProcessMapping_Channel_Lnk add constraint FK_3944895eefaad19b6f54528c5b014c21 foreign key (xMasterId, xEntityId, xProcessMapping)
		references xProcessMapping (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProcessMapping_Channel_Lnk add constraint FK_eb27bbd2a0a8e10fe559eb27b995d35b foreign key (xMasterId, xEntityId, xDeliveryChannel)
		references xDeliveryChannel (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProcess_InternalProduct_Lnk add constraint FK_b5242b214d692145030e29b3a770173f foreign key (xMasterId, xEntityId, xProcessMapping)
		references xProcessMapping (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProcess_InternalProduct_Lnk add constraint FK_7a20eed9bb4ad606638b90c3de240635 foreign key (xMasterId, xEntityId, xProductProfile)
		references xProductProfile (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProcess_ExternalProduct_Lnk add constraint FK_a950deb3020aaa7f1374ea0ccbcd76ba foreign key (xMasterId, xEntityId, xProcessMapping)
		references xProcessMapping (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProcess_ExternalProduct_Lnk add constraint FK_03a355ebb15a35bbf300d989e3c629e5 foreign key (xMasterId, xEntityId, xExternalProductMapping)
		references xExternalProductMapping (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProcessMapping_Branches_Lnk add constraint FK_c20db253e41aaa0a937e6f8863f205a2 foreign key (xMasterId, xEntityId, xProcessMapping)
		references xProcessMapping (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProcessMapping_Branches_Lnk add constraint FK_78cdbd8f371d36789e8a0be20aca0a0f foreign key (xMasterId, xEntityId, xBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xProcessAutofillMapping add constraint FK_2dd86a53a82bd32b9758e120137c6683 foreign key (xMasterId, xEntityId, xProcessMapping)
		references xProcessMapping (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProcessAutofillMapping add constraint FK_7670906bbb78722bbe76282b8170b620 foreign key (xMasterId, xEntityId, xProcessVariable)
		references xProcessVariable (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProcessChargeMapping add constraint FK_fa8c21378263e7903b119750872870bf foreign key (xMasterId, xEntityId, xProcessMapping)
		references xProcessMapping (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProcessChargeMapping add constraint FK_39bbcd2adc41bf177679fea76a71a218 foreign key (xMasterId, xEntityId, xCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProcessChargeMapping add constraint FK_8784272f2113b76211def0e75de1c17f foreign key (xMasterId, xEntityId, xChargeAmount)
		references xProcessVariable (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProcessChargeMapping add constraint FK_cf0a888ee3ded2c7710f9694dfef4579 foreign key (xMasterId, xEntityId, xChargeBasis)
		references xProcessVariable (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProcessAccountingMapping add constraint FK_3460bcdb7b155e801ed65be5fb94b767 foreign key (xMasterId, xEntityId, xProcessMapping)
		references xProcessMapping (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProcessAccountingMapping add constraint FK_96c5973ebc8637a2faa58d3887447cd9 foreign key (xMasterId, xEntityId, xProcessVariable)
		references xProcessVariable (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProcessAccountingMapping add constraint FK_b6999ee9491734d2fc0545b59e9c9fe4 foreign key (xMasterId, xEntityId, xRateType)
		references xCurrencyRateType (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xLinkProcess add constraint FK_02b5456efe956f7671cf22aa33a4b594 foreign key (xMasterId, xEntityId, xProcess)
		references xProcessAuthorization (xMasterId, xEntityId, xProcessDefinitionId) on delete restrict on update restrict;

alter table xLinkProcess add constraint FK_bd947a8ebfbb7cafe49340fd6ccdd296 foreign key (xMasterId, xEntityId, xTask)
		references xProcessTask (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xLinkProcessWf add constraint FK_e05b20424c92700cec3a7ab9750d14e3 foreign key (xMasterId, xEntityId, xLinkProcess)
		references xLinkProcess (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xLinkProcessWf add constraint FK_1969a25d90fe8c0d3c84dd8e39126531 foreign key (xMasterId, xEntityId, xLinkedProcess)
		references xProcessAuthorization (xMasterId, xEntityId, xProcessDefinitionId) on delete restrict on update restrict;

alter table xLinkProcessWfVariable add constraint FK_00c0d011a3b0536076f686cf1620b642 foreign key (xMasterId, xEntityId, xLinkProcessWf)
		references xLinkProcessWf (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xLinkProcessWfVariable add constraint FK_07a2981ba4c60419efcfd3c2b7a97508 foreign key (xMasterId, xEntityId, xProcessVariable)
		references xProcessVariable (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xLinkProcessWfVariable add constraint FK_1d70a233e0c7eb948bea3de956e201ec foreign key (xMasterId, xEntityId, xLinkProcessVariable)
		references xProcessVariable (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xPersonCommunity add constraint FK_7b33337437e8969aa7d64f5ebaf97911 foreign key (xMasterId, xPerson)
		references xPerson (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xPersonCommunity add constraint FK_f7fd8237798bd61ba5e188b11b7c29d6 foreign key (xMasterId, xEntityId, xType)
		references xCommunity (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xOrganisationCommunity add constraint FK_b0e13e622fc6a9419602fb93d23f3784 foreign key (xMasterId, xEntityId, xType)
		references xCommunity (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xOrganisationCommunity add constraint FK_ef2d78bda61f59a8f7993e97efed3c93 foreign key (xMasterId, xOrganisation)
		references xOrganisation (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xClientKYCDetail add constraint FK_ee0299a9ec7951b10f2a64e5b5689dc0 foreign key (xMasterId, xEntityId, xGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xClientKYCDetail add constraint FK_bba495a0b76373a66cd04c7ec7064c28 foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientActivity add constraint FK_631cf7af4b79a8362776fc30dbe0c62a foreign key (xMasterId, xActivityType)
		references xSICCode (xMasterId, xCode) on delete restrict on update restrict;

alter table xClientActivity add constraint FK_39c14d333f1ea46359fcf45bba415eac foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientActivity_Countries_Lnk add constraint FK_4876f422645c5b172f4cf362e5204947 foreign key (xMasterId, xEntityId, xClientActivity)
		references xClientActivity (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientActivity_Countries_Lnk add constraint FK_e45afc4d06cef892bc322da91c113e12 foreign key (xMasterId, xCountry)
		references xCountry (xMasterId, xAlpha3Code) on delete restrict on update restrict;

alter table xClientAverageMonthlyBalance add constraint FK_2280c9ea93a41e1646666f465a405834 foreign key (xMasterId, xEntityId, xGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xClientAverageMonthlyBalance add constraint FK_dc0f3c479b99d882454a24d29467ec3f foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xClientAverageTurnOver add constraint FK_13b44198edf0586ba83d107b011c5d6a foreign key (xMasterId, xEntityId, xGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xClientAverageTurnOver add constraint FK_96e3fb3a68ef5258d14b95bb79dcac89 foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xOrganisationCreditRating add constraint FK_c63b5ba5bfe253a92444001d2f8f3a3d foreign key (xMasterId, xOrganisation)
		references xOrganisation (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xOrganisationCreditRating add constraint FK_c4b888914d5a00658022b507a06b3d9d foreign key (xMasterId, xCreditAgency)
		references xCreditAgency (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xRuleConfiguration add constraint FK_b08f144a25c07a884d5ebbb9f6eeaa91 foreign key (xMasterId, xEntityId, xRuleSnapshot)
		references xRuleSnapshot (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xRuleParam add constraint FK_9c4246ddee4f4abf9a587a8298a0853f foreign key (xMasterId, xEntityId, xRuleSnapshot)
		references xRuleSnapshot (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProcessRuleConfig add constraint FK_d7b4708be49acfdbdec3dbd43a124e94 foreign key (xMasterId, xEntityId, xProcessAuthorization)
		references xProcessAuthorization (xMasterId, xEntityId, xProcessDefinitionId) on delete restrict on update restrict;

alter table xProcessRuleConfig add constraint FK_0b783d9167f0a3aa4f0dca9b6c040a03 foreign key (xMasterId, xEntityId, xRuleSnapshot)
		references xRuleSnapshot (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProcessRuleConfig add constraint FK_9082d648620acd478703105c520aff00 foreign key (xMasterId, xEntityId, xRuleConfiguration)
		references xRuleConfiguration (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTillVault add constraint FK_27ac7140f63735766eb8cb4bcb1ccf9c foreign key (xMasterId, xEntityId, xBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTillVault add constraint FK_371e8fd89b638001ef6a8283b2c4577a foreign key (xMasterId, xEntityId, xLedger)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTillVault add constraint FK_16c300a2a64c5fb9768d58e703437517 foreign key (xMasterId, xCurrentUser)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTillVault add constraint FK_b7271bc023749d1168fe5cd74cd45a26 foreign key (xMasterId, xEntityId, xReportingVault)
		references xTillVault (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTillVault add constraint FK_ef0317e8105c0ca63424de0b3aba763c foreign key (xMasterId, xEntityId, xExcessLedger)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTillVault add constraint FK_4390cd6bfa41e1e4dae563beffa8ce82 foreign key (xMasterId, xEntityId, xShortageLedger)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTillVaultOperation add constraint FK_dda1d5e443dc513d72edf5523659b097 foreign key (xMasterId, xEntityId, xTillVault)
		references xTillVault (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTillVaultOperation add constraint FK_f4063d9f213ab3ce3228bcf380177fc4 foreign key (xMasterId, xUser)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xTillVaultCurrency add constraint FK_3c42e0ef4dc60f199bd7b97c98000567 foreign key (xMasterId, xEntityId, xGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xTillVaultCurrency add constraint FK_8a113e06c02a4324bc31579b48190521 foreign key (xMasterId, xEntityId, xTillVault)
		references xTillVault (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTillVaultBalance add constraint FK_1e98e3799823891277db0fd1d24c0274 foreign key (xMasterId, xEntityId, xTillVaultCurrency)
		references xTillVaultCurrency (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xTillVaultBalanceHistory add constraint FK_9c7531f4739fe2f4f45b2e08e12853a6 foreign key (xMasterId, xEntityId, xTillVault)
		references xTillVault (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xTillVaultBalanceHistory add constraint FK_aac1fad08af52f46e6bd3cb6e4128e7a foreign key (xMasterId, xEntityId, xGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xChannelUser add constraint FK_9ca9243f4b7e69b09a1d401e00151eed foreign key (xMasterId, xPerson)
		references xPerson (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xChannelUser_IssueCodeCard_Lnk add constraint FK_8afef06368e51f34f1c379696e6d89d8 foreign key (xMasterId, xChannelUser)
		references xChannelUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xChannelUser_IssueCodeCard_Lnk add constraint FK_271e8839bf59882b6c792b2b56c6a799 foreign key (xMasterId, xEntityId, xChannelUserIssueCodeCard)
		references xChannelUserIssueCodeCard (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xChannelUser_UserRole_Lnk add constraint FK_468cbada43872a160c0173c01b48d944 foreign key (xMasterId, xChannelUser)
		references xChannelUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xChannelUser_UserRole_Lnk add constraint FK_533333c71e8eb6ed99792e5bb1c3c1ec foreign key (xMasterId, xEntityId, xChannelUserRole)
		references xChannelUserRole (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardMaster add constraint FK_3f5c52d8d5644e922689fa7eb88638d4 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCardMaster_StatusChanges_Lnk add constraint FK_7d55eaba0714fa7a8bdc060bf1ca5885 foreign key (xMasterId, xCardMaster)
		references xCardMaster (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCardMaster_StatusChanges_Lnk add constraint FK_094d1dea5fb2bea6b581b422185e9522 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCardDetails add constraint FK_1f3c1e61c273fa011fad5fa1219e4f7d foreign key (xMasterId, xCardMaster)
		references xCardMaster (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xLocation add constraint FK_777e15afb0eb5efabb37b9ea63458e27 foreign key (xMasterId, xEntityId, xBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xLocation_Photograph_Lnk add constraint FK_14b42d491dbc83766c94e46581bebd24 foreign key (xMasterId, xEntityId, xLocation)
		references xLocation (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xLocation_Photograph_Lnk add constraint FK_3fd39b44aa940a07a5ce4861851873a7 foreign key (xMasterId, xBinaryData)
		references xBinaryData (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xOperatingHours add constraint FK_72188d6072910a3ad81d3032538a0481 foreign key (xMasterId, xEntityId, xBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xMenuMaster_IconFile_Lnk add constraint FK_212c337b7783aab1e73dd7687a094753 foreign key (xMasterId, xEntityId, xMenuMaster)
		references xMenuMaster (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xMenuMaster_IconFile_Lnk add constraint FK_e596ef04a25111771d6919e2e8e6e9e7 foreign key (xMasterId, xBinaryData)
		references xBinaryData (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xMenuChild add constraint FK_868a85aa946d6b1f2280e7835f8e19b8 foreign key (xMasterId, xEntityId, xMenuMaster)
		references xMenuMaster (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xMenuChild add constraint FK_7b9d982ac6a10cf6ad2ed2544ac950a9 foreign key (xMasterId, xLanguage)
		references xLanguage (xMasterId, xCode) on delete restrict on update restrict;

alter table xChannelUserRole add constraint FK_f59a502373813742f670120493bb020a foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xChannelUserRole add constraint FK_2a0fdb79b05b8c462439edd90ea91aaf foreign key (xMasterId, xRole)
		references xPersonRole (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xChannelUserRole add constraint FK_c594a643a04a9dbd32776344cc4d333b foreign key (xMasterId, xLimitCurrency)
		references xCurrency (xMasterId, xCode) on delete restrict on update restrict;

alter table xCBUserRole_MenuChild_Lnk add constraint FK_45bbbd33ebf0cf6a11fcea650663e9e3 foreign key (xMasterId, xEntityId, xChannelUserRole)
		references xChannelUserRole (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCBUserRole_MenuChild_Lnk add constraint FK_47a20415e1a9e719dc8b28ab59b918fe foreign key (xMasterId, xEntityId, xMenuChild)
		references xMenuChild (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xChannelUserActivityLimit add constraint FK_33eaf4fe883d233cd74e8eba1322bdc1 foreign key (xMasterId, xEntityId, xMenuChild)
		references xMenuChild (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xChannelUserActivityLimit add constraint FK_09f161bd7193e12e10b261242a64dd64 foreign key (xMasterId, xEntityId, xChannelUserRole)
		references xChannelUserRole (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xChannelUserActivityLog add constraint FK_5bdde0a9819bd3c3f07f495d6fb67f18 foreign key (xMasterId, xChannelUser)
		references xChannelUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xChannelUserActivityLog add constraint FK_50002ae484289774561bf545abf1a128 foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xChannelUserActivityLog add constraint FK_495f17b037b20f91a6388f58cb6d202f foreign key (xMasterId, xEntityId, xActivity)
		references xMenuChild (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xChannelUserExternalMapping add constraint FK_3930d19e1645e1cb2e65a489590f7221 foreign key (xMasterId, xChannelUser)
		references xChannelUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xChannelUserExternalMapping add constraint FK_f6e6e5b5cc70c569ab9348b911ae1a20 foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xChannelUserExternalMapping add constraint FK_01705b3c514d2522bea4e967411f7abf foreign key (xMasterId, xInterface)
		references xInterfaceDefinition (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xChannelUserIssueCodeCard add constraint FK_0a3c9f7b20d808ce02d876e830221c19 foreign key (xMasterId, xCardMaster)
		references xCardMaster (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xChannelUserIssueCodeCard add constraint FK_13498805d1492ccc3c3f140f43264e1b foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCBIssueCodeCard_SC_Lnk add constraint FK_2d1d5250d6190d95b3ef2f113d001f03 foreign key (xMasterId, xEntityId, xChannelUserIssueCodeCard)
		references xChannelUserIssueCodeCard (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCBIssueCodeCard_SC_Lnk add constraint FK_dde3488ced4c4aaed4c1a844cbcd4bba foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXForwardRate add constraint FK_c7dab445be0764b4915fa2049f6d9e27 foreign key (xMasterId, xFromCurrency)
		references xCurrency (xMasterId, xCode) on delete restrict on update restrict;

alter table xFXForwardRate add constraint FK_b4ffcecbdb04ddc43325e52ae588d62b foreign key (xMasterId, xEntityId, xToCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xFXForwardRate add constraint FK_0955332e41902976d6c7c7af4ea70101 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXForwardRate add constraint FK_a59d616d567681b89d7892183b3c742c foreign key (xMasterId, xApprovedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXForwardRate_SC_Lnk add constraint FK_c95e9924db207eef497e90097cdfc4a9 foreign key (xMasterId, xEntityId, xFXForwardRate)
		references xFXForwardRate (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXForwardRate_SC_Lnk add constraint FK_ca3ef75d50dd81079367fb88314ad2eb foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xFXForwardRate_Period_Lnk add constraint FK_dbfce62ef7d58e9c30f124ed264f0773 foreign key (xMasterId, xEntityId, xFXForwardRate)
		references xFXForwardRate (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXForwardRate_Period_Lnk add constraint FK_55895bb4b6be7ae7a9dfbf52797a0fec foreign key (xMasterId, xEntityId, xFXForwardRatePeriod)
		references xFXForwardRatePeriod (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xFXForwardRatePeriod add constraint FK_8260dacf31eb63a77f1d4b73bfb4b3f2 foreign key (xMasterId, xEntityId, xFXForwardRate)
		references xFXForwardRate (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProcessTask add constraint FK_450c42a46d3240461e5f978102e569d6 foreign key (xMasterId, xEntityId, xProcessAuthorization)
		references xProcessAuthorization (xMasterId, xEntityId, xProcessDefinitionId) on delete restrict on update restrict;

alter table xProcessVariable add constraint FK_727a3f275fce8097c312a4271cc54d47 foreign key (xMasterId, xEntityId, xProcessTask)
		references xProcessTask (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xChannelUserChallengeLog add constraint FK_7c5076a05abb24ec7200e0b2dfc60d29 foreign key (xMasterId, xChannelUser)
		references xChannelUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xChannelUserChallengeLog add constraint FK_839c31ed7a49894ecb5086fa34c4f300 foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xChannelUserChallengeLog add constraint FK_f2cd31373aaa02e9302a1c22b7ebc15f foreign key (xMasterId, xEntityId, xActivity)
		references xMenuChild (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xChannelUserPassword add constraint FK_c4cac5366e49fc24bc352c915718d8de foreign key (xMasterId, xChannelUser)
		references xChannelUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDiscountRate add constraint FK_6ab73759e9398fa78ded6eebe706bbba foreign key (xMasterId, xCurrency)
		references xCurrency (xMasterId, xCode) on delete restrict on update restrict;

alter table xDiscountRate add constraint FK_c9cce05e4c46b57e21f664a1724796d5 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDiscountRate_SC_Lnk add constraint FK_08e3f9395d6ba1417664bd9625151bde foreign key (xMasterId, xEntityId, xDiscountRate)
		references xDiscountRate (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xDiscountRate_SC_Lnk add constraint FK_338d0c0742a46723213a10aa4e4af65c foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDiscountRatePeriod add constraint FK_d26355801fc3f6fd2740b365306311f1 foreign key (xMasterId, xEntityId, xDiscountRate)
		references xDiscountRate (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xDiscountRatePeriod add constraint FK_d6b862a8195d159f02514d5f86e8c3d9 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCardProduct add constraint FK_361fdd6c89c5191547ecba2c90f574ee foreign key (xMasterId, xEntityId, xCardProvider)
		references xCardProvider (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardProduct add constraint FK_13e65e675e3ef1e92d7699ec21aa4d25 foreign key (xMasterId, xEntityId, xCardIssuanceCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardProduct add constraint FK_b70551dac77a60a6a35e1d1b480bd56a foreign key (xMasterId, xEntityId, xProcessingCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardProduct add constraint FK_32835133415e7851bcb6b4c0f975c1f7 foreign key (xMasterId, xEntityId, xAnnualCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardProduct add constraint FK_5a999522ca2479c8fc98ef2575b38f3c foreign key (xMasterId, xEntityId, xServiceCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardProduct add constraint FK_472e24d1ab21bc54e9a4c7e97ee279e2 foreign key (xMasterId, xEntityId, xLatePaymentCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardProduct add constraint FK_6ba03e8a9de7d6a5a9c51fa02ea43d4b foreign key (xMasterId, xEntityId, xChargesOnExtendedCredit)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardProduct_TrnsCodes_Lnk add constraint FK_0e458d1013958a3f5fadb32e94758ca1 foreign key (xMasterId, xEntityId, xCardProduct)
		references xCardProduct (xMasterId, xEntityId, xBinNumber) on delete restrict on update restrict;

alter table xCardProduct_TrnsCodes_Lnk add constraint FK_34c2044f02da11761dbee90ca8ec1039 foreign key (xMasterId, xEntityId, xTransactionCode)
		references xTransactionCode (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xCardProduct_Offerings_Lnk add constraint FK_a34754e89b51a0c929c15ce93c303888 foreign key (xMasterId, xEntityId, xCardProduct)
		references xCardProduct (xMasterId, xEntityId, xBinNumber) on delete restrict on update restrict;

alter table xCardProduct_Offerings_Lnk add constraint FK_3c6723d1a6dc3fb7beb63d4d0c96fdf5 foreign key (xMasterId, xEntityId, xOffering)
		references xOffering (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardProduct_Clients_Lnk add constraint FK_72d64985e36bc8e467f14f4be5d433a7 foreign key (xMasterId, xEntityId, xCardProduct)
		references xCardProduct (xMasterId, xEntityId, xBinNumber) on delete restrict on update restrict;

alter table xCardProduct_Clients_Lnk add constraint FK_f3d07b03cdd83b6926f3ca600e3cfda9 foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardProduct_AccProducts_Lnk add constraint FK_c77ead760a4dffa8d224ffe068d076ee foreign key (xMasterId, xEntityId, xCardProduct)
		references xCardProduct (xMasterId, xEntityId, xBinNumber) on delete restrict on update restrict;

alter table xCardProduct_AccProducts_Lnk add constraint FK_e6f06ce5c351aa3b4d25c8045245502c foreign key (xMasterId, xEntityId, xProductProfile)
		references xProductProfile (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xCardProduct_Currency_Lnk add constraint FK_198d6ad676e947f5d4ba31967a0e57af foreign key (xMasterId, xEntityId, xCardProduct)
		references xCardProduct (xMasterId, xEntityId, xBinNumber) on delete restrict on update restrict;

alter table xCardProduct_Currency_Lnk add constraint FK_87ef59f8d33e11ed6e4717b945c10fe7 foreign key (xMasterId, xEntityId, xGLCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xCardProduct_Designs_Lnk add constraint FK_b169c32c80812305e1807a017f54adcd foreign key (xMasterId, xEntityId, xCardProduct)
		references xCardProduct (xMasterId, xEntityId, xBinNumber) on delete restrict on update restrict;

alter table xCardProduct_Designs_Lnk add constraint FK_0bcaa7b4a48780adf700f2a2581f896a foreign key (xMasterId, xDesign)
		references xDesign (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCardProduct_Notifications_Lnk add constraint FK_6e1ce5c0beb495c7c510708c1d97fcf7 foreign key (xMasterId, xEntityId, xCardProduct)
		references xCardProduct (xMasterId, xEntityId, xBinNumber) on delete restrict on update restrict;

alter table xCardProduct_Notifications_Lnk add constraint FK_b7bff6a36ed7512a98c9b09c55bc9c69 foreign key (xMasterId, xEntityId, xNotification)
		references xNotification (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardProduct_AddCharges_Lnk add constraint FK_b32bbdd573a370ac86ef50c7c25dda29 foreign key (xMasterId, xEntityId, xCardProduct)
		references xCardProduct (xMasterId, xEntityId, xBinNumber) on delete restrict on update restrict;

alter table xCardProduct_AddCharges_Lnk add constraint FK_fe5366dfbc4aae0261acd6fe093c71b9 foreign key (xMasterId, xEntityId, xAdditionalCharge)
		references xAdditionalCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardProduct_Branches_Lnk add constraint FK_135fa416e26c1fa690b93a627253eaf9 foreign key (xMasterId, xEntityId, xCardProduct)
		references xCardProduct (xMasterId, xEntityId, xBinNumber) on delete restrict on update restrict;

alter table xCardProduct_Branches_Lnk add constraint FK_2a6185755b511f79687aaab821482e47 foreign key (xMasterId, xEntityId, xBranch)
		references xBranch (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xAdditionalCharge add constraint FK_8f76cc3b7dd3117252e48e6f91286c27 foreign key (xMasterId, xEntityId, xChargeScheme)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xDesign_BinaryDatas_Lnk add constraint FK_4c45593259995c3a0b73ba3f62b6e9f3 foreign key (xMasterId, xDesign)
		references xDesign (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xDesign_BinaryDatas_Lnk add constraint FK_23270d55a218e92ac8c0a34e35806df9 foreign key (xMasterId, xBinaryData)
		references xBinaryData (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xNotification add constraint FK_0df2e458d2810ffa4444fbe3b70beb2c foreign key (xMasterId, xEntityId, xMessageType)
		references xMessageType (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xNotification_SC_Lnk add constraint FK_b8bdd7ca0e80aad9fa660baa53948a36 foreign key (xMasterId, xEntityId, xNotification)
		references xNotification (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xNotification_SC_Lnk add constraint FK_a41e8877ddf846cb3fae0cfe95fc33e0 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCardProvider add constraint FK_d39ca4911d1798bb1690fef84ab312bc foreign key (xMasterId, xInterface)
		references xInterfaceDefinition (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCard add constraint FK_4fe4ac8535b4c31914fa872d432fe83e foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCard add constraint FK_ccd821de790d4ebea2c06d601b408cda foreign key (xMasterId, xEntityId, xCardProduct)
		references xCardProduct (xMasterId, xEntityId, xBinNumber) on delete restrict on update restrict;

alter table xCard add constraint FK_b46325015b4f11b56a055c7f308e93b9 foreign key (xMasterId, xEntityId, xPrimaryCard)
		references xCard (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCard add constraint FK_32087c3027844ae5f9cc737ad84fa650 foreign key (xMasterId, xEntityId, xAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCard add constraint FK_139b2eb4b9a8d7fc1c93d58558704c2b foreign key (xMasterId, xEntityId, xCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xCard add constraint FK_a85a57abb88665b8520550679e01d920 foreign key (xMasterId, xCardHolder)
		references xContact (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCard add constraint FK_59165dd280d7b86f13495de67fbeba41 foreign key (xMasterId, xEntityId, xLinkedCard)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCard add constraint FK_408d6e35a3a6794d984f63a8c72c2c6a foreign key (xMasterId, xEntityId, xOverallLimit)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCard add constraint FK_4f1dbfd0bb4325ca7a3d8c3ffbd9fc3c foreign key (xMasterId, xEntityId, xCashLimit)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCard add constraint FK_99828cd9bf111ffe0f965584eb179b25 foreign key (xMasterId, xEntityId, xUtilizedLimit)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCard add constraint FK_741b1e999662a7384f84465fdb95489b foreign key (xMasterId, xEntityId, xAvailableLimit)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCard add constraint FK_bc53acfe36e59f21a4f4f30db4052e91 foreign key (xMasterId, xEntityId, xAvailableCashLimit)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCard_LinkedAccounts_Lnk add constraint FK_9333825260dd0ab78d3781fc5e919c6f foreign key (xMasterId, xEntityId, xCard)
		references xCard (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCard_LinkedAccounts_Lnk add constraint FK_7f394e1cb37b09aefd61d5ff174eb32a foreign key (xMasterId, xEntityId, xLinkedAccount)
		references xLinkedAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCard add constraint FK_6cf0245627590724fc0a775462ce86ce foreign key (xMasterId, xEntityId, xDefaultAccountNumber)
		references xLinkedAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardCharges add constraint FK_4c61552043f86af87b4bcdc18442c2a1 foreign key (xMasterId, xEntityId, xCard)
		references xCard (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardCharges add constraint FK_c9419de3f4b4cdba0c189006d405f202 foreign key (xMasterId, xEntityId, xCardIssuanceCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardCharges add constraint FK_0eb805d2130ac84dac8f623e0e615c04 foreign key (xMasterId, xEntityId, xProcessingCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardCharges add constraint FK_cb420a363dde6c05ae71ca516e0ab82b foreign key (xMasterId, xEntityId, xAnnualCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardCharges add constraint FK_f79eeb7e3a1d237a77fcdf84bccc599c foreign key (xMasterId, xEntityId, xServiceCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardCharges add constraint FK_1d11fbfd81d0a58a577ffa106e2df6c6 foreign key (xMasterId, xEntityId, xLatePaymentCharge)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardCharges add constraint FK_06a9bac97cd8bef5e2a7dff7b7faf310 foreign key (xMasterId, xEntityId, xChargesOnExtendedCredit)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardCharges add constraint FK_f2337d9416bd6b9c2a1006cbd0642caf foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCardCharges_SC_Lnk add constraint FK_026b236725594fe9ee384f206e113290 foreign key (xMasterId, xEntityId, xCardCharges)
		references xCardCharges (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardCharges_SC_Lnk add constraint FK_ad72fa8039a87e619ad964ace79408e6 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCardAdditionalCharges add constraint FK_b257e82b49b57ca652583adf16648388 foreign key (xMasterId, xEntityId, xCard)
		references xCard (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardAdditionalCharges add constraint FK_82a75c87c136105f179e9a60854876e9 foreign key (xMasterId, xEntityId, xChargeScheme)
		references xCharge (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardAdditionalCharges add constraint FK_0f40f38210416fe6033118ae2815c8a9 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCardAdditionalCharges_SC_Lnk add constraint FK_927569d73d9b8a1bd392bf573c9e8e99 foreign key (xMasterId, xEntityId, xCardAdditionalCharges)
		references xCardAdditionalCharges (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardAdditionalCharges_SC_Lnk add constraint FK_ec04ec9da78ea3c536aa7c5bdb14ff0c foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCardStatus add constraint FK_50098b6e180fae34125efb2b72d0dcdc foreign key (xMasterId, xEntityId, xCard)
		references xCard (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardStatus add constraint FK_2333fcc30596aa23d8980bae8e5a4dd3 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCardStatus_SC_Lnk add constraint FK_dfd73e3929fbf67e7be318c8a746334d foreign key (xMasterId, xEntityId, xCardStatus)
		references xCardStatus (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCardStatus_SC_Lnk add constraint FK_c82212098edea70e4db9cf8943bb7a45 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xLinkedAccount add constraint FK_a77b13fe5e92b144a4a17dcd5c46e5b1 foreign key (xMasterId, xEntityId, xAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xLinkedAccount add constraint FK_671ff225c04dba87d5168dd754bd48ce foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xSettlementInstructions add constraint FK_1caa43002a247c63b883912b94d8637c foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xSettlementInstructions add constraint FK_9f0e01a15477e845d6cd55fbc5003738 foreign key (xMasterId, xEntityId, xCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xSettlementInstructions add constraint FK_ad8e26c85817bb744c13b9d4dcce43d6 foreign key (xMasterId, xEntityId, xProduct)
		references xProduct (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xSettlementInstructions add constraint FK_6330feff7b12f88f8499969ecadf9868 foreign key (xMasterId, xEntityId, xDebitAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xSettlementInstructions add constraint FK_770886232b36e8d9d23504a75f1d5044 foreign key (xMasterId, xEntityId, xDebitGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xSettlementInstructions add constraint FK_4fc436c7b43cc8bc1707ca1a54b474cd foreign key (xMasterId, xEntityId, xCreditAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xSettlementInstructions add constraint FK_5fc8e03629eece95b476e183ee48120e foreign key (xMasterId, xEntityId, xCreditGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xSettlementInstructions add constraint FK_1289d831979884bd296c478bdbad5bb1 foreign key (xMasterId, xEntityId, xChargeAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xSettlementInstructions add constraint FK_f420763879292eca42b32ebaa7392201 foreign key (xMasterId, xEntityId, xChargeGLAccount)
		references xGLAccount (xMasterId, xEntityId, xCode) on delete restrict on update restrict;

alter table xSettlementInstructions add constraint FK_796eeafa79829e8f6e3255ff3ed5553e foreign key (xMasterId, xBeneficiaryBIC)
		references xSettlementDirectory (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xSettlementInstructions add constraint FK_2a68063aa159290bc9edc1d7404406ef foreign key (xMasterId, xAcctWithInstitutionBIC)
		references xSettlementDirectory (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xSettlementInstructions add constraint FK_34e58075a5529388cf84c0f09e4b7d89 foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xSI_SC_Lnk add constraint FK_848425ecc5665fa829e9409c4bffbd74 foreign key (xMasterId, xEntityId, xSettlementInstructions)
		references xSettlementInstructions (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xSI_SC_Lnk add constraint FK_6143b979435e7cdafa3c98c6afdd2db0 foreign key (xMasterId, xStatusChange)
		references xStatusChange (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCollateral add constraint FK_a0184cdbbce9a3f1497cac86f9385f38 foreign key (xMasterId, xEntityId, xCollateralCurrency)
		references xGLCurrency (xMasterId, xEntityId, xCurrency) on delete restrict on update restrict;

alter table xCollateral_Client_Lnk add constraint FK_a5b90eb051da695168091a3c778604c6 foreign key (xMasterId, xEntityId, xCollateral)
		references xCollateral (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCollateral_Client_Lnk add constraint FK_3954ea1b3e168f73e7e4bae420e90a68 foreign key (xMasterId, xEntityId, xClient)
		references xClient (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCollateral add constraint FK_b266cdf8be90defbc0298ca0db34d0cc foreign key (xMasterId, xAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCollateral add constraint FK_7d1012aae5e621440cff8c879a2d96fe foreign key (xMasterId, xApprovedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCollateral add constraint FK_f77ba4d2803f8521cc8d1db659f3c9f5 foreign key (xMasterId, xUpdatedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCollateral_Contact_Lnk add constraint FK_06b9da22920780b200843d419183627e foreign key (xMasterId, xEntityId, xCollateral)
		references xCollateral (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCollateral_Contact_Lnk add constraint FK_e832a9e7f4b729fbc178d58f1cb02f68 foreign key (xMasterId, xContact)
		references xContact (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCollateralNotes add constraint FK_341d970b2516ea8d795c49893ad41fc5 foreign key (xMasterId, xEntityId, xCollateral)
		references xCollateral (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCollateralCash add constraint FK_0ff20cda3214dd95908c704c2a45c175 foreign key (xMasterId, xEntityId, xClientAccount)
		references xClientAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCollateralCash add constraint FK_c70520bf802b576bbff9982c58b74962 foreign key (xMasterId, xEntityId, xTermDepositAccount)
		references xTermDepositAccount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCollateralCash add constraint FK_668e4020995c3e0e2465c0ed802a8a53 foreign key (xMasterId, xEntityId, xBlockCategory)
		references xBlockCategory (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCollateralCash add constraint FK_0b0320220c22abcb5d0f492e3354a142 foreign key (xMasterId, xEntityId, xAmountBlock)
		references xBlockedAmount (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCollateralProperty add constraint FK_38d3e5f6c510e21563c58506adcbfd35 foreign key (xMasterId, xAddressType)
		references xAddressType (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCollateralProperty add constraint FK_e186d329fcc3dc8354cc3938d5caf88c foreign key (xMasterId, xCountry)
		references xCountry (xMasterId, xAlpha3Code) on delete restrict on update restrict;

alter table xProperty_CollateralEM_Lnk add constraint FK_46ef9608fc5cf155f5734e8cf6844619 foreign key (xMasterId, xEntityId, xCollateralProperty)
		references xCollateralProperty (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xProperty_CollateralEM_Lnk add constraint FK_dfc589f712e6ff7acb9077009aa8e090 foreign key (xMasterId, xEntityId, xCollateralEMortgage)
		references xCollateralEMortgage (xMasterId, xEntityId, xIdKey) on delete restrict on update restrict;

alter table xCollateralProperty add constraint FK_e3a62a953e5db1f458a142b3f4bf798f foreign key (xMasterId, xValueAddedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCollateralProperty add constraint FK_cabc1ec681cc2a50ae2a46b1f936a315 foreign key (xMasterId, xValueApprovedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;

alter table xCollateralProperty add constraint FK_6e8b4b070c45f3fca195b7aae729856e foreign key (xMasterId, xValueUpdatedBy)
		references xUser (xMasterId, xIdKey) on delete restrict on update restrict;
